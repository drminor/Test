﻿using System.ServiceModel;
using System.Threading.Tasks;

namespace Test001WcfService
{
	[ServiceContract]
	public interface IService1
	{
		[OperationContract]
		Task<TestServiceResult> SendMessagesAsync(int messagesToSend, int jobCntr, string messageTemplate, int delayToSimulateOtherWorkMs);
	}

}
