﻿using Autofac;
using Autofac.Integration.Wcf;
using GatewayLib.ClientPool;
using GatewayLib.Gateway;
using GatewayLib.Tcp;
using System;
using System.Net;
using TcpProtocolLib;

namespace Test001WcfService
{
	public class Global : System.Web.HttpApplication
	{
		public static readonly int TEST_SERVER_PORT = 11234;

		public static readonly string CERT_PATH = @"C:\Users\david\ClientRunner.pfx";
		private static readonly string CERT_PASS = "Mary";
		private static readonly string PEER_PUBLIC_CERT_PATH = @"C:\Users\david\TcpServer.cer";

		protected void Application_Start(object sender, EventArgs e)
		{
			IPAddress remoteTcpServer = IPAddress.Parse("192.168.3.126");
			//IPAddress remoteTcpServer = IPAddress.Loopback;

			CertInfo certInfo = new CertInfo(CERT_PATH, CERT_PASS, PEER_PUBLIC_CERT_PATH);
			ClientPoolSettings clientPoolSettings = new ClientPoolSettings
			(
				new IPEndPoint(remoteTcpServer, TEST_SERVER_PORT),
				minConnections: 3, //3,
				maxConnections: 10,
				allocateClientTimeoutMs: TimeSpan.FromMilliseconds(3 * 1000),
				messageEncoder: new ASCII_MessageEncoder(4),
				messageResponseTimeout: TimeSpan.FromMilliseconds(150),
				certInfo: certInfo
			);

			// WCF integration docs are at:
			// https://autofac.readthedocs.io/en/latest/integration/wcf.html
			var builder = new ContainerBuilder();

			// Register your service implementations.
			builder.RegisterType<Test001Service>();
			builder.RegisterType<Test001ServiceSync>();

			// Register your dependencies.

			// Shared Gateway Service

			var clientPoolCreator = ClientPool2<IMessageClient>.ClientPoolCreator;
			var messageClientCreator = MessageClient.MessageClientCreator;
			var clientPool = clientPoolCreator(clientPoolSettings, messageClientCreator);
			var managedClientCreator = ManagedClient<IMessageClient>.ManagedClientCreator;
			IGateway<IMessageClient> gateway = new Gateway<IMessageClient>(clientPool, managedClientCreator);
			builder.RegisterInstance(gateway).As<IGateway<IMessageClient>>().SingleInstance();

			// Set the dependency resolver. This works for both regular WCF services and REST-enabled services.
			var container = builder.Build();
			AutofacHostFactory.Container = container;

			//var gw = container.Resolve<IGateway<IMessageClient>>();
			//System.Diagnostics.Debug.Assert(gw != null);
		}

		protected void Session_Start(object sender, EventArgs e)
		{

		}

		protected void Application_BeginRequest(object sender, EventArgs e)
		{

		}

		protected void Application_AuthenticateRequest(object sender, EventArgs e)
		{

		}

		protected void Application_Error(object sender, EventArgs e)
		{

		}

		protected void Session_End(object sender, EventArgs e)
		{

		}

		protected void Application_End(object sender, EventArgs e)
		{
			// TODO: Dispose AutofacHostFactory.Container

			//var container = AutofacHostFactory.Container;

			//var gw = container.Resolve<IGateway<IMessageClient>>();
			//gw.Dispose();

		}
	}
}