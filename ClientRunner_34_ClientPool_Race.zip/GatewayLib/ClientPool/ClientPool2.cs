﻿#define CHECK_FOR_DISPOSED_CLIENTS
#define CHECK_FOR_REGISTERED_CLIENTS

using GatewayLib.Gateway;
using GatewayLib.Tcp;
using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Linq;
using System.Net;
using System.Threading;
using System.Threading.Tasks;
using TcpProtocolLib;

namespace GatewayLib.ClientPool
{
	public class ClientPool2<T> : IClientPool<T>, IDisposable where T : class, IMessageClient
	{
		#region Private Properties

		private readonly CertInfo _certInfo;
		private readonly IList<IPooledClient> _allClients;
		private readonly Queue<T> _pool;
		private readonly LinkedList<TcsPlus> _waiters;

		private int NumberAllocated;
		private int NumberFree;
		private string FreeAllocatedPhrase => $"free: {NumberFree}, allocated: {NumberAllocated}";

		private int NumberCreated;
		private int NumberDestroyed;
		private int NumberOfRequests;
		private int NumberOfHits;

		private int NumberOfGetClientTimeouts;

		private int NumberOfReturns;
		private int NumberOfDiscards;
		private int NumberOfPoolAdds;

		private readonly CreateMessageClient _clientCreator;
		private readonly ReaderWriterLockSlim _locker;

		private readonly bool _useDetailedDebug = true;
		//private readonly bool _reportTimeToAllocateClient = false;

		private static int _poolInstanceCounter = 0;

		#endregion

		#region Constructor

		public ClientPool2(ClientPoolSettings clientPoolSettings, CreateMessageClient clientCreator)
		{
			InstanceId = _poolInstanceCounter++;

			ServerEndPoint = clientPoolSettings.ServerEndPoint;
			MinClients = clientPoolSettings.MinConnections;
			MaxClients = clientPoolSettings.MaxConnections;
			AllocateClientTimeout = clientPoolSettings.AllocateClientTimeout;
			MessageEncoder = clientPoolSettings.MessageEncoder;
			MessageResponseTimeout = clientPoolSettings.MessageResponseTimeout;
			_certInfo = clientPoolSettings.CertInfo;

			_clientCreator = clientCreator;

			_allClients = new List<IPooledClient>();
			_pool = new Queue<T>();
			_waiters = new LinkedList<TcsPlus>();

			NumberAllocated = 0;

			_locker = new ReaderWriterLockSlim();

			PollForFreeClientDuration = TimeSpan.FromMilliseconds(DEFAULT_POLL_FOR_FREE_CLIENT_DURATION_MS);
			MinimumInactivityDuration = TimeSpan.FromMilliseconds(DEFAULT_MINIMUM_INACTIVITY_DURATION_MS);

			string valMsg = ValidateGetClientTimeout(AllocateClientTimeout, PollForFreeClientDuration);
			if (valMsg != null)
			{
				throw new ArgumentException(valMsg);
			}

			FillPool(MinClients);
			Debug.WriteLine($"ClientPool created, {FreeAllocatedPhrase}.");
		}

		#endregion

		#region Public Properties

		public static CreateClientPool<T> ClientPoolCreator => (ClientPoolSettings clientPoolSettings, CreateMessageClient clientCreator)
			=> new ClientPool2<T>(clientPoolSettings, clientCreator);

		public TimeSpan AllocateClientTimeout { get; private set; }
		public TimeSpan PollForFreeClientDuration { get; private set; }
		public TimeSpan MinimumInactivityDuration { get; private set; }

		public const int DEFAULT_POLL_FOR_FREE_CLIENT_DURATION_MS = 20;
		public const int DEFAULT_MINIMUM_INACTIVITY_DURATION_MS = 2500;

		public int InstanceId { get; }

		public readonly IPEndPoint ServerEndPoint;
		public readonly int MinClients;
		public readonly int MaxClients;
		public readonly IMessageEncoder MessageEncoder;
		public readonly TimeSpan MessageResponseTimeout;

		public bool IsClosed
		{
			get
			{
				_locker.EnterReadLock();
				try
				{
					return disposedValue;
				}
				finally
				{
					_locker.ExitReadLock();
				}
			}
		}

		#endregion

		#region Public Methods -- Read Only
		
		public PoolStats GetPoolStats()
		{
			_locker.EnterReadLock(); // Keep writers out while making the copy.
			try
			{
				return GetPoolStatsInternal();
			}
			finally
			{
				_locker.ExitReadLock();
			}
		}

		public IList<IPooledClient> GetAllClients()
		{
			_locker.EnterReadLock(); // Keep writers out while making the copy.
			try
			{
				List<IPooledClient> result = _allClients.AsEnumerable().ToList();
				return result;
			}
			finally
			{
				_locker.ExitReadLock();
			}
		}

		#endregion

		#region Public Methods -- Can Change State

		public T GetClient(string opId)
		{
			T client = Task.Run(() => GetClientAsync(opId)).GetAwaiter().GetResult();
			return client;
		}

		public async Task<T> GetClientAsync(string opId)
		{
			return await GetClientAsync(null, opId);
		}

		// Throws GatewayException,	ErrorCode = Timeout, ClientPoolIsDisposed, or Other.
		public async Task<T> GetClientAsync(T clientToReturn, string opId)
		{
			if (IsClosed)
			{
				if (clientToReturn != null)
				{
					ReturnClient(clientToReturn, opId);
				}
				throw new GatewayException(GatewayOperationEnum.GetClientFromPool, GatewayError.ClientPoolIsDisposed);
			}

			Thread requestingThread = Thread.CurrentThread;
			Stopwatch s = null;
			PoolStats t0 = null;
			PoolStatPair pr = null;

			T client;
			bool requestSatisfiedImmediately;
			TcsPlus tcs = null;

			_locker.EnterUpgradeableReadLock();
			try
			{
				NumberOfRequests++;

				t0 = GetPoolStatsInternal();

				if (clientToReturn != null)
				{
					ReturnClient(clientToReturn, opId);
				}

				s = Stopwatch.StartNew();

				requestSatisfiedImmediately = TrySatisfyRequestImmediately(out client, opId);
				if (requestSatisfiedImmediately)
				{
					s.Stop();
				}
				else
				{
					tcs = new TcsPlus(opId);
					_waiters.AddLast(tcs);
				}
			}
			catch (Exception e)
			{
				throw new GatewayException("Unexpected Exception occured while retrieving a client.", GatewayOperationEnum.GetClientFromPool, GatewayError.Other, e);
			}
			finally
			{
				_locker.ExitUpgradeableReadLock();
			}

			if (!requestSatisfiedImmediately)
			{
				Debug.Assert(tcs != null, "tcs is null");
				if (_useDetailedDebug) Debug.WriteLine($"Thread {Thread.CurrentThread.ManagedThreadId} is waiting on the FreeClientQ - AAResetEvent to become signaled or timed-out at {GetTime()}. {opId}");

				Task winner = await Task.WhenAny(tcs.Task, Task.Delay(AllocateClientTimeout, CancellationToken.None));
				Debug.Assert(opId == tcs.OpId, "The OpIds don't match.");

				_locker.EnterUpgradeableReadLock();
				try
				{
					if (winner == tcs.Task)
					{
						// The task was signaled.
						if (_useDetailedDebug) Debug.WriteLine($"FreeClientQ - AAResetEvent is returning true because we were signaled, using Thread: {Thread.CurrentThread.ManagedThreadId} at {GetTime()}. {GetSignaledInfo()}. {opId}");
						client = tcs.Client;
						Debug.Assert(client != null, "the client is null after the tcs task completed.");
					}
					else
					{
						// We timed-out; remove our reference to the task.
						if (tcs.Result == true)
						{
							// Set has been called after Task.Delay completed, but before we could take the lock.
							if (_useDetailedDebug) Debug.WriteLine($"FreeClientQ - AAResetEvent is returning true after timeout, using the Delay Thread: {Thread.CurrentThread.ManagedThreadId} at {GetTime()}. {GetSignaledInfo()}. {opId}");
							client = tcs.Client;
							Debug.Assert(client != null, "the client is null after the tcs task completed.");
						}
						else
						{
							bool removed = _waiters.Remove(tcs);
							if (!removed)
							{
								Debug.WriteLine("FreeClientQ - WARNING Tcs was not removed from the List of waiters.");
							}
							Debug.Assert(removed);
							if (_useDetailedDebug) Debug.WriteLine($"FreeClientQ - AAResetEvent is returning false after timeout, using the Delay Thread: {Thread.CurrentThread.ManagedThreadId} at {GetTime()}. {GetSignaledInfo()}. {opId}");

							client = null;
						}
					}
				}
				finally
				{
					_locker.ExitUpgradeableReadLock();
				}
			}
			else
			{
				Debug.Assert(client != null, "The client is null, but requestSatisfiedImmediately is true.");
			}

			_locker.EnterReadLock();
			try
			{
				var continueThread = Thread.CurrentThread;
				string threadInfo = (continueThread.ManagedThreadId != requestingThread.ManagedThreadId) ? $"ThreadInfo: Call made on {requestingThread.ManagedThreadId}, continuing on {continueThread.ManagedThreadId}." : null;

				string ems = null;
				if (s != null)
				{
					s.Stop();
					ems = s.ElapsedMilliseconds.ToString("F4");
				}

				if (t0 != null)
				{
					PoolStats t1 = GetPoolStatsInternal();
					pr = new PoolStatPair(t0, t1);
				}

				if (client == null)
				{
					Debug.WriteLine($"ClientPool::GetClient waited {ems} but was unable to provide a client. PoolStatDiff: {pr}. {threadInfo}");
					Interlocked.Increment(ref NumberOfGetClientTimeouts);
					throw new GatewayException(GatewayOperationEnum.GetClientFromPool, GatewayError.Timeout);
				}
				else
				{
					CheckClientDisposed(client, "Just provided by GetClientAsync.", true);
					CheckIsClientRegistered(client, "Just provided by GetClientAsync.");
					client.LastProvidedDate = DateTime.Now;
					client.ProvidedCount++;

					NumberOfHits++;

					Debug.WriteLine($"ClientPool::GetClient provided client: {client.Identifier} in {ems} milliseconds. PoolStatDiff: {pr}. {threadInfo}");
					return client;
				}
			}
			finally
			{
				_locker.ExitReadLock();
			}
		}

		#endregion

		#region Private Methods

		private bool TrySatisfyRequestImmediately(out T client, string opId)
		{
			client = null;
			bool result;

			if (_waiters.Count > 0)
			{
				// Other requestors are waiting for a client to become free, this requestor must "get in line."
				result = false;
			}
			else
			{
				result = TryGetClientNoWait(out client, opId);
			}

			return result;
		}

		private bool TryGetClientNoWait(out T client, string opId)
		{
			if (TryTakeConnectedClient(out client, opId))
			{
				// Found an available client, remove it from the pool and return it the caller.
				if (_useDetailedDebug) Debug.WriteLine($"ClientPool retrieved an existing client: {client.Identifier}, {FreeAllocatedPhrase}. {opId}");
				return true;
			}

			if (TryAddNewClient(out client))
			{
				// Added a new client, return it to the caller.
				if (_useDetailedDebug) Debug.WriteLine($"ClientPool had less than {MaxClients}. Created a brand new client. {FreeAllocatedPhrase}. {opId}");
				return true;
			}

			return false;
		}

		private bool TryTakeConnectedClient(out T client, string opId)
		{
			client = null;
			bool result = false;

			T testClient;
			bool connectedClientFound = false;
			bool clientFound;

			_locker.EnterWriteLock();

			try
			{
				if (disposedValue) return false;

				do
				{
					if (_pool.Count > 0)
					{
						testClient = _pool.Dequeue();
						clientFound = true;
					}
					else
					{
						testClient = null;
						clientFound = false;
					}

					if (clientFound)
					{
						NumberFree--;

						bool clientIsDisposed = IsClientDisposed(testClient, out string id);
						if (clientIsDisposed) Debug.WriteLine($"We must be in the process of being disposed. {opId}");
						if (clientIsDisposed || !testClient.IsConnected)
						{
							DiscardClient(testClient, id, true, opId);
						}
						else
						{
							client = testClient;
							connectedClientFound = true;
							result = true;
						}
					}
				}
				while (clientFound && !connectedClientFound);
			}
			finally
			{
				_locker.ExitWriteLock();
			}

			return result;
		}

		private bool TryAddNewClient(out T client)
		{
			client = null;

			if (NumberAllocated < MaxClients)
			{
				_locker.EnterWriteLock();
				try
				{
					if (disposedValue) return false;
					client = (T)_clientCreator(ServerEndPoint, MessageEncoder, MessageResponseTimeout, _certInfo);

					_allClients.Add(client);
					NumberAllocated++;
					NumberCreated++;
				}
				finally
				{
					_locker.ExitWriteLock();
				}
				return true;
			}
			else
			{
				return false;
			}
		}

		public void ReturnClient(T client, string opId)
		{
			if (client == null) return;

			CheckIsClientRegistered(client, $"PoolRequestProcessor handling a return {opId}.");
			bool clientIsDisposed = IsClientDisposed(client, out string id);

			bool clientWasDiscarded;
			TcsPlus waiter = null;

			_locker.EnterWriteLock();
			try
			{
				if (disposedValue)
				{
					if (!clientIsDisposed) client.Dispose();
					return;
				}

				NumberOfReturns++;

				if (clientIsDisposed || client.IsClosed)
				{
					Debug.WriteLine($"ClientPool is discarding {id}. The Client's Tcp connection is closed. {opId}");
					DiscardClient(client, id, clientIsDisposed, opId);
					clientWasDiscarded = true;
				}
				else if (ShouldClientBeDiscarded(client, NumberAllocated, MinClients, MinimumInactivityDuration))
				{
					double secondsSinceLastUse = (DateTime.Now - client.LastUsedDate).TotalSeconds;
					Debug.WriteLine($"ClientPool is discarding {id}. Client has not been used in {secondsSinceLastUse} seconds and we are {NumberAllocated - MinClients} over the minimum of {MinClients}, {FreeAllocatedPhrase}. {opId}");
					DiscardClient(client, id, clientIsDisposed, opId);
					clientWasDiscarded = true;
				}
				else
				{
					if (_useDetailedDebug) Debug.WriteLine($"ClientPool is returning {id}. {FreeAllocatedPhrase}, Client used for {(DateTime.Now - client.LastFreedDate).TotalSeconds} seconds. {opId}");
					client.LastFreedDate = DateTime.Now;
					client.FreedCount++;
					clientWasDiscarded = false;
				}

				if(_waiters.Count > 0)
				{
					waiter = _waiters.First.Value;
					_waiters.RemoveFirst();
					waiter.Result = true;

					if (clientWasDiscarded)
					{
						// Create a new client so that we can satisfy the pending waiting request.
						T newClient = (T)_clientCreator(ServerEndPoint, MessageEncoder, MessageResponseTimeout, _certInfo);
						_allClients.Add(newClient);
						waiter.Client = newClient;
						NumberCreated++;
						NumberAllocated++;
					}
					else
					{
						waiter.Client = client;
					}
				}
				else
				{
					if (!clientWasDiscarded)
					{
						_pool.Enqueue(client);
						NumberFree++;
						NumberOfPoolAdds++;
					}
				}
			}
			finally
			{
				_locker.ExitWriteLock();
			}

			if (waiter != null)
			{
				try
				{
					waiter.Tcs.SetResult(true);
				}
				catch (Exception e)
				{
					Debug.WriteLine($"The client pool could not set the waiter's result. The exception is {e.GetType()}:{e.Message} {opId}");
				}
			}
		}

		private void DiscardClient(T client, string id, bool clientIsDisposed, string opId)
		{
			_allClients.Remove(client);
			NumberOfDiscards++;
			NumberDestroyed++;
			NumberAllocated--;

			if (_useDetailedDebug) Debug.WriteLine($"ClientPool has removed {id}, {FreeAllocatedPhrase} {opId}.");

			if (!clientIsDisposed)
				client.Dispose();
		}

		private void FillPool(int size)
		{
			_locker.EnterWriteLock();
			try
			{
				if (disposedValue) return;
				while (_allClients.Count < size)
				{
					T client = (T)_clientCreator(ServerEndPoint, MessageEncoder, MessageResponseTimeout, _certInfo);

					_allClients.Add(client);
					NumberCreated++;
					NumberAllocated++;

					_pool.Enqueue(client);
					NumberFree++;
					NumberOfPoolAdds++;
				}
			}
			finally
			{
				_locker.ExitWriteLock();
			}
		}

		private bool ShouldClientBeDiscarded(IPooledClient client, int numberAllocated, int minimumClients, TimeSpan minimumInactivityDuration)
		{
			bool result;

			if (numberAllocated > minimumClients)
			{
				result = DateTime.Now - client.LastUsedDate > minimumInactivityDuration;
			}
			else
			{
				result = false;
			}

			return result;
		}

		private PoolStats GetPoolStatsInternal()
		{
			return PoolStatHelper.GetPoolStats(NumberAllocated, NumberFree,
			NumberCreated, NumberDestroyed,
			NumberOfRequests, NumberOfHits,
			NumberOfReturns, NumberOfDiscards,
			NumberOfPoolAdds, _allClients.AsEnumerable().ToList());
		}

		#endregion

		#region Checks and Helpers

		[Conditional("CHECK_FOR_DISPOSED_CLIENTS")]
		private void CheckClientDisposed(IPooledClient client, string context, bool throwWhenDisposed)
		{
			try
			{
				string _ = client.Identifier;
			}
			catch (ObjectDisposedException)
			{
				Debug.WriteLine($"WARNING: The pooled client has already been disposed. Context={context}");
				if (throwWhenDisposed) throw;
			}
		}
		
		private bool IsClientDisposed(IPooledClient client, out string id)
		{
			try
			{
				id = client?.Identifier ?? "client is null";
				return false;
			}
			catch (ObjectDisposedException)
			{
				id = "disposed";
				return true;
			}
		}

		[Conditional("CHECK_FOR_REGISTERED_CLIENTS")]
		private void CheckIsClientRegistered(IPooledClient client, string context)
		{
			string id = "disposed";
			try
			{
				id = client.Identifier;
			}
			catch (ObjectDisposedException) { }

			if (!_allClients.Contains(client))
				Debug.WriteLine($"WARNING: The client: {id} is not being managed from this pool. Context={context}");
		}

		private string ValidateGetClientTimeout(TimeSpan timeout, TimeSpan pollForFreeClientDuration)
		{
			// The duration to wait for a client to become available must be at least 4 times the poll duration.
			const double factor = 4;
			double maxPollDuration = timeout.TotalMilliseconds / factor;

			if (pollForFreeClientDuration.TotalMilliseconds > maxPollDuration)
			{
				return $"The GetClientTimeout must be at least {factor} times as long as the PollForFreeClientDuration.";
			}
			else
			{
				return null;
			}
		}

		#endregion

		#region IDisposable Support

		private void Clear()
		{
			int free = _pool.Count();
			int total = _allClients.Count;

			if (free != total)
			{
				Debug.WriteLine($"Warning: There are {total - free} clients that not been returned to the pool. There are only {free} free clients out of {total}, total.");
			}

			// Remove all items from the blocking collection.
			NumberFree -= free;
			_pool.Clear();

			foreach (IPooledClient client in _allClients)
			{
				try
				{
					client.Dispose();
				}
				catch (ObjectDisposedException)
				{
					// ignore
				}
			}

			NumberDestroyed += total;
			_allClients.Clear();
		}

		private bool disposedValue = false; // To detect redundant calls

		protected virtual void Dispose(bool disposing)
		{
			if (!disposedValue)
			{
				if (disposing)
				{
					// Dispose managed state (managed objects).
					_locker.EnterWriteLock();
					try
					{
						//StopBackgroundProcessor();
						Clear();
						//_pool.Dispose();
					}
					finally
					{
						disposedValue = true;
						_locker.ExitWriteLock();
						//_locker.Dispose();
					}
				}
			}
		}

		public void Dispose()
		{
			Dispose(true);
		}

		#endregion

		#region Async Support

		private string GetSignaledInfo()
		{
			return $"Waiters: {_waiters.Count}";
		}

		private string GetTime()
		{
			string t = DateTime.Now.ToString("HH:mm:ss:fff").Substring(3);
			return t;
		}

		class TcsPlus
		{
			public TaskCompletionSource<bool> Tcs;
			public bool? Result { get; set; }
			public T Client { get; set; }

			public string OpId { get; }

			public Task<bool> Task => Tcs.Task;

			public TcsPlus(string opId)
			{
				Tcs = new TaskCompletionSource<bool>(TaskCreationOptions.RunContinuationsAsynchronously);
				Result = null;
				Client = null;
				OpId = opId;
			}
		}

		#endregion
	}
}
