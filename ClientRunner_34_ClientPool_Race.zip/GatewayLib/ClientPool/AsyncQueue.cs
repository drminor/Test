﻿using GatewayLib.Tcp;
using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Threading;
using System.Threading.Tasks;

namespace GatewayLib.ClientPool
{
	public class AsyncQueue<T> where T : class, IMessageClient
	{
		private readonly LinkedList<TcsPlus> _waiters;

		private readonly Queue<T> _clients;
		private bool _isSignaled;

		private readonly bool _useDetailedDebug;

		private readonly object _stateLock = new object();

		public AsyncQueue()
		{
			_waiters = new LinkedList<TcsPlus>();
			_isSignaled = false;
			_clients = new Queue<T>();

			_useDetailedDebug = true;
		}

		public int Count()
		{
			lock (_stateLock)
			{
				return _clients.Count;
			}
		}

		public void Enqueue(T client)
		{
			lock (_stateLock)
			{
				if (client != null)
				{
					_clients.Enqueue(client);
				}

				TcsPlus waiter = Set();

				if (waiter != null)
				{
					CompleteTcs(waiter);
				}
			}
		}

		public void Clear()
		{
			lock (_stateLock)
			{
				_waiters.Clear();
				_clients.Clear();
				_isSignaled = false;
			}
		}

		public Task<T> WaitForClient(TimeSpan timeout, string opId)
		{
			return WaitAsync(timeout, CancellationToken.None, opId);
		}

		private async Task<T> WaitAsync(TimeSpan timeout, CancellationToken cancellationToken, string opId)
		{
			TcsPlus tcs;

			lock (_stateLock)
			{
				if (_useDetailedDebug) Debug.WriteLine($"FreeClientQ - at start wait: {GetSignaledInfo(useLock: false)}. {opId}");

				if (_isSignaled)
				{
					_isSignaled = false;
					return GetResult(_clients);
				}

				if (timeout == TimeSpan.Zero)
				{
					return null;
				}
				else
				{
					tcs = new TcsPlus(opId);
					//_waiter = tcs;
					_waiters.AddLast(tcs);
				}
			}

			if(_useDetailedDebug) Debug.WriteLine($"Thread {Thread.CurrentThread.ManagedThreadId} is waiting on the FreeClientQ - AAResetEvent to become signaled or timed-out at {GetTime()}. {opId}");

			Task winner = await Task.WhenAny(tcs.Task, Task.Delay(timeout, cancellationToken));

			lock (_stateLock)
			{
				if (winner == tcs.Task)
				{
					// The task was signaled.
					if (_useDetailedDebug) Debug.WriteLine($"FreeClientQ - AAResetEvent is returning true because we were signaled, using Thread: {Thread.CurrentThread.ManagedThreadId} at {GetTime()}. {GetSignaledInfo(useLock: true)}. {opId}");

					return GetResult(_clients);
				}
				else
				{
					// We timed-out; remove our reference to the task.
					if (tcs.Result == true)
					{
						// Set has been called after Task.Delay completed, but before we could take the lock.

						if (_useDetailedDebug) Debug.WriteLine($"FreeClientQ - AAResetEvent is returning true after timeout, using the Delay Thread: {Thread.CurrentThread.ManagedThreadId} at {GetTime()}. {GetSignaledInfo(useLock: false)}. {opId}");

						//Debug.Assert(_clients.Count > 0, "FreeClientQ - The TcsPlus result was set to true, but we have no messagees.");

						return GetResult(_clients);
					}
					else
					{
						//if (_waiter == null)
						//{
						//	Debug.WriteLine($"WARNING FreeClientQ - _waiter was null on timeout at {GetTime()} {opId}.");
						//}
						//_waiter = null;
						bool removed = _waiters.Remove(tcs);
						if (!removed)
						{
							Debug.WriteLine("FreeClientQ - WARNING Tcs was not removed from the LList of waiters.");
						}
						Debug.Assert(removed);
						if (_useDetailedDebug) Debug.WriteLine($"FreeClientQ - AAResetEvent is returning false after timeout, using the Delay Thread: {Thread.CurrentThread.ManagedThreadId} at {GetTime()}. {GetSignaledInfo(useLock: false)}. {opId}");

						throw new TimeoutException();
					}
				}
			}
		}

		private T GetResult(Queue<T> clients)
		{
			if(clients.Count > 0)
			{
				return clients.Dequeue();
			}
			else
			{
				return null;
			}
		}

		private TcsPlus Set()
		{
			TcsPlus waiter;

			lock (_stateLock)
			{
				if (_useDetailedDebug) Debug.WriteLine($"FreeClientQ - at set: {GetSignaledInfo(useLock: false)}");

				//if (_waiter != null)
				//{
				//	// Signal the first task in the waiters list. This must be done on a new
				//	// thread to avoid stack-dives and situations where we try to complete the
				//	// same result multiple times.

				//	result = _waiter;
				//	result.Result = true;
				//	_waiter = null;
				//}

				if (_waiters.Count > 0)
				{
					// Signal the first task in the waiters list. This must be done on a new
					// thread to avoid stack-dives and situations where we try to complete the
					// same result multiple times.

					waiter = _waiters.First.Value;
					waiter.Result = true;
					_waiters.RemoveFirst();
				}
				else
				{
					// No tasks are pending
					waiter = null;

					if (!_isSignaled)
					{
						_isSignaled = true;
					}
				}
			}

			return waiter;
		}

		private void CompleteTcs(TcsPlus waiter)
		{

			//tcs.Tcs.TrySetResult(true);

			try
			{
				waiter.Tcs.SetResult(true);
			}
			catch (InvalidOperationException)
			{
				throw new InvalidOperationException($"FreeClientQ wait task has already completed. SetResult failed. {waiter.OpId}");
			}
			catch (Exception e)
			{
				Debug.WriteLine($"FreeClientQ could not complete the task, received exception {e.GetType()}: {e.Message}. {waiter.OpId}");
			}

			//// TODO: Make sure that we must use a task instead of just calling TrySetResult directly.
			//// TODO: Make sure that we must use TrySetResult instead of SetResult.

			//var callingThread = Thread.CurrentThread;
			//Task.Factory.StartNew(s =>
			//{
			//	TcsPlus insideTcs = (TcsPlus)s;
			//	if (_useDetailedDebug) Debug.WriteLine($"Thread: {callingThread.ManagedThreadId} is setting the IMessage Client's AAResetEvent, using runner Thread: {Thread.CurrentThread.ManagedThreadId} and then waiting at {GetTime()}. {insideTcs.OpId}");

			//	bool succ = insideTcs.Tcs.TrySetResult(true);

			//	if (!succ) Debug.WriteLine($"Could not set the result of the TCS at {GetTime()}. {insideTcs.OpId}");
			//}
			//	, tcs, CancellationToken.None, TaskCreationOptions.PreferFairness, TaskScheduler.Default
			//);

			//// TODO: Make sure that we do not have to wait for the task to return
			//tcs.Task.Wait();
			//Debug.WriteLine($"IMessage Client's AAREvent Runner thread returned. {tcs.OpId}");
		}

		private string GetSignaledInfo(bool useLock)
		{
			if(useLock)
			{
				lock (_stateLock)
				{
					return $"Signaled: {_isSignaled}, Waiters: {_waiters.Count}";
				}
			}
			else
			{
				return $"Signaled: {_isSignaled}, Waiters: {_waiters.Count}";
			}
		}

		private string GetTime()
		{
			string t = DateTime.Now.ToString("HH:mm:ss:fff").Substring(3);
			return t;
		}

		class TcsPlus
		{
			public TaskCompletionSource<bool> Tcs;
			public bool? Result { get; set; }

			public string OpId { get; }

			public Task<bool> Task => Tcs.Task;

			public TcsPlus(string opId)
			{
				Tcs = new TaskCompletionSource<bool>(TaskCreationOptions.RunContinuationsAsynchronously);
				Result = null;
				OpId = opId;
			}
		}

	}
}
