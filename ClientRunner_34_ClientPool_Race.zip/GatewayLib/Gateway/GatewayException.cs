﻿using System;
using System.Text;

namespace GatewayLib.Gateway
{
	public class GatewayException : Exception
	{
		public readonly GatewayOperationEnum Operation;
		public readonly GatewayError ErrorCode;

		public GatewayException(GatewayOperationEnum operation, Exception innnerException) : this(MessageFromOperation(operation), operation, innnerException)
		{
		}

		public GatewayException(string message, GatewayOperationEnum operation) : this(message, operation, null)
		{
		}

		public GatewayException(string message, GatewayOperationEnum operation, Exception innerException) : this(message, operation, GatewayError.Other, innerException)
		{
		}

		// With ErrorCode
		public GatewayException(GatewayOperationEnum operation, GatewayError errorCode) : this(MessageFromOperation(operation), operation, errorCode, null)
		{
		}

		public GatewayException(string message, GatewayOperationEnum operation, GatewayError errorCode) : this(message, operation, errorCode, null)
		{
		}

		public GatewayException(string message, GatewayOperationEnum operation, GatewayError errorCode, Exception innerException) : base(message, innerException)
		{
			Operation = operation;
			ErrorCode = errorCode;
		}

		public override string ToString()
		{
			StringBuilder sb = new StringBuilder();

			sb.Append($"SendRequestException: {Message}, op:{Operation}, ErrorCode: {ErrorCode}");

			if (InnerException != null)
			{
				Type inExType = InnerException.GetType();
				sb.Append($" with {inExType}: {InnerException.Message}");
			}

			return sb.ToString();
		}

		static string MessageFromOperation(GatewayOperationEnum operation)
		{
			return $"{operation}, see InnerException for details.";
		}
	}
}
