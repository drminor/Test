﻿using System;

namespace TcpServerConsole
{
	public interface IReceiver : IDisposable
	{
		bool IsConnected { get; }
		DateTime LastCalled { get; }

		void Start();
	}
}
