﻿using System;
using System.Diagnostics;
using System.IO;
using System.Text;
using System.Xml.Serialization;

namespace AppProtocolLib.TcpServerControl
{
	public class TcpServerControlRequest : IFixedWidthMessage<TcpServerControlRequest>
	{
		public static ColumnDictionary _columnDefinitions;

		static TcpServerControlRequest()
		{
			_columnDefinitions = new ColumnDictionary();
			_columnDefinitions
				.AddColumnDefinition(nameof(DateCreated), 20)
				.AddColumnDefinition(nameof(Command), 20)
				.AddColumnDefinition(nameof(Key), 20)
				.AddColumnDefinition(nameof(Settings), 500)
				.AddColumnDefinition(nameof(CorrelationId), 40);
		}

		public string MessageName => nameof(TcpServerControlRequest);

		public IColumnDictionary ColumnDefinitions => _columnDefinitions;

		public DateTime DateCreated;
		public string Command;
		public string Key;
		public TcpServerSettings Settings;
		public string CorrelationId { get; set; }

		public TcpServerControlRequest()
		{
			DateCreated = DateTime.Now;
			CorrelationId = Guid.NewGuid().ToString();
		}

		public TcpServerControlRequest(string command, string key, TcpServerSettings settings)
		{
			CheckArgument(command, nameof(Command));
			CheckArgument(key, nameof(Key));
			DateCreated = DateTime.Now;
			Command = command;
			Key = key;
			Settings = settings;
			CorrelationId = Guid.NewGuid().ToString();
		}

		private void CheckArgument(string argument, string name)
		{
			if(argument == null)
			{
				throw new ArgumentNullException(name);
			}

			int len = GetLength(name);
			if(argument.Length > len)
			{
				throw new ArgumentException($"{name} must be {len} characters or shorter.", name);
			}
		}

		public string ToMessage()
		{
			StringBuilder sb = new StringBuilder();

			sb.Append(DateCreated.ToLongTimeString().PadRight(GetLength(nameof(DateCreated))));
			sb.Append(Command.PadRight(GetLength(nameof(Command))));
			sb.Append(Key.PadRight(GetLength(nameof(Key))));
			string s = Serialize(Settings);
			sb.Append(s.PadRight(GetLength(nameof(Settings))));
			sb.Append(CorrelationId.PadRight(GetLength(nameof(CorrelationId))));

			return sb.ToString();
		}

		public static TcpServerControlRequest CreateNewFromMessage(string m)
		{
			TcpServerControlRequest result = new TcpServerControlRequest();

			ColumnDefinition cd = _columnDefinitions[nameof(DateCreated)];
			result.DateCreated = DateTime.Parse(m.Substring(cd.Start, cd.Length));

			cd = _columnDefinitions[nameof(Command)];
			result.Command = m.Substring(cd.Start, cd.Length).TrimEnd();

			cd = _columnDefinitions[nameof(Key)];
			result.Key = m.Substring(cd.Start, cd.Length).TrimEnd();

			cd = _columnDefinitions[nameof(Settings)];
			string strSettings = m.Substring(cd.Start, cd.Length);
			result.Settings = GetSettings(strSettings);

			cd = _columnDefinitions[nameof(CorrelationId)];
			result.CorrelationId = m.Substring(cd.Start, cd.Length).TrimEnd();

			return result;
		}

		public static TcpServerSettings GetSettings(string s)
		{
			TextReader tr = new StringReader(s);
			XmlSerializer serializer = new XmlSerializer(typeof(TcpServerSettings));

			try
			{
				TcpServerSettings result = (TcpServerSettings)serializer.Deserialize(tr);
				return result;
			}
			catch (Exception e)
			{
				Debug.WriteLine($"Exception thrown while deserializing a TcpServerSettings object. {e.GetType()} : {e.Message}.");
				throw;
			}
		}

		public string Serialize(TcpServerSettings settings)
		{
			XmlSerializer serializer = new XmlSerializer(typeof(TcpServerSettings));

			using (TextWriter tw = new StringWriter(new StringBuilder()))
			{
				serializer.Serialize(tw, settings);
				string result = tw.ToString();
				return result;
			}
		}

		private int GetLength(string columnName)
		{
			int length = _columnDefinitions[columnName].Length;
			return length;
		}

	}
}
