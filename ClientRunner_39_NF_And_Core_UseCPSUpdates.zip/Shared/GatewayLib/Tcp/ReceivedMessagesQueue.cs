﻿using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Linq;
using System.Threading;
using System.Threading.Tasks;

namespace GatewayLib.Tcp
{
	public class ReceivedMessagesQueue
	{
		private TcsPlus _waiter;
		private readonly Queue<MessageWithTimestamp> _receivedMessages;
		private bool _isSignaled;

		private readonly bool _useDetailedDebug;

		private readonly object _stateLock = new object();

		public ReceivedMessagesQueue()
		{
			_waiter = null;
			_isSignaled = false;
			_receivedMessages = new Queue<MessageWithTimestamp>();

			_useDetailedDebug = false;
		}

		public void Enqueue(MessageWithTimestamp mwts)
		{
			lock (_stateLock)
			{
				_receivedMessages.Enqueue(mwts);
				TcsPlus waiter = Set();

				if (waiter != null)
				{
					CompleteTcs(waiter);
				}
			}
		}

		public IList<MessageWithTimestamp> DequeueAll()
		{
			List<MessageWithTimestamp> result;

			lock (_stateLock)
			{
				if (_receivedMessages.Count > 0)
				{
					result = new List<MessageWithTimestamp>();
					while (_receivedMessages.Count > 0)
					{
						MessageWithTimestamp mwts = _receivedMessages.Dequeue();
						result.Add(mwts);
					};

					_isSignaled = false;
				}
				else
				{
					result = null;
				}

				Debug.Assert(!_isSignaled, "DequeueAll completed, but we are still signaled.");
			}

			return result;
		}

		public Task<bool> WaitForMessage(TimeSpan timeout, string correlationId, CorrelationIdInfo correlationIdInfo, string opId)
		{
			return WaitAsync(timeout, CancellationToken.None, correlationId, correlationIdInfo, opId);
		}

		private async Task<bool> WaitAsync(TimeSpan timeout, CancellationToken cancellationToken, string correlationId, CorrelationIdInfo correlationIdInfo, string opId)
		{
			TcsPlus tcs;

			lock (_stateLock)
			{
				if (_useDetailedDebug) Debug.WriteLine($"At start wait: {GetSignaledInfo(useLock: false)}. {opId}");

				if (_isSignaled)
				{
					_isSignaled = false;
					return ShouldWeSignal(correlationId, correlationIdInfo);
				}

				if (timeout == TimeSpan.Zero)
				{
					return false;
				}
				else
				{
					Debug.Assert(_waiter == null, "Another caller is waiting on ReceivedMessagesQueue.");
					tcs = new TcsPlus(correlationId, correlationIdInfo, opId);
					_waiter = tcs;
				}
			}

			if(_useDetailedDebug) Debug.WriteLine($"Thread {Thread.CurrentThread.ManagedThreadId} is waiting on the AAResetEvent to become signaled or timed-out at {GetTime()}. {opId}");

			Task winner = await Task.WhenAny(tcs.Task, Task.Delay(timeout, cancellationToken));

			lock (_stateLock)
			{
				if (winner == tcs.Task)
				{
					// The task was signaled.
					if (_useDetailedDebug) Debug.WriteLine($"AAResetEvent is returning true because we were signaled, using Thread: {Thread.CurrentThread.ManagedThreadId} at {GetTime()}. {GetSignaledInfo(useLock: true)}. {opId}");

					return ShouldWeSignal(tcs.CorrelationId, tcs.CorrelationIdInfo);
				}
				else
				{
					// We timed-out; remove our reference to the task.
					if (tcs.Result == true)
					{
						// Set has been called after Task.Delay completed, but before we could take the lock.

						if (_useDetailedDebug) Debug.WriteLine($"AAResetEvent is returning true after timeout, using the Delay Thread: {Thread.CurrentThread.ManagedThreadId} at {GetTime()}. {GetSignaledInfo(useLock: false)}. {opId}");

						Debug.Assert(_receivedMessages.Count > 0, "The TcsPlus result was set to true, but we have no messagees.");
						return ShouldWeSignal(tcs.CorrelationId, tcs.CorrelationIdInfo);
					}
					else
					{
						if (_waiter == null)
						{
							Debug.WriteLine($"WARNING _waiter was null on timeout at {GetTime()} {opId}.");
						}
						_waiter = null;

						if (_useDetailedDebug) Debug.WriteLine($"AAResetEvent is returning false after timeout, using the Delay Thread: {Thread.CurrentThread.ManagedThreadId} at {GetTime()}. {GetSignaledInfo(useLock: false)}. {opId}");

						return false;
					}
				}
			}
		}

		private TcsPlus Set()
		{
			if (_useDetailedDebug) Debug.WriteLine($"At set: {GetSignaledInfo(useLock: false)}");
			TcsPlus waiter;

			if (_waiter != null)
			{
				// Signal the first task in the waiters list. This must be done on a new
				// thread to avoid stack-dives and situations where we try to complete the
				// same result multiple times.

				waiter = _waiter;
				waiter.Result = true;
				_waiter = null;
			}
			else
			{
				// No tasks are pending
				waiter = null;

				if (!_isSignaled)
				{
					_isSignaled = true;
				}
			}

			return waiter;
		}

		private bool ShouldWeSignal(string correlationId, CorrelationIdInfo correlationIdInfo)
		{
			if (_receivedMessages.Where(x => x.IsException).Count() > 0)
			{
				return true;
			}

			foreach (MessageWithTimestamp mwts in _receivedMessages)
			{
				if (MessageHelper.DoesResponseHaveExpectedCorId(mwts.Message, correlationId, correlationIdInfo))
				{
					return true;
				}
			}

			return false;
		}

		private void CompleteTcs(TcsPlus waiter)
		{

			//tcs.Tcs.TrySetResult(true);

			try
			{
				waiter.Tcs.SetResult(true);
			}
			catch (InvalidOperationException)
			{
				throw new InvalidOperationException($"ReceivedMessagesQueue wait task has already completed. SetResult failed. {waiter.OpId}");
			}
			catch (Exception e)
			{
				Debug.WriteLine($"ReceivedMessagesQueue could not complete the task, received exception {e.GetType()}: {e.Message}. {waiter.OpId}");
			}


			//// TODO: Make sure that we must use a task instead of just calling TrySetResult directly.
			//// TODO: Make sure that we must use TrySetResult instead of SetResult.

			//var callingThread = Thread.CurrentThread;
			//Task.Factory.StartNew(s =>
			//{
			//	TcsPlus insideTcs = (TcsPlus)s;
			//	if (_useDetailedDebug) Debug.WriteLine($"Thread: {callingThread.ManagedThreadId} is setting the IMessage Client's AAResetEvent, using runner Thread: {Thread.CurrentThread.ManagedThreadId} and then waiting at {GetTime()}. {insideTcs.OpId}");

			//	bool succ = insideTcs.Tcs.TrySetResult(true);

			//	if (!succ) Debug.WriteLine($"Could not set the result of the TCS at {GetTime()}. {insideTcs.OpId}");
			//}
			//	, tcs, CancellationToken.None, TaskCreationOptions.PreferFairness, TaskScheduler.Default
			//);

			//// TODO: Make sure that we do not have to wait for the task to return
			//tcs.Task.Wait();
			//Debug.WriteLine($"IMessage Client's AAREvent Runner thread returned. {tcs.OpId}");
		}

		private string GetSignaledInfo(bool useLock)
		{
			if(useLock)
			{
				lock (_stateLock)
				{
					return $"Signaled: {_isSignaled}, Waiters: {(_waiter == null ? 0 : 1)}";
				}
			}
			else
			{
				return $"Signaled: {_isSignaled}, Waiters: {(_waiter == null ? 0 : 1)}";
			}
		}

		private string GetTime()
		{
			string t = DateTime.Now.ToString("HH:mm:ss:fff").Substring(3);
			return t;
		}

		class TcsPlus
		{
			public TaskCompletionSource<bool> Tcs;
			public bool? Result { get; set; }

			public string CorrelationId { get; }
			public CorrelationIdInfo CorrelationIdInfo { get; }
			public string OpId { get; }

			public Task<bool> Task => Tcs.Task;

			public TcsPlus(string correlationId, CorrelationIdInfo correlationIdInfo, string opId)
			{
				Tcs = new TaskCompletionSource<bool>(TaskCreationOptions.RunContinuationsAsynchronously);
				Result = null;
				CorrelationId = correlationId;
				CorrelationIdInfo = correlationIdInfo;
				OpId = opId;
			}
		}

	}
}
