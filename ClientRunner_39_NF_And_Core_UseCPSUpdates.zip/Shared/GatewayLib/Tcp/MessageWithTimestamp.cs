﻿using System;
using TcpProtocolLib;

namespace GatewayLib.Tcp
{
	public class MessageWithTimestamp
	{
		public static long RefTicks { get; set; }

		static MessageWithTimestamp()
		{
			RefTicks = DateTime.Now.Ticks;
		}

		public readonly DateTime Timestamp;
		public readonly string Message;
		public readonly SendRequestException Exception;

		public bool IsMessage => Message != null;
		public bool IsException => Exception != null;

		public MessageWithTimestamp(string message)
		{
			Timestamp = DateTime.Now;
			Message = message ?? throw new ArgumentNullException(nameof(message), "The message cannot be null when creating a 'Message' type MessageWithTimestamp entry.");
			Exception = null;
		}

		public MessageWithTimestamp(SendRequestException exception)
		{
			Timestamp = DateTime.Now;
			Message = null;
			Exception = exception ?? throw new ArgumentNullException(nameof(exception), "The exception cannot be null when creating a 'Exception' type MessageWithTimestamp entry.");
		}

		public override string ToString()
		{
			if(IsException)
			{
				return $"{Ts}: Exception:{Exception}";
			}
			else
			{
				return $"{Ts}: Response:{RemoveWhiteSpace(Message)}";
			}
		}

		public static string RemoveWhiteSpace(string input)
		{
			return string.Join(" ", input.Split(default(string[]), StringSplitOptions.RemoveEmptyEntries));
		}

		private string Ts
		{
			get
			{
				string msfs = Timestamp.ToString("HH:mm:ss:fff").Substring(3);
				return $"{msfs} ({Timestamp.Ticks - RefTicks})";
			}
		}

	}
}
