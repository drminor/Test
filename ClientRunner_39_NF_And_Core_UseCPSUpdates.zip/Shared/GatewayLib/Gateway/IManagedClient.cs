﻿using GatewayLib.Tcp;
using System;
using System.Threading.Tasks;

namespace GatewayLib.Gateway
{
	public interface IManagedClient : IDisposable
	{
		int Id { get; }
		string MessageClientIdentifier { get; }

		string SendAndReadResponse(string message, string correlationId, CorrelationIdInfo correlationIdInfo);
		Task<string> SendAndReadResponseAsync(string message, string correlationId, CorrelationIdInfo correlationIdInfo);
	}
}
