﻿namespace GatewayLib.Gateway
{
	public enum GatewayOperationEnum
	{
		GetClientFromPool,
		SendAndReadResponse,
		ReturnClientToPool
	}
}
