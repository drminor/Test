﻿using GatewayLib.ClientPool;
using GatewayLib.Tcp;
using System;
using System.Threading.Tasks;

namespace GatewayLib.Gateway
{
	public class Gateway<T> : IGateway<T>, IDisposable where T: class, IMessageClient
	{
		private readonly IClientPool<T> _clientPool;
		private readonly CreateManagedClient<T> _managedClientCreator;

		private int _managedClientCounter;

		public Gateway(IClientPool<T> clientPool, CreateManagedClient<T> managedClientCreator)
		{
			_clientPool = clientPool;
			_managedClientCreator = managedClientCreator;
			_managedClientCounter = 0;
		}

		// Throws GatewayException,	ErrorCode = Timeout or ClientPoolIsDisposed
		public async Task<IManagedClient> GetManagedClientAsync()
		{
			string opId = MessageHelper.GetOpId();
			T client = await _clientPool.GetClientAsync(opId);
			if (client == null)
			{
				return null;
			}

			IManagedClient managedClient = _managedClientCreator(_clientPool, client, _managedClientCounter++);
			return managedClient;
		}

		public int ClientPoolId => _clientPool.InstanceId;

		public PoolStats GetPoolStats() => _clientPool.GetPoolStats();

		public override string ToString()
		{
			return $"ClientPoolId: {ClientPoolId}, ManagedClientCounter: {_managedClientCounter}";
		}

		#region IDisposable Support

		private bool disposedValue;

		protected virtual void Dispose(bool disposing)
		{
			if (!disposedValue)
			{
				if (disposing)
				{
					// Dispose managed state (managed objects)
					_clientPool.Dispose();
				}

				disposedValue = true;
			}
		}

		public void Dispose()
		{
			Dispose(disposing: true);
			GC.SuppressFinalize(this);
		}

		#endregion
	}

}
