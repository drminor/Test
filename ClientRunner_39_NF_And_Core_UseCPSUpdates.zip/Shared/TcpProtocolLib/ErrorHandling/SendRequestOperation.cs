﻿namespace TcpProtocolLib
{
	public enum SendRequestOperation
	{
		Connect,
		PreWrite,
		Write,
		Read
	}
}
