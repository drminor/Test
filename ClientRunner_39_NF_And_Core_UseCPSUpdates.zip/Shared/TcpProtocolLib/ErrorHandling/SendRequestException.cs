﻿using System;
using System.IO;
using System.Net.Sockets;
using System.Text;

namespace TcpProtocolLib
{
	[Serializable]
	public class SendRequestException : Exception
	{
		public readonly SendRequestOperation Operation;
		public readonly SendRequestError ErrorCode;
		public readonly SocketError? SocketErrorCode;

		// Just operation
		public SendRequestException(SendRequestOperation operation, Exception innnerException) : this(MessageFromOperation(operation), operation, SendRequestError.Other, innnerException)
		{
		}

		public SendRequestException(string message, SendRequestOperation operation) : this(message, operation, SendRequestError.Other, null)
		{
		}

		public SendRequestException(string message, SendRequestOperation operation, Exception innerException) : this(message, operation, SendRequestError.Other, innerException)
		{
		}

		// With ErrorCode
		public SendRequestException(string message, SendRequestOperation operation, SendRequestError errorCode) : this(message, operation, errorCode, null)
		{
		}

		public SendRequestException(string message, SendRequestOperation operation, SendRequestError errorCode, Exception innerException) : base(message, innerException)
		{
			Operation = operation;
			ErrorCode = errorCode;
		}

		// With SocketErrorCode
		public SendRequestException(string message, SendRequestOperation operation, SendRequestError errorCode, SocketError socketErrorCode) : this(message, operation, errorCode, socketErrorCode, null)
		{
		}

		// From SocketException
		public SendRequestException(string message, SendRequestOperation operation, SocketException socketException)
			: this(message, operation, SendRequestError.SocketException, socketException.SocketErrorCode, socketException)
		{
		}

		// From IOException
		public SendRequestException(string message, SendRequestOperation operation, IOException iOException) : base(message, iOException)
		{
			Operation = operation;
			ErrorCode = iOException?.InnerException is SocketException
				? SendRequestError.IOExceptionWithInnerSocketException
				: SendRequestError.IOException;

			SocketErrorCode = iOException?.InnerException is SocketException se
				? se.SocketErrorCode
				: (SocketError?) null;
		}

		public SendRequestException(string message, SendRequestOperation operation, SendRequestError errorCode, SocketError socketErrorCode, Exception innerException) : base(message, innerException)
		{
			Operation = operation;
			ErrorCode = errorCode;
			SocketErrorCode = socketErrorCode;
		}

		public override string ToString()
		{
			StringBuilder sb = new StringBuilder();

			sb.Append($"SendRequestException: {Message}, op:{Operation}, ErrorCode: {ErrorCode}");
			if (SocketErrorCode != null)
			{
				sb.Append($" SocketError: {SocketErrorCode}");
			}

			if (InnerException != null)
			{
				if (InnerException is AggregateException ae)
				{
					sb.Append(" List of inner exceptions:\n");
					foreach(Exception e in ae.InnerExceptions)
					{
						sb.Append(e.ToString() + "\n");
					}
				}
				else
				{
					sb.Append($" with {InnerException.GetType()}: {InnerException.Message}");
				}
			}

			return sb.ToString();
		}

		static string MessageFromOperation(SendRequestOperation operation)
		{
			return $"{operation}, see InnerException for details.";
		}
	}
}
