﻿using GatewayLib.ClientPool;
using System;
using System.Net;
using TcpProtocolLib;

namespace AppProtocolLib.WebApiDTOs
{
	public class ClientPoolSettingsRequest
	{
		public string ServerAddress { get; set; }
		public int ServerPort { get; set; }
		public int MinConnections { get; set; }
		public int MaxConnections { get; set; }
		public double AllocateClientTimeoutSeconds { get; set; }
		public int MessageEncoderType { get; set; }
		public double MessageResponseTimeoutSeconds { get; set; }

		public string OurPrivateCertFilePath { get; set; }
		public string OurPrivateCertPassword { get; set; }
		public string PeersPublicCertFilePath { get; set; }

		public bool UseClientPool2Implementation { get; set; }

		public ClientPoolSettingsRequest()
		{
		}

		public ClientPoolSettingsRequest(ClientPoolSettings settings, bool useClientPool2Implementation)
		{
			ServerAddress = settings.ServerEndPoint.Address.ToString();
			ServerPort = settings.ServerEndPoint.Port;
			MinConnections = settings.MinConnections;
			MaxConnections = settings.MaxConnections;
			AllocateClientTimeoutSeconds = settings.AllocateClientTimeout.TotalSeconds;
			MessageEncoderType = GetEncoderType(settings.MessageEncoder);
			MessageResponseTimeoutSeconds = settings.MessageResponseTimeout.TotalSeconds;
			OurPrivateCertFilePath = settings.CertInfo.OurPrivateCertFilePath;
			OurPrivateCertPassword = settings.CertInfo.OurPrivateCertPassword;
			PeersPublicCertFilePath = settings.CertInfo.PeersPublicCertFilePath;

			UseClientPool2Implementation = useClientPool2Implementation;
		}

		public ClientPoolSettings GetClientPoolSettings()
		{
			ClientPoolSettings result = new ClientPoolSettings
				(
				new IPEndPoint(IPAddress.Parse(ServerAddress), ServerPort),
				MinConnections,
				MaxConnections,
				TimeSpan.FromSeconds(AllocateClientTimeoutSeconds),
				GetMessageEncoder(MessageEncoderType),
				TimeSpan.FromSeconds(MessageResponseTimeoutSeconds),
				new CertInfo(OurPrivateCertFilePath, OurPrivateCertPassword, PeersPublicCertFilePath)
				);

			return result;
		}

		private IMessageEncoder GetMessageEncoder(int encoderType)
		{
			switch(encoderType)
			{
				case 0: return new ASCII_MessageEncoder(4);
				case 1: return new EBCDIC_MessageEncoder(4);
				default: throw new ArgumentException($"The encoderType: {encoderType} is not supported or is not recognized.");
			}
		}

		private int GetEncoderType(IMessageEncoder encoder)
		{
			if (encoder is ASCII_MessageEncoder)
			{
				return (int) MessageEncoderTypeEnum.ASCII;
			}
			else if (encoder is EBCDIC_MessageEncoder)
			{
				return (int) MessageEncoderTypeEnum.EBCDIC;
			}
			else
			{
				throw new ArgumentException($"The encoder of type: {encoder.GetType().Name} is not supported or not recognized.");
			}
		}
	}

	public enum MessageEncoderTypeEnum
	{
		ASCII = 0,
		EBCDIC = 1
	}

}
