﻿namespace ClientRunnerLib
{
	public enum TcpServerOperationEnum
	{
		Start = 1,
		Stop = 2,
	}
}
