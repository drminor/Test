﻿namespace ClientRunnerLib
{
	public class SharedSettings
	{
		public const int TCP_SERVER_CONTROL_PORT = 11233;

		public const string SERVER_CERT_FILE_NAME = "TcpServer.pfx";
		public const string SERVER_CERT_PASS = "Joel";
		public const string SERVER_PUBLIC_CERT_FILE_NAME = "TcpServer.cer";

		public const string CLIENT_CERT_FILE_NAME = "ClientRunner.pfx";
		public const string CLIENT_CERT_PASS = "Mary";
		public const string CLIENT_PUBLIC_CERT_FILE_NAME = "ClientRunner.cer";
	}

}
