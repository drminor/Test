﻿using GatewayLib.ClientPool;
using GatewayLib.Tcp;
using System;
using System.Net;
using TcpProtocolLib;

namespace ClientRunnerLib
{
	public static class GatewayFactoryHelper
	{
		private readonly static int TEST_SERVER_PORT = 11234;

		public static GatewayFactory<IMessageClient> GetGatewayFactory()
		{
			ClientPoolSettings initialSettings = GetInitialClientPoolSettings(TEST_SERVER_PORT);
			GatewayFactory<IMessageClient> result = new GatewayFactory<IMessageClient>(initialSettings, useClientPool2Implementation: false);

			return result;
		}

		private static ClientPoolSettings GetInitialClientPoolSettings(int tcpServerPort)
		{
			IPAddress remoteTcpServerAddress = IPAddress.Loopback;
			CertInfo certInfo = JobRunnerHelper.GetClientCertInfo();

			ClientPoolSettings clientPoolSettings = new ClientPoolSettings
			(
				serverEndPoint: new IPEndPoint(remoteTcpServerAddress, tcpServerPort),
				minConnections: 3,
				maxConnections: 30,
				allocateClientTimeoutMs: TimeSpan.FromMilliseconds(3 * 1000),
				messageEncoder: new ASCII_MessageEncoder(4),
				messageResponseTimeout: TimeSpan.FromMilliseconds(150),
				certInfo: certInfo
			);

			return clientPoolSettings;
		}
	}
}