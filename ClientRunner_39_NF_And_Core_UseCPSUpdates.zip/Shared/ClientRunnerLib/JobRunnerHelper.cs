﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using TcpProtocolLib;

namespace ClientRunnerLib
{
	public static class JobRunnerHelper
	{
		public static bool? IsRunningOnNetCore { get; set; }
		public static bool IsWebServerApp { get; set; }

		/// <summary>
		/// This assumes that this is being called from a project executable in a child folder of the NF or Core folder.
		/// </summary>
		/// <returns></returns>
		public static string GetSharedSolutionRootPath()
		{
			if (!IsRunningOnNetCore.HasValue) throw new InvalidOperationException("You must first set the static property: IsRunningOnNetCore.");

			int numFoldersToRemove;
			if (IsWebServerApp)
			{
				numFoldersToRemove = 2;
			}
			else
			{
				numFoldersToRemove = IsRunningOnNetCore.Value ? 5 : 4;
			}

			string baseDir = AppContext.BaseDirectory;
			string result = RemoveChildFolders(baseDir, numFoldersToRemove);

			if (result == null) throw new InvalidOperationException("Cannot determine the path to the Shared Solution Root folder.");

			return result;
		}

		#region Client Runner Results Folder

		public static string GetRunResultsFilePath(string jobShortName, bool isCore)
		{
			string baseFolderPath = GetRunResultsFolderPath(isCore);

			string fileName = jobShortName + GetFileName(DateTime.Now);
			string filePath = Path.Combine(baseFolderPath, fileName);
			filePath = Path.ChangeExtension(filePath, "txt");

			return filePath;
		}

		public static string GetRunResultsFolderPath(bool isCore)
		{
			string rootPath = GetSharedSolutionRootPath();
			string result = Path.Combine(rootPath, "ClientRunnerResults");
			result = isCore ? Path.Combine(result, "Core") : Path.Combine(result, "NF");

			return result;
		}

		#endregion

		#region Cert Info

		public static CertInfo GetClientCertInfo()
		{
			string certFolderPath = GetCertsFolderPath();
			string certPath = Path.Combine(certFolderPath, SharedSettings.CLIENT_CERT_FILE_NAME);
			string peerPublicCertPath = Path.Combine(certFolderPath, SharedSettings.SERVER_PUBLIC_CERT_FILE_NAME);

			CertInfo certInfo = new CertInfo(certPath, SharedSettings.CLIENT_CERT_PASS, peerPublicCertPath);
			return certInfo;
		}

		public static CertInfo GetServerCertInfo()
		{
			string certFolderPath = GetCertsFolderPath();
			string certPath = Path.Combine(certFolderPath, SharedSettings.SERVER_CERT_FILE_NAME);
			string peerPublicCertPath = Path.Combine(certFolderPath, SharedSettings.CLIENT_PUBLIC_CERT_FILE_NAME);

			CertInfo certInfo = new CertInfo(certPath, SharedSettings.SERVER_CERT_PASS, peerPublicCertPath);
			return certInfo;
		}

		public static string GetCertsFolderPath()
		{
			string rootPath = GetSharedSolutionRootPath();
			string result = Path.Combine(rootPath, "Certs");

			return result;
		}

		#endregion

		/// <summary>
		/// Gets the number of ticks since the last time this was called.
		/// </summary>
		/// <param name="currentTickCount"></param>
		/// <returns></returns>
		public static long GetDurationInTicks(ref long currentTickCount)
		{
			long tickCount = Environment.TickCount;
			long diff = currentTickCount == -1 ? 0 : tickCount - currentTickCount;
			currentTickCount = tickCount;

			return diff;
		}

		public static double GetAverage(double[] items)
		{
			IEnumerable<double> nonZeroItem = items.Where(x => x != 0);
			if (nonZeroItem.Count() > 0)
			{
				return nonZeroItem.Average();
			}
			else
			{
				return 0;
			}
		}

		private static string RemoveChildFolders(string path, int numberOfLevelsToRemove)
		{
			// TODO: Use IndexOfLast instead.

			string aPath = Path.GetFullPath(path);

			char[] separator = new char[] { Path.DirectorySeparatorChar, Path.AltDirectorySeparatorChar };
			string[] components = aPath.Split(separator, StringSplitOptions.RemoveEmptyEntries);

			if (components.Length < numberOfLevelsToRemove)
				return null;

			IEnumerable<string> componentsToUse = components.Take(components.Length - numberOfLevelsToRemove);
			string first = componentsToUse.First();
			IEnumerable<string> allButFirst = componentsToUse.Skip(1);

			string result = first + Path.DirectorySeparatorChar + Path.Combine(allButFirst.ToArray());
			return result;
		}

		private static string GetFileName(DateTime t)
		{
			return t.ToString("yyyy_MM_dd_HH_mm_ss");
		}
	}
}
