﻿using AppProtocolLib.WebApiDTOs;
using System.ServiceModel;

namespace Test001WcfService
{
	[ServiceContract]
	public interface IService1Sync
	{
		[OperationContract]
		TestServiceResult SendMessages(int messagesToSend, int jobCntr, string messageTemplate, int delayToSimulateOtherWorkMs);

		[OperationContract]
		void UpdateClientPoolSettings(ClientPoolSettingsRequest request);
	}

}
