﻿using AppProtocolLib;
using AppProtocolLib.WebApiDTOs;
using ClientRunnerLib;
using GatewayLib.ClientPool;
using GatewayLib.Gateway;
using GatewayLib.Tcp;
using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Linq;
using System.Threading.Tasks;

namespace Test001WcfService
{
	public class Test001Service : IService1
	{
		static readonly CorrelationIdInfo ResponseCorrelationIdInfo;

		static Test001Service()
		{
			ColumnDefinition coreIdCd = TestResponse001._columnDefinitions["CorrelationId"];
			ResponseCorrelationIdInfo = new CorrelationIdInfo(coreIdCd.Start, coreIdCd.Length);
		}

		private readonly GatewayFactory<IMessageClient> _gatewayFactory;
		private readonly IGateway<IMessageClient> _gateway;

		//public Test001Service(IGateway<IMessageClient> gateway)
		//{
		//	_gateway = gateway;
		//}

		public Test001Service(GatewayFactory<IMessageClient> gatewayFactory)
		{
			_gatewayFactory = gatewayFactory;
			_gateway = gatewayFactory.Gateway;
		}

		public async Task<TestServiceResult> SendMessagesAsync(int messagesToSend, int jobCntr, string messageTemplate, int delayToSimulateOtherWorkMs)
		{
			int messagesSent = 0;
			IList<string> uniqueMessageClientIds = new List<string>();
			IList<double> sendTimeMs = Enumerable.Repeat(0d, messagesToSend).ToList();
			long timeToGetClient;

			if (delayToSimulateOtherWorkMs > 14)
			{
				//Debug.WriteLine($"TestService waiting {delayToSimulateOtherWorkMs}ms to simulate other work.");
				await Task.Delay(delayToSimulateOtherWorkMs);
			}

			Stopwatch s = Stopwatch.StartNew();
			using (IManagedClient managedClient = await GetManagedClientAsync(_gateway))
			{
				if (managedClient == null)
				{
					s.Stop();
					timeToGetClient = s.ElapsedMilliseconds;
					Debug.WriteLine($"The Test001Service could not get a ManagedClient from the pool. Took {s.ElapsedMilliseconds} ms");
				}
				else
				{
					s.Stop();
					timeToGetClient = s.ElapsedMilliseconds;

					string strJobCntr = jobCntr.ToString().PadLeft(3);

					for (int messageCounter = 0; messageCounter < messagesToSend; messageCounter++)
					{
						string strMessageCntr = messageCounter.ToString().PadLeft(5);
						string command = $"{messageTemplate}{strMessageCntr}";

						TestMessage001 message = new TestMessage001
						{
							DateCreated = DateTime.Now,
							Command = command,
							Extra = string.Empty,
							CorrelationId = strJobCntr + strMessageCntr
						};

						s.Restart();
						try
						{
							string id = managedClient.MessageClientIdentifier;
							if (!uniqueMessageClientIds.Contains(id)) uniqueMessageClientIds.Add(id);

							TestResponse001 response = await SendRequestAsync(managedClient, message, s);
							s.Stop();

							if (response.Succeeded)
								messagesSent++;
						}
						catch (Exception e)
						{
							s.Stop();
							string errorMessage = e.GetBaseException().Message;
							Debug.WriteLine($"Test001Service received {e.GetType()}: {errorMessage}");
						}

						sendTimeMs[messageCounter] = s.ElapsedMilliseconds;
					}
				}

				TestServiceResult result = new TestServiceResult(messagesSent, uniqueMessageClientIds.Count, sendTimeMs.Average(), timeToGetClient);

				return result;
			}
		}

		public void UpdateClientPoolSettings(ClientPoolSettingsRequest request)
		{
			ClientPoolSettings newSettings = request.GetClientPoolSettings();
			_gatewayFactory.RefreshGateway(newSettings, request.UseClientPool2Implementation);
		}

		private async Task<TestResponse001> SendRequestAsync(IManagedClient managedClient, TestMessage001 message, Stopwatch s)
		{
			TestResponse001 result;

			string strMessage = message.ToMessage();
			string strResponse;
			long e1 = s.ElapsedMilliseconds;

			try
			{
				strResponse = await managedClient.SendAndReadResponseAsync(strMessage, message.CorrelationId, ResponseCorrelationIdInfo);

				result = new TestResponse001(strResponse, strMessage);
				//Debug.WriteLine($"The Test001Service took {s.ElapsedMilliseconds - e1} ms to send {message.Command}.");
			}
			catch (Exception e)
			{
				strResponse = $"The Test001Service took {s.ElapsedMilliseconds - e1} ms, and then raised exception {e.GetType()}:{e.Message} while sending {message.Command}.";
				Debug.WriteLine(strResponse);

				result = new TestResponse001(strResponse, strMessage)
				{
					Succeeded = false
				};
			}

			return result;
		}

		private async Task<IManagedClient> GetManagedClientAsync(IGateway<IMessageClient> gateway)
		{
			try
			{
				IManagedClient managedClient = await gateway.GetManagedClientAsync();
				return managedClient;
			}
			catch
			{
				Debug.WriteLine($"Could not get a client from the gateway.");
				return null;
			}
		}

		public async Task<TestResponse001> SendAndReadResponseAsync(TestMessage001 message)
		{
			Stopwatch s = Stopwatch.StartNew();
			string strMessage = message.ToMessage();

			//var t0 = s.ElapsedMilliseconds;
			//Debug.WriteLine($"TestService got a string from the message in {t0} ms");

			TestResponse001 result;

			//CheckTestMessage001(message);

			using (IManagedClient managedClient = await GetManagedClientAsync(_gateway))
			{

				if (managedClient == null)
				{
					s.Stop();
					string response = $"The Test001Service could not get a ManagedClient from the pool. Took {s.ElapsedMilliseconds} ms";
					Debug.WriteLine(response);

					result = new TestResponse001(response, strMessage)
					{
						Succeeded = false
					};

					return result;
				}

				var t1 = s.ElapsedMilliseconds;
				Debug.WriteLine($"TestService got a managed client in {t1} ms");

				try
				{
					string strResponse = await managedClient.SendAndReadResponseAsync(strMessage, message.CorrelationId, ResponseCorrelationIdInfo);
					var t2 = s.ElapsedMilliseconds;
					Debug.WriteLine($"TestService got a respone in {t2} ms");

					result = new TestResponse001(strResponse, strMessage);
					s.Stop();
					Debug.WriteLine($"The Test001Service took {s.ElapsedMilliseconds} ms to send {message.Command}.");
					//string testStrResponse = result.ToMessage();
					//Debug.Assert(strResponse == testStrResponse, "TestResponse001 cannot round trip.");
					return result;
				}
				catch (Exception e)
				{
					s.Stop();
					string response = $"The Test001Service took {s.ElapsedMilliseconds} ms, and then raised exception {e.GetType()}:{e.Message} while sending {message.Command}.";
					Debug.WriteLine(response);

					result = new TestResponse001(response, strMessage)
					{
						Succeeded = false
					};
					return result;
				}
			}
		}

		//private void CheckTestMessage001(TestMessage001 m)
		//{
		//	string s = m.ToMessage();
		//	TestMessage001 tm = TestMessage001.CreateNewFromMessage(s);
		//	string t = tm.ToMessage();

		//	Debug.Assert(s == t, "Test001Message cannot roundtrip.");
		//}

		//private void CheckTestResponse001(TestResponse001 m)
		//{
		//	string s = m.ToMessage();
		//	TestResponse001 tm = TestResponse001.CreateNewFromMessage(s);
		//	string t = tm.ToMessage();

		//	Debug.Assert(s == t, "TestResponse001 cannot roundtrip.");
		//}


	}
}
