﻿namespace TcpServerConsole
{
	public interface IRequestHandler
	{
		string GetResponse(string request);
	}
}
