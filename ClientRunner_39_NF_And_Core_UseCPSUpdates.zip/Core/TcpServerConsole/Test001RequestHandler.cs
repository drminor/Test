﻿using AppProtocolLib;

namespace TcpServerConsole
{
	class Test001RequestHandler : IRequestHandler
	{
		public string GetResponse(string message)
		{
			TestMessage001 request = TestMessage001.CreateNewFromMessage(message);
			TestResponse001 response = new TestResponse001("Test Response", request.CorrelationId, true);
			return response.ToMessage();
		}
	}
}
