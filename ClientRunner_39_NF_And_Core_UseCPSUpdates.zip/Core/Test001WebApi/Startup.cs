using ClientRunnerLib;
using GatewayLib.Tcp;
using Microsoft.AspNetCore.Builder;
using Microsoft.AspNetCore.Hosting;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.DependencyInjection;
using Microsoft.Extensions.Hosting;
using System.Diagnostics;

namespace Test001WebApi
{
	public class Startup
	{
		private static int _startupInstanceCounter = 0;
		public int InstanceId { get; }

		public const int TEST_SERVER_PORT = 11234;

		static Startup()
		{
			// This is required to make sure the JobRunnerHelper can retrieve the Certificate files.
			JobRunnerHelper.IsRunningOnNetCore = true;
			JobRunnerHelper.IsWebServerApp = false;
		}

		public Startup(IConfiguration configuration)
		{
			InstanceId = _startupInstanceCounter++;
			Configuration = configuration;
		}

		public IConfiguration Configuration { get; }

		// This method gets called by the runtime. Use this method to add services to the container.
		public void ConfigureServices(IServiceCollection services)
		{
			Debug.WriteLine($"The Startup Config is being retrieved. InstanceId = {InstanceId}");

			// Register the GatewayProvider as a singleton.
			GatewayFactory<IMessageClient> gatewayFactory = GatewayFactoryHelper.GetGatewayFactory();
			services.AddSingleton(gatewayFactory);

			services.AddControllers().AddJsonOptions(jsonOptions =>
			{
				jsonOptions.JsonSerializerOptions.PropertyNamingPolicy = null;
			}
			).SetCompatibilityVersion(CompatibilityVersion.Version_3_0);
		}

		// This method gets called by the runtime. Use this method to configure the HTTP request pipeline.
		public void Configure(IApplicationBuilder app, IWebHostEnvironment env)
		{
			if (env.IsDevelopment())
			{
				app.UseDeveloperExceptionPage();
			}

			app.UseHttpsRedirection();

			app.UseRouting();

			app.UseAuthorization();

			app.UseEndpoints(endpoints =>
			{
				endpoints.MapControllers();
			});
		}
	}

}
