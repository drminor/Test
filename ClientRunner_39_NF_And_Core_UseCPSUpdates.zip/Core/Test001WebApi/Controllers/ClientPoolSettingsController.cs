﻿using AppProtocolLib.WebApiDTOs;
using ClientRunnerLib;
using GatewayLib.ClientPool;
using GatewayLib.Tcp;
using Microsoft.AspNetCore.Mvc;
using System.Diagnostics;

namespace Test001WebApi.Controllers
{
	[Route("[controller]")]
	[ApiController]
	public class ClientPoolSettingsController : ControllerBase
	{
		private readonly GatewayFactory<IMessageClient> _gatewayFactory;
		private readonly bool _useDetailedDebug = true;

		public ClientPoolSettingsController(GatewayFactory<IMessageClient> gatewayFactory)
		{
			_gatewayFactory = gatewayFactory;
		}

		[HttpGet]
		public string Ping()
		{
			//IGateway<IMessageClient> gateway = _gatewayFactory.Gateway;
			//IManagedClient mc = GetManagedClient(gateway);
			//ClientPoolSettings current = _gatewayFactory.ClientPoolSettings;
			//ClientPoolSettings newSettings = new ClientPoolSettings(current.ServerEndPoint, current.MinConnections + 1, current.MaxConnections, current.AllocateClientTimeout, current.MessageEncoder, current.MessageResponseTimeout, current.CertInfo);
			//_gatewayFactory.RefreshGateway(newSettings, useClientPool2Implementation: false);
			//gateway = _gatewayFactory.Gateway;
			//mc = GetManagedClient(gateway);

			return $"Hi There - WebServiceController. GatewayProvider = {_gatewayFactory}";
		}

		[HttpPost]
		[ProducesResponseType(200)]
		public IActionResult PostClientPoolSettings(ClientPoolSettingsRequest request)
		{
			ClientPoolSettings newSettings = request.GetClientPoolSettings();
			if (_useDetailedDebug) Debug.WriteLine($"PostWebService received new settings: {newSettings}.");
			_gatewayFactory.RefreshGateway(newSettings, request.UseClientPool2Implementation);

			var ar = new OkResult();
			return ar;
		}

		//// Only for testing
		//private IManagedClient GetManagedClient(IGateway<IMessageClient> gateway)
		//{
		//	try
		//	{
		//		IManagedClient managedClient = Task.Run(() => gateway.GetManagedClientAsync()).GetAwaiter().GetResult();
		//		return managedClient;
		//	}
		//	catch (Exception e)
		//	{
		//		Debug.WriteLine($"The WebServiceController could not get a client from the gateway. {e.GetType()}: {e.Message}");
		//		return null;
		//	}
		//}

	}
}
