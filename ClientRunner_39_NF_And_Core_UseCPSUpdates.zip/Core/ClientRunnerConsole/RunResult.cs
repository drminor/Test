﻿using System;

namespace ClientRunnerConsole
{
	class RunResult
	{
		public readonly int UniqueThreadsUsed;
		public readonly int TotalMessagesSent;
		public readonly TimeSpan Duration;
		public readonly Double AverageTimeToSendAMessageMs;

		public RunResult()
		{
		}

		public RunResult(int uniqueThreadsUsed, int totalMessagesSent, TimeSpan duration, double averageTimeToSendAMessageMs)
		{
			UniqueThreadsUsed = uniqueThreadsUsed;
			TotalMessagesSent = totalMessagesSent;
			Duration = duration;
			AverageTimeToSendAMessageMs = averageTimeToSendAMessageMs;
		}
	}
}
