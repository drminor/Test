﻿using GatewayLib.ClientPool;
using System;
using System.Diagnostics;
using System.Threading.Tasks;

namespace ClientRunnerConsole
{
	class WebApiClientPoolSettingsControllerClient : IDisposable
	{
		private readonly WebApiClient _webApiClient;

		public WebApiClientPoolSettingsControllerClient(string webApiEndpoint)
		{
			_webApiClient = new WebApiClient(webApiEndpoint);
		}

		public void PostClientPoolSettings(ClientPoolSettings clientPoolSettings, bool useClientPool2Implementation)
		{
			try
			{
				Task.Run(() => _webApiClient.PostClientPoolSettings(clientPoolSettings, useClientPool2Implementation)).GetAwaiter().GetResult();
			}
			catch (Exception e)
			{
				Debug.WriteLine($"WebApiClientPoolSettingsControllerClient received {e.GetType()}: {e.Message}");
				throw;
			}

		}

		#region IDisposable Support

		private bool disposedValue;

		protected virtual void Dispose(bool disposing)
		{
			if (!disposedValue)
			{
				if (disposing)
				{
					// Dispose managed state (managed objects)
					if (_webApiClient != null)
						_webApiClient.Dispose();
				}

				disposedValue = true;
			}
		}

		public void Dispose()
		{
			// Do not change this code. Put cleanup code in 'Dispose(bool disposing)' method
			Dispose(disposing: true);
			GC.SuppressFinalize(this);
		}

		#endregion
	}

}
