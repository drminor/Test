﻿using AppProtocolLib;
using ClientRunnerLib;
using GatewayLib.ClientPool;
using GatewayLib.Gateway;
using GatewayLib.Tcp;
using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.IO;
using System.Linq;
using System.Threading;
using System.Threading.Tasks;

namespace ClientRunnerConsole
{
	class ManagedClientJobRunner
	{
		private long _currentTickCount = -1;

		public RunResult[] Run(JobSettings settings, TcpServerControllerClient serverController, TcpServerSettings tcpServerSettings, ClientPoolSettings clientPoolSettings)
		{
			string filePath = settings.FilePath;
			int taskCount = settings.NumberOfTasks;
			//int taskSpacingMs = settings.TaskSpacingMs;
			int messagesToSendPerTask = settings.MessagesToSendPerTask;
			int serviceWorkDelayMs = settings.ServiceWorkDelayMs;
			int repeatCnt = settings.RepeatCnt;

			RunResult[] runResults = Enumerable.Repeat<RunResult>(new RunResult(), taskCount).ToArray();

			Console.WriteLine("Press the Enter key to start run.");
			Console.ReadLine();

			try
			{
				string servResponse = serverController.Start("Test1", tcpServerSettings);
				Console.WriteLine($"Response from TcpServerController: {servResponse}");
				Debug.WriteLine($"Response from TcpServerController: {servResponse}");
			}
			catch
			{
				Console.WriteLine("Could not contact the TcpServerController.");
				Debug.WriteLine("Could not contact the TcpServerController.");
				return runResults;
			}

			ColumnDefinition coreIdCd = TestResponse001._columnDefinitions["CorrelationId"];
			CorrelationIdInfo responseCorrelationIdInfo = new CorrelationIdInfo(coreIdCd.Start, coreIdCd.Length);

			using IGateway<IMessageClient> gateway = GatewayModule.BuildGateway(clientPoolSettings, useClientPool2Implementation: false);
			using (var sw = new StreamWriter(filePath))
			{
				for (int runCounter = 0; runCounter < repeatCnt; runCounter++)
				{
					Stopwatch mainSw = Stopwatch.StartNew();

					sw.WriteLine($"For Run {runCounter}");
					sw.WriteLine("Job|StartingTickCount|Thread|Elapsed|Actual|Target|TimePerMessage{ms}|TimeToGetManagedClient(ms)|NumUniqueMessageClients");

					IList<int> uniqueThreads = new List<int>();
					int totalMessagesSent = 0;
					double[] sendTimes = new double[taskCount];

					for (int jobCounter = 0; jobCounter < taskCount; jobCounter++)
					{
						string messageTemplate = $"Job:{jobCounter}, Sample Message";
						//Thread.Sleep(taskSpacingMs);
						long startingTickCount = JobRunnerHelper.GetDurationInTicks(ref _currentTickCount);

						string oLine;
						try
						{
							JobResult r = SendRequests(runCounter, jobCounter, messagesToSendPerTask, messageTemplate, gateway, serviceWorkDelayMs, responseCorrelationIdInfo, startingTickCount);

							oLine = string.Format("{0}|{1}|{2}|{3}|{4}|{5}|{6:F3}|{7}|{8}",
								jobCounter, r.StartingTickCount, r.ThreadId, r.Elapsed.ToString(@"mm\:ss\.fff"), r.MessagesSent, messagesToSendPerTask, r.AverageTimeToSendMessageMs, r.AverageTimeToGetManagedClientMs, r.NumberUniqueMessageClientsUsed);

							if (!uniqueThreads.Contains(r.ThreadId)) uniqueThreads.Add(r.ThreadId);

							totalMessagesSent += r.MessagesSent;
							sendTimes[jobCounter] = r.AverageTimeToSendMessageMs;
						}

						catch (AggregateException e)
						{
							mainSw.Stop();
							Console.WriteLine("\nThe following exceptions have been thrown by WaitAll():");
							Debug.WriteLine("\nThe following exceptions have been thrown by WaitAll():");
							for (int j = 0; j < e.InnerExceptions.Count; j++)
							{
								Console.WriteLine("\n-------------------------------------------------\n{0},{1}", j, e.InnerExceptions[j].ToString());
								Debug.WriteLine("\n-------------------------------------------------\n{0},{1}", j, e.InnerExceptions[j].ToString());
								if (e.InnerExceptions[j].InnerException != null)
								{
									Console.WriteLine("\n-------------------------------------------------\n{0},{1}", j, e.InnerExceptions[j].InnerException.ToString());
									Debug.WriteLine("\n-------------------------------------------------\n{0},{1}", j, e.InnerExceptions[j].InnerException.ToString());
								}
							}

							oLine = string.Format("{0}|{1}|{2}|{3}|{4}|{5}",
								runCounter, jobCounter, 0, 0, 0, 0, messagesToSendPerTask);

							sendTimes[jobCounter] = 0;
						}

						sw.WriteLine(oLine);
					}

					TimeSpan overallDuration = mainSw.Elapsed;

					int totalSent = taskCount * messagesToSendPerTask;
					double sentPerSec = totalSent / overallDuration.TotalSeconds;
					double timePerWebServiceCall = overallDuration.TotalSeconds / taskCount;
					timePerWebServiceCall *= 1000;

					PoolStats stats = gateway.GetPoolStats();
					//Debug.WriteLine($"Total Allocated: {stats.NumberAllocated}, Free: {stats.NumberFree}, Total Uses: {stats.ClientsSumOfProvidedCount}, Total Returns: {stats.ClientsSumOfFreedCount}.");
					Debug.WriteLine($"Allocated: {stats.NumberAllocated}, Free: {stats.NumberFree}, Requests(s/f): {stats.RequestsSF}, Returns(s/f): {stats.ReturnsSF}, Created/Destroyed: {stats.CreatedDestroyed}.");

					Console.WriteLine($"Sent {totalSent} messages in {overallDuration.TotalSeconds} for {sentPerSec} m/s.");

					sw.WriteLine();
					sw.WriteLine(string.Format("Run={0}|NumberUniqueThreads={1}|TotalSent={2}|TotalTime(sec)={3:F4}|MessagePerSecond={4:F3}|TimePerWebServiceCall(ms)={5:F3}|AverageTimeToSendMessage(ms)={6:F3}",
								runCounter, uniqueThreads.Count, totalSent, overallDuration.TotalSeconds, sentPerSec, timePerWebServiceCall, sendTimes.Average()));
					sw.WriteLine();

					runResults[runCounter] = new RunResult(uniqueThreads.Count, totalMessagesSent, overallDuration, JobRunnerHelper.GetAverage(sendTimes));

					if (runCounter < repeatCnt)
					{
						//Console.WriteLine($"Run {repeatCnt} completed, press Enter to continue.");
						//Console.ReadLine();

						Thread.Sleep(settings.PauseDurationBeforeRepeatingMs);
						_currentTickCount = -1;
						mainSw.Restart();
					}
				}
			}

			string servResponse2 = serverController.Stop("Test1");
			Console.WriteLine($"TcpServer sent stop request, has returned {servResponse2}");

			Console.WriteLine("All completed, press Enter to continue.");
			Console.ReadLine();

			return runResults;
		}

		private JobResult SendRequests(int runCounter, int jobCounter, int messagesToSend, string messageTemplate
			, IGateway<IMessageClient> gateway, int serviceWorkDelayMs, CorrelationIdInfo responseCorrelationIdInfo, long startingTickCount)
		{
			TimeSpan elapsed;

			int messageSent = 0;
			IList<string> uniqueMessageClientIds = new List<string>();
			IList<double> sendTimeMs = Enumerable.Repeat(0d, messagesToSend).ToList();
			long timeToGetClient;

			if (serviceWorkDelayMs > 14)
			{
				//Debug.WriteLine($"TestService waiting {delayToSimulateOtherWorkMs}ms to simulate other work.");
				Thread.Sleep(serviceWorkDelayMs);
			}

			Stopwatch g = Stopwatch.StartNew();

			Stopwatch s = Stopwatch.StartNew();
			using (IManagedClient managedClient = GetManagedClient(gateway))
			{
				if (managedClient == null)
				{
					g.Stop();
					s.Stop();
					timeToGetClient = s.ElapsedMilliseconds;
					elapsed = g.Elapsed;
					Debug.WriteLine($"The ManagedClientRunner could not get a ManagedClient from the pool. Took {s.ElapsedMilliseconds} ms");
				}
				else
				{
					s.Stop();
					timeToGetClient = s.ElapsedMilliseconds;

					string strJobCntr = jobCounter.ToString().PadLeft(3);

					for (int messageCounter = 0; messageCounter < messagesToSend; messageCounter++)
					{
						string strMessageCntr = messageCounter.ToString().PadLeft(5);
						string command = $"{messageTemplate}{strMessageCntr}";
						TestMessage001 message = new TestMessage001(command, strJobCntr + strMessageCntr);

						s.Restart();
						try
						{
							string id = managedClient.MessageClientIdentifier;
							if (!uniqueMessageClientIds.Contains(id)) uniqueMessageClientIds.Add(id);

							TestResponse001 response = SendRequest(managedClient, message, responseCorrelationIdInfo, s);
							s.Stop();

							if(response.Succeeded)
							{
								messageSent++;
							}
						}
						catch (Exception e)
						{
							s.Stop();
							string errorMessage = e.GetBaseException().Message;
							Debug.WriteLine($"ManagedClientRunner received {errorMessage}");
						}

						sendTimeMs[messageCounter] = s.ElapsedMilliseconds;
					}

					g.Stop();
					elapsed = g.Elapsed;
				}
			}

			string numSentOfCountMsg = $"Sent {messageSent} out of {messagesToSend}";
			Console.WriteLine("run={0}, i={1}, TickCount={2}, Thread={3}, elapsed={4}, sent:{5}",
				runCounter, jobCounter, startingTickCount, Thread.CurrentThread.ManagedThreadId, elapsed.ToString(@"mm\:ss\.fff"), numSentOfCountMsg);

			Debug.WriteLine("Run={0}, i={1}, TickCount={2}, Thread={3}, elapsed={4}, sent:{5}",
				runCounter, jobCounter, startingTickCount, Thread.CurrentThread.ManagedThreadId, elapsed.ToString(@"mm\:ss\.fff"), numSentOfCountMsg);

			JobResult result = new JobResult(startingTickCount, Thread.CurrentThread.ManagedThreadId, elapsed, messageSent)
			{
				AverageTimeToSendMessageMs = sendTimeMs.Average(),
				AverageTimeToGetManagedClientMs = timeToGetClient,
				NumberUniqueMessageClientsUsed = uniqueMessageClientIds.Count
			};

			return result;
		}

		private TestResponse001 SendRequest(IManagedClient managedClient, TestMessage001 message, CorrelationIdInfo responseCorrelationIdInfo, Stopwatch s)
		{
			TestResponse001 result;

			string strMessage = message.ToMessage();
			string strResponse;
			long e1 = s.ElapsedMilliseconds;

			try
			{
				strResponse = managedClient.SendAndReadResponse(strMessage, message.CorrelationId, responseCorrelationIdInfo);

				result = new TestResponse001(strResponse, strMessage);
				//Debug.WriteLine($"The ManagedClientRunner took {s.ElapsedMilliseconds - e1} ms to send {message.Command}.");
			}
			catch (Exception e)
			{
				strResponse = $"The ManagedClientRunner took {s.ElapsedMilliseconds - e1} ms, and then raised exception {e.GetType()}:{e.Message} while sending {message.Command}.";
				Debug.WriteLine(strResponse);

				result = new TestResponse001(strResponse, strMessage)
				{
					Succeeded = false
				};
			}

			return result;
		}

		private IManagedClient GetManagedClient(IGateway<IMessageClient> gateway)
		{
			try
			{
				IManagedClient managedClient = Task.Run(() => gateway.GetManagedClientAsync()).GetAwaiter().GetResult();
				return managedClient;
			}
			catch (Exception e)
			{
				Debug.WriteLine($"The ManagedClientRunner could not get a client from the gateway. {e.GetType()}: {e.Message}");
				return null;
			}
		}

	}
}
