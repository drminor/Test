﻿using System;

namespace ClientRunnerConsole
{
	class JobResult
	{
		public readonly long StartingTickCount;
		public readonly int ThreadId;
		public readonly TimeSpan Elapsed;
		public readonly int MessagesSent;

		public int NumberUniqueMessageClientsUsed { get; set; }
		public double AverageTimeToSendMessageMs { get; set; }
		public double AverageTimeToGetManagedClientMs { get; set; }

		public JobResult(long startingTickCount, int threadId, TimeSpan elapsed, int messagesSent)
		{
			StartingTickCount = startingTickCount;
			ThreadId = threadId;
			Elapsed = elapsed;
			MessagesSent = messagesSent;
		}
	}
}
