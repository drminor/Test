﻿using System;
using System.Net;

namespace ClientRunnerConsole
{
	class RunSettings
	{
		public readonly IPAddress TcpServerAddress;
		public readonly JobType JobType;

		public RunSettings(IPAddress tcpServerAddress, JobType jobType)
		{
			TcpServerAddress = tcpServerAddress ?? throw new ArgumentNullException(nameof(tcpServerAddress));
			JobType = jobType;
		}

		public bool RunSynchronously => JobType == JobType.ManagedClients || JobType == JobType.WebServiceClients;

		public string GetShortJobTypeName()
		{
			switch(JobType)
			{
				case JobType.ManagedClients: return "mc";
				case JobType.WebServiceClients: return "wcf";
				case JobType.ManagedClientsAsync: return "mc-a";
				case JobType.WebServiceClientsAsync: return "wcf-a";
				default: return "unk";
			}
		}
	}

	enum JobType
	{
		ManagedClients,
		WebServiceClients,
		ManagedClientsAsync,
		WebServiceClientsAsync
	}
}
