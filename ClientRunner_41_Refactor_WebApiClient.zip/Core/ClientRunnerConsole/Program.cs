﻿using ClientRunnerLib;
using GatewayLib.ClientPool;
using System;
using System.Diagnostics;
using System.Net;
using System.Net.Sockets;
using TcpProtocolLib;

namespace ClientRunnerConsole
{
	class Program
	{
		private static readonly int TEST_SERVER_PORT = 11234;
		private static readonly string WEB_API_BASE_ADDRESS = "https://localhost:44370";

		static void Main(string[] args)
		{
			JobRunnerHelper.IsRunningOnNetCore = true;

			RunSettings runSettings = ParseArgs(args);

			//RunSettings runSettingsLocal1 = new RunSettings(IPAddress.Loopback, JobType.ManagedClientsAsync);
			//RunSettings runSettingsLocal2 = new RunSettings(IPAddress.Loopback, JobType.ManagedClients);
			RunSettings runSettingsLocal3 = new RunSettings(IPAddress.Loopback, JobType.WebServiceClientsAsync);

			//IPAddress remoteTcpServerAddress = IPAddress.Parse("192.168.3.124");
			//RunSettings runSettingsRemote1 = new RunSettings(remoteTcpServerAddress, JobType.ManagedClientsAsync);
			//RunSettings runSettingsRemote2 = new RunSettings(remoteTcpServerAddress, JobType.ManagedClients);
			//RunSettings runSettingsRemote3 = new RunSettings(remoteTcpServerAddress, JobType.WebServiceClientsAsync);

			//RunSettings runSettings = runSettingsLocal3;

			runSettings = runSettingsLocal3;

			Console.WriteLine($"Running {runSettings.JobType}");
			Debug.WriteLine($"Running {runSettings.JobType}");

			Console.WriteLine("Press the Enter key to connect to the Test TcpServer.");
			Console.ReadLine();

			string filePath = JobRunnerHelper.GetRunResultsFilePath(runSettings.GetShortJobTypeName(), isCore: true);
			JobSettings jobSettings = new JobSettings(
				filePath: filePath,
				numberOfTasks: 24,
				messagesToSendPerTask: 5,
				taskSpacingMs: 30,
				repeatCnt: 3,
				pauseDurationBeforeRepeatingMs: 100,
				webServiceWorkDelayMs: 0,
				useClientPool2Implementation: false
			);

			TcpServerSettings tcpServerSettings = new TcpServerSettings
			{
				Port = TEST_SERVER_PORT,
				MessageType = 1,
				CloseConnsAfterNoActivitySeconds = 60,
				ResponseDelayMs1 = 100, // 35,
				ResponseDelayMs2 = 4120, // 200,
				UseResponseDelayMs2Frequency = 0 //0.12 //0.66
			};

			CertInfo certInfo = JobRunnerHelper.GetClientCertInfo();
			ClientPoolSettings clientPoolSettings = new ClientPoolSettings
				(
				serverEndPoint: new IPEndPoint(runSettings.TcpServerAddress, TEST_SERVER_PORT),
				minConnections: 3, //3
				maxConnections: 10,
				allocateClientTimeoutMs: TimeSpan.FromMilliseconds(3 * 1000),
				messageEncoder: new ASCII_MessageEncoder(4),
				messageResponseTimeout: TimeSpan.FromMilliseconds(150),
				certInfo: certInfo
			);

			IPEndPoint endPoint = new IPEndPoint(runSettings.TcpServerAddress, SharedSettings.TCP_SERVER_CONTROL_PORT);
			IPAddress localIpAddress = GetLocalHostIpAddress();
			Console.WriteLine($"Connecting to TcpServerController: {endPoint} from {localIpAddress}.");
			Debug.WriteLine($"Connecting to TcpServerController: {endPoint} from {localIpAddress}.");

			using TcpServerControllerClient tcpServerController = new TcpServerControllerClient(endPoint, certInfo);
			using ClientPoolControllerClient clientPoolSettingsController = new ClientPoolControllerClient(WEB_API_BASE_ADDRESS);

			RunResult[] runResults = null;

			switch(runSettings.JobType)
			{
				case JobType.ManagedClients:
					{
						ManagedClientJobRunner managedClientJobRunner = new ManagedClientJobRunner();
						runResults = managedClientJobRunner.Run(jobSettings, tcpServerController, tcpServerSettings, clientPoolSettings);
						break;
					}

				case JobType.ManagedClientsAsync:
					{
						ManagedClientJobRunnerAsync managedClientJobRunner = new ManagedClientJobRunnerAsync();
						runResults = managedClientJobRunner.Run(jobSettings, tcpServerController, tcpServerSettings, clientPoolSettings);
						break;
					}

				case JobType.WebServiceClients:
					throw new NotImplementedException("Only Async is supported for .net Core.");

				case JobType.WebServiceClientsAsync:
					{
						WebApiJobRunner webApiJobRunner = new WebApiJobRunner();
						runResults = webApiJobRunner.Run(jobSettings, tcpServerController, tcpServerSettings, clientPoolSettings, WEB_API_BASE_ADDRESS, clientPoolSettingsController);
						break;
					}
			}

			// TODO: Do something with the runResults variable.

			Console.WriteLine("Press the Enter key to exit.");
			Console.ReadLine();
		}

		private static RunSettings ParseArgs(string[] args)
		{
			IPAddress address;
			JobType jobType;

			if (args.Length > 0)
			{
				if (args[0].ToLower() == "localhost")
					address = IPAddress.Loopback;
				else
					address = IPAddress.Parse(args[0]);
			}
			else
			{
				address = GetLocalHostIpAddress();
			}

			if (args.Length > 1)
			{
				string strJobType = args[1].ToLower();
				if (strJobType.Contains("managed-async"))
				{
					jobType = JobType.ManagedClientsAsync;
				}
				else if (strJobType.Contains("managed"))
				{
					jobType = JobType.ManagedClients;
				}
				else if (strJobType.Contains("web-async"))
				{
					jobType = JobType.WebServiceClientsAsync;
				}
				else if (strJobType.Contains("web"))
				{
					jobType = JobType.WebServiceClients;
				}
				else
				{
					throw new ArgumentException("The 2nd argument is missing or does not specify a supported JobType.");
				}
			}
			else
			{
				jobType = JobType.ManagedClients;
			}

			return new RunSettings(address, jobType);
		}

		private static IPAddress GetLocalHostIpAddress()
		{
			IPHostEntry host = Dns.GetHostEntry(Environment.MachineName);
			foreach (IPAddress IP in host.AddressList)
			{
				if (IP.AddressFamily == AddressFamily.InterNetwork)
				{
					return IP;
				}
			}

			return null;
		}

	}
}
