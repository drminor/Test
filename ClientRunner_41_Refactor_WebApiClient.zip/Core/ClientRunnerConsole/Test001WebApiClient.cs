﻿using ClientRunnerLib;
using System;
using System.Diagnostics;
using System.Net.Http;
using System.Text;
using System.Text.Json;
using System.Threading;
using System.Threading.Tasks;

namespace ClientRunnerConsole
{
	class Test001WebApiClient
	{
		private readonly string _endpoint;
		private readonly HttpClient _httpClient;

		public Test001WebApiClient(string webApiServiceBaseAddress)
		{
			_endpoint = webApiServiceBaseAddress + "/SendMessages";
			_httpClient = new HttpClient();
		}

		public async Task<JobResult> SendRequestsAsync(int runCounter, TestServiceRequest request, long startingTickCount)
		{
			int messagesToSend = request.MessagesToSend;
			int jobCounter = request.JobCntr;

			TimeSpan elapsed;
			Stopwatch s = Stopwatch.StartNew();
			TestServiceResult serviceResult;

			try
			{
				//serviceResult = null; //await webService.SendMessagesAsync(messagesToSend, jobCounter, messageTemplate, serviceWorkDelayMs);
				serviceResult = await SendMessagesAsync(request);
			}
			catch (Exception e)
			{
				serviceResult = null;
				string errorMessage = e.GetBaseException().Message;
				Debug.WriteLine($"Job received {errorMessage}");
			}

			s.Stop();
			//webService.Close();

			elapsed = s.Elapsed;

			int messagesSent = serviceResult?.MessagesSent ?? 0;
			string resultStatus = $"Sent {messagesSent} out of {messagesToSend}";
			Console.WriteLine("Run={0} | Job={1} | TickCount={2} | Thread={3} | elapsed={4} | sent:{5}",
				runCounter, jobCounter, startingTickCount, Thread.CurrentThread.ManagedThreadId, elapsed.ToString(@"mm\:ss\.fff"), resultStatus);

			Debug.WriteLine("Run={0} | Job={1} | TickCount={2} | Thread={3} | elapsed={4} | sent:{5}",
				runCounter, jobCounter, startingTickCount, Thread.CurrentThread.ManagedThreadId, elapsed.ToString(@"mm\:ss\.fff"), resultStatus);

			JobResult result = new JobResult(startingTickCount, Thread.CurrentThread.ManagedThreadId, elapsed, messagesSent)
			{
				AverageTimeToSendMessageMs = serviceResult?.AverageTimeToSendMessageMs ?? 0,
				AverageTimeToGetManagedClientMs = serviceResult?.AverageTimeToGetManagedClientMs ?? 0,
				NumberUniqueMessageClientsUsed = serviceResult?.NumberUniqueMessageClientsUsed ?? 0
			};

			return result;
		}

		public async Task<TestServiceResult> SendMessagesAsync(TestServiceRequest request)
		{
			TestServiceResult result;

			var jsonRequest = JsonSerializer.Serialize(request);
			StringContent content = new StringContent(jsonRequest, Encoding.UTF8, "application/json");

			using var response = await _httpClient.PostAsync(_endpoint, content);

			if (response.StatusCode == System.Net.HttpStatusCode.OK)
			{
				string strResponse = await response.Content.ReadAsStringAsync();
				using var responseStream = await response.Content.ReadAsStreamAsync();
				result = await JsonSerializer.DeserializeAsync<TestServiceResult>(responseStream);
			}
			else
			{
				result = null;
			}

			return result;
		}
	}
}
