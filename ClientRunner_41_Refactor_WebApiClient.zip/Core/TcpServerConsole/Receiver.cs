﻿using ClientRunnerLib;
using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.IO;
using System.Linq;
using System.Net.Security;
using System.Net.Sockets;
using System.Security.Authentication;
using System.Security.Cryptography.X509Certificates;
using System.Threading.Tasks;
using TcpProtocolLib;

namespace TcpServerConsole
{
	class Receiver : IReceiver
	{
		private const int TASK_SHUTDOWN_TIMEOUT_SECONDS = 1;
		private const int BUFFER_SIZE = 1024;
		private const int MAX_MESSAGE_SIZE = 0; // No Maximum.

		private readonly TcpClient _tcpClient;
		private SslStream _stream;
		private readonly CertInfo _certInfo;

		private readonly IRequestHandler _requestHandler;
		private readonly IMessageEncoder _messageEncoder;
		private readonly string _typeName;

		public DateTime LastCalled { get; private set; }
		private Task _messagesReceiverTask;
		private readonly object _stateLock;

		private readonly int[] _delaySequence;
		private int _counter1;
		private int _counter2;

		private readonly bool _useDetailedDebug = false;

		public Receiver(TcpClient client, TcpServerSettings settings, IRequestHandler requestHandler, string typeName)
        {
			_stateLock = new object();

			LastCalled = DateTime.Now;

            _tcpClient = client;
            _tcpClient.ReceiveBufferSize = BUFFER_SIZE;
            _tcpClient.SendBufferSize = BUFFER_SIZE;

			_certInfo = JobRunnerHelper.GetServerCertInfo();

			_counter1 = 0;
			_counter2 = 0;
			_delaySequence = BuildDelaySequence(settings);

			_requestHandler = requestHandler;
			_messageEncoder = new ASCII_MessageEncoder(4);
			_typeName = typeName;
		}

		public void Start()
		{
			_messagesReceiverTask = ReceiveMessagesAsync(_tcpClient, _certInfo);
		}

		private async Task<ReadBufferResult> ReceiveMessagesAsync(TcpClient client, CertInfo certInfo)
		{
			Packetizer packetizer = new Packetizer(MAX_MESSAGE_SIZE, _messageEncoder);
			_stream = GetSslStream(client, certInfo);
			byte[] myReadBuffer = new byte[BUFFER_SIZE];

			try
			{
				ReadBufferResult result;

				do
				{
					result = await ReadBufAsync(myReadBuffer, _stream);
					if (result.BytesRead > 0)
					{
						IEnumerable<string> messages = packetizer.PushData(myReadBuffer, result.BytesRead);
						foreach (string message in messages)
						{
							if (message != null)
							{
								LastCalled = DateTime.Now;
								string response = _requestHandler.GetResponse(message);

								if(_useDetailedDebug) Debug.WriteLine($"A {_typeName} receiver is now sending the response of {response}");
								var _ = SendMessageAsync(response, _stream);
							}
						}
					}
					else if (result.Exception != null && !ShouldStop(result.Exception))
					{
						Debug.WriteLine($"A {_typeName} receiver encountered {result.Exception.GetType()}: {result.Exception.Message}. Recevier is continuing.");
					}
				}
				while (result.BytesRead != 0 && !ShouldStop(result.Exception));

				if (result.BytesRead == 0)
				{
					Debug.WriteLine($"A {_typeName} receiver is stopping 0 bytes were read -- peer is closing the connection.");
				}
				else
				{
					Debug.WriteLine($"A {_typeName} receiver is stopping due to {result.Exception.GetType()}: {result.Exception.Message}.");
				}

				return result;
			}
			catch (Exception e)
			{
				// This should never happen.
				Debug.WriteLine($"A {_typeName} receiver's messagesReceiverTask encountered exception {e.GetType()}: {e.Message}");
				return new ReadBufferResult(new SendRequestException(SendRequestOperation.Read, e));
			}
		}

		private bool ShouldStop(Exception e)
		{
			if(e == null) return false;
			if (e is SendRequestException sre && sre.ErrorCode == SendRequestError.ClientIsDisposed) return true;
			if (e?.InnerException is IOException ioe && ioe?.InnerException is SocketException se && se.SocketErrorCode == SocketError.ConnectionReset) return true;
			return false;
		}

		private async Task<ReadBufferResult> ReadBufAsync(byte[] myReadBuffer, SslStream stream)
		{
			try
			{
				int bytesRead = await stream.ReadAsync(myReadBuffer, 0, myReadBuffer.Length);
				return new ReadBufferResult(bytesRead);
			}
			catch (ObjectDisposedException)
			{
				if(_useDetailedDebug) Debug.WriteLine($"Received ObjectDisposedException while a {_typeName} Receiver trying to read.");
				return new ReadBufferResult(new SendRequestException("TcpClient is disposed while reading.", SendRequestOperation.Read, SendRequestError.ClientIsDisposed));
			}
			catch (SocketException se)
			{
				return new ReadBufferResult(new SendRequestException(SendRequestOperation.Read, se));
			}
			catch (IOException ie)
			{
				return new ReadBufferResult(new SendRequestException(SendRequestOperation.Read, ie));
			}
			catch (Exception e)
			{
				Debug.WriteLine($"Received system exception {e.GetType()}: {e.Message} while a {_typeName} Receiver is trying to read from the stream.");
				return new ReadBufferResult(new SendRequestException("SystemException on Read, see inner exception for details", SendRequestOperation.Read, e));
			}
		}

		private SslStream GetSslStream(TcpClient client, CertInfo certInfo)
		{
			var clientCertificateCollection = new X509CertificateCollection(new X509Certificate[] { certInfo.PeersPublicCert });

			var sslStream = new SslStream(client.GetStream(), false, CertHelper.ValidateRemoteCert, CertHelper.SelectLocalCertificate);

			sslStream.AuthenticateAsServer(certInfo.OurPrivateCert, true, SslProtocols.Tls12, false);
			return sslStream;
		}

		private async Task SendMessageAsync(string response, SslStream stream)
		{
			int delay = GetDelay(ref _counter2, _counter1++);
			if(delay > 14)
			{
				if (_useDetailedDebug) Debug.WriteLine($"{_typeName} receiver is delaying send by {delay} ms.");
				await Task.Delay(delay);
			}

			byte[] packet = _messageEncoder.CreatePacket(response);
			await stream.WriteAsync(packet, 0, packet.Length);
		}

		private int GetDelay(ref int counter2, int counter1)
		{
			int nextDelay = _delaySequence[counter2];

			// reuse delay for two operations.
			if (0 == counter1 % 2) counter2++;
			
			if (counter2 > 999) counter2 = 0;

			return nextDelay;
		}

		public bool IsConnected
		{
			get
			{
				lock (_stateLock)
				{
					bool result;
					if (_isClosed)
					{
						Debug.WriteLine($"A {_typeName} Receiver was found to be disposed when accessing its IsConnected property.");
						result = false;
					}
					else
					{
						if (_messagesReceiverTask.IsCompleted)
							result = false;
						else 
							result = _tcpClient.Connected;
					}

					return result;
				}
			}
		}

		private int[] BuildDelaySequence(TcpServerSettings settings)
		{
			int[] result;

			if (settings.UseResponseDelayMs2Frequency < 0.001)
			{
				result = Enumerable.Repeat(settings.ResponseDelayMs1, 1000).ToArray();
			}
			else
			{
				result = Enumerable.Range(0, 1000).ToArray();
				Shuffle(result);
				result = result.Select(i => settings.UseResponseDelayMs2Frequency > (double)i / 1000 ? settings.ResponseDelayMs2 : settings.ResponseDelayMs1).ToArray();
			}

			return result;
		}

		private void Shuffle(int[] array)
		{
			Random rng = new Random();
			int n = array.Length;
			while (n > 1)
			{
				int k = rng.Next(n--);
				int temp = array[n];
				array[n] = array[k];
				array[k] = temp;
			}
		}

		#region IDisposable Support

		private void StopReceiver()
		{
			try
			{
				bool didComplete = _messagesReceiverTask.Wait(TimeSpan.FromSeconds(TASK_SHUTDOWN_TIMEOUT_SECONDS));
				if (!didComplete)
				{
					Debug.WriteLine($"The reader task for a ServerReceiver failed to stop within {TASK_SHUTDOWN_TIMEOUT_SECONDS} seconds.");
				}
			}
			catch (Exception e)
			{
				Debug.WriteLine($"The ServerReceiver reader task returned exception: {e.Message}.");
			}
		}

		private bool _isClosed;
		private bool disposedValue;

		protected virtual void Dispose(bool disposing)
		{
			if (!disposedValue)
			{
				lock (_stateLock)
				{
					if (disposing)
					{
						// Dispose managed state (managed objects)

						try
						{
							_tcpClient.Close();
							if (_stream != null) _stream.Dispose();
							if (_certInfo != null) _certInfo.Dispose();
						}
						catch (Exception e)
						{
							// ignore all errors.
							Debug.WriteLine($"Receiver got {e.GetType()}:{e.Message}.");
						}

						StopReceiver();
						if (_messagesReceiverTask.IsCompleted) _messagesReceiverTask.Dispose();
						_isClosed = true;
					}

					disposedValue = true;
				}
			}
		}

		public void Dispose()
		{
			// Do not change this code. Put cleanup code in 'Dispose(bool disposing)' method
			Dispose(disposing: true);
		}

		#endregion

		private class ReadBufferResult
		{
			public readonly int BytesRead;
			public readonly SendRequestException Exception;

			public ReadBufferResult(int bytesRead)
			{
				BytesRead = bytesRead;
				Exception = null;
			}

			public ReadBufferResult(SendRequestException exception)
			{
				BytesRead = -1;
				Exception = exception;
			}
		}

	}
}
