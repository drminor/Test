﻿using ClientRunnerLib;
using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Linq;
using System.Net;
using System.Net.Sockets;
using System.Threading;
using System.Threading.Tasks;

namespace TcpServerConsole
{
	class MessageServer : IMessageServer
	{
		public const int STOP_TIMEOUT_SECONDS = 1;

		public string TypeName { get; }
		public bool IsStarted { get; private set; }

		readonly IPEndPoint _endPoint;
		readonly TcpServerSettings _settingsForNewReceivers;
		readonly IRequestHandler _requestHandler;

		readonly List<IReceiver> _receivers;
		readonly TcpListener _listener;

		CancellationTokenSource _cts;
		readonly ReaderWriterLockSlim _locker;

		readonly int _closeAfterNoActivity;

		Task _removeDisconnectedTask;

		public MessageServer(string typeName, IPEndPoint endPoint, TcpServerSettings settings, IRequestHandler requestHandler)
		{
			TypeName = typeName;
			_endPoint = endPoint;
			_settingsForNewReceivers = settings;
			_requestHandler = requestHandler;

			_closeAfterNoActivity = settings.CloseConnsAfterNoActivitySeconds;

			_receivers = new List<IReceiver>();
			_listener = new TcpListener(_endPoint);
			_locker = new ReaderWriterLockSlim();
			_cts = null;
		}

		public void Start()
		{
			if (!IsStarted)
			{
				_listener.Start();
				IsStarted = true;

				WaitForConnection();

				_cts = new CancellationTokenSource();
				_removeDisconnectedTask = RemoveDisconnectedReceiversAsync(_cts.Token);
			}
		}

		private void WaitForConnection()
		{
			_listener.BeginAcceptTcpClient(new AsyncCallback(ConnectionHandler), null);
		}

		private void ConnectionHandler(IAsyncResult ar)
		{
			_locker.EnterWriteLock();

			try
			{
				if (!IsStarted) return;
				TcpClient client = _listener.EndAcceptTcpClient(ar);

				IReceiver receiver = new Receiver(client, _settingsForNewReceivers, _requestHandler, TypeName);

				receiver.Start();
				_receivers.Add(receiver);
				Console.WriteLine($"Added a new {TypeName} receiver for client {client.Client.RemoteEndPoint}. There are now {_receivers.Count()} receivers.");
			}
			finally
			{
				_locker.ExitWriteLock();
			}

			WaitForConnection();
		}

		private async Task RemoveDisconnectedReceiversAsync(CancellationToken token)
		{
			while (IsStarted)
			{
				try
				{
					await Task.Delay(5 * 1000, token);
				}
				catch (OperationCanceledException)
				{
					break;
				}

				// Remove Disconnected.
				Func<IReceiver, bool> selectFunc = (x => !x.IsConnected);
				int countRemoved = RemoveReceivers(selectFunc);
				if (countRemoved > 0)
					Console.WriteLine($"Removed {countRemoved} disconnected receivers.");

				// Remove Inactive.
				if (_closeAfterNoActivity > 0)
				{
					TimeSpan noActivityDuration = TimeSpan.FromSeconds(_closeAfterNoActivity);
					DateTime now = DateTime.Now;
					selectFunc = x => now - x.LastCalled > noActivityDuration;
					countRemoved = RemoveReceivers(selectFunc);
					if (countRemoved > 0)
						Console.WriteLine($"Removed {countRemoved} receivers that have not been called in the last {_closeAfterNoActivity} seconds.");
				}
			}
		}

		private int RemoveReceivers(Func<IReceiver, bool> selectFunc)
		{
			_locker.EnterUpgradeableReadLock();
			try
			{
				DateTime now = DateTime.Now;
				List<IReceiver> disconnectedReceivers = _receivers.Where(selectFunc).ToList();

				_locker.EnterWriteLock();
				try
				{
					foreach (IReceiver r in disconnectedReceivers)
					{
						_receivers.Remove(r);
						r.Dispose();
					}
				}
				finally
				{
					_locker.ExitWriteLock();
				}

				return disconnectedReceivers.Count;
			}
			finally
			{
				_locker.ExitUpgradeableReadLock();
			}
		}

		public string Stop(out bool success)
		{
			string result;
			_locker.EnterWriteLock();

			try
			{
				if (IsStarted)
				{
					_listener.Stop();
					ClearReceivers();
					IsStarted = false;

					_cts.Cancel();
					if (_removeDisconnectedTask.Wait(TimeSpan.FromSeconds(STOP_TIMEOUT_SECONDS)))
					{
						result = $"Message server {TypeName} was stopped";
						success = true;
					}
					else
					{
						Debug.WriteLine("The task used to cleanup unused connections failed to exit after waiting for 10 seconds.");
						result = $"Message server {TypeName} did not stop after waiting for {STOP_TIMEOUT_SECONDS} seconds.";
						success = false;
					}
					_cts.Dispose();
					_cts = null;
				}
				else
				{
					result = "The message server {TypeName} was already stopped.";
					success = true;
				}

				return result;
			}
			finally
			{
				_locker.ExitWriteLock();
			}
		}

		private void ClearReceivers()
		{
			foreach (IReceiver receiver in _receivers)
			{
				receiver.Dispose();
			}
		}


	}
}
