﻿using System;
using System.Collections.Generic;
using System.Linq;
using TcpProtocolLib;
using Xunit;

namespace UnitTests
{
	public class PacketizerTest
	{

		[Fact]
		public void Should_Get_One_Message_When_Sending_Entire_Message()
		{
			IMessageEncoder messageEncoder = new ASCII_MessageEncoder(4);
			Packetizer packetizer = new Packetizer(0, messageEncoder);

			string message = "Hello There";
			byte[] packet = messageEncoder.CreatePacket(message);
			IList<string> messagesReceived = packetizer.PushData(packet, packet.Length).ToList();

			Assert.True(1 == messagesReceived.Count, $"Received {messagesReceived.Count} messages, expecting 1.");
			Assert.True(message == messagesReceived[0], "Received Message 1 does not match sent value.");
		}

		[Fact]
		public void Should_Get_One_Message_When_Sending_Message_In_Two_Sections()
		{
			IMessageEncoder messageEncoder = new ASCII_MessageEncoder(4);
			Packetizer packetizer = new Packetizer(0, messageEncoder);

			string message = "Hello There";
			byte[] packet = messageEncoder.CreatePacket(message);

			byte[] part1 = new byte[7];
			byte[] part2 = new byte[packet.Length - 7];

			Array.Copy(packet, part1, part1.Length);
			Array.Copy(packet, 7, part2, 0, part2.Length);

			IList<string> messagesReceived1 = packetizer.PushData(part1, part1.Length).ToList();

			IList<string> messagesReceived2 = packetizer.PushData(part2, part2.Length).ToList();

			IList<string> messagesReceived = messagesReceived2.Concat(messagesReceived1).Where(x => x != null).ToList();

			Assert.True(1 == messagesReceived.Count, $"Received {messagesReceived.Count} messages, expecting 1.");
			Assert.True(message == messagesReceived[0], "Received Message 1 does not match sent value.");
		}

		[Fact]
		public void Should_Get_Two_Messages_When_Sending_Both_Together()
		{
			IMessageEncoder messageEncoder = new ASCII_MessageEncoder(4);
			Packetizer packetizer = new Packetizer(0, messageEncoder);

			string message1 = "Hello There";
			byte[] packet1 = messageEncoder.CreatePacket(message1);

			string message2 = "Welcome to my humble abode.";
			byte[] packet2 = messageEncoder.CreatePacket(message2);

			byte[] both = new byte[packet1.Length + packet2.Length];

			Array.Copy(packet1, both, packet1.Length);
			Array.Copy(packet2, 0, both, packet1.Length, packet2.Length);
			IList<string> messagesReceived = packetizer.PushData(both, both.Length).ToList();

			Assert.True(2 == messagesReceived.Count, $"Received {messagesReceived.Count} messages, expecting 2.");
			Assert.True(message1 == messagesReceived[0], "Received Message 1 does not match sent value.");
			Assert.True(message2 == messagesReceived[1], "Received Message 2 does not match sent value.");
		}

	}
}
