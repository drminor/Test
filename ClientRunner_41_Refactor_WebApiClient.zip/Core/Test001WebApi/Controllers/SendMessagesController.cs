﻿using ClientRunnerLib;
using GatewayLib.Gateway;
using GatewayLib.Tcp;
using Microsoft.AspNetCore.Mvc;
using System.Diagnostics;
using System.Threading.Tasks;
using Test001WebApi.Handlers;

namespace Test001WebApi.Controllers
{
	[ApiController]
	[Route("[controller]")]
	public class SendMessagesController : ControllerBase
	{
		private readonly IGateway<IMessageClient> _gateway;
		private readonly bool _useDetailedDebug = true;

		public SendMessagesController(GatewayFactory<IMessageClient> gatewayProvider)
		{
			_gateway = gatewayProvider.Gateway;

			if (_useDetailedDebug) Debug.WriteLine($"SendMessagesController got gateway: {_gateway}");

			//IManagedClient mc = GetManagedClient(_gateway);
		}

		[HttpGet]
		public string Ping()
		{
			return $"Hi There - SendMessagesController. Gateway = {_gateway}";
		}

		[HttpPost]
		[ProducesResponseType(200)]
		public async Task<ActionResult<TestServiceResult>> PostSendMessages(TestServiceRequest request)
		{
			if (_useDetailedDebug) Debug.WriteLine($"PostSendMessages received request: {request}.");

			Test001Handler test001Handler = new Test001Handler(_gateway);
			TestServiceResult result = await test001Handler.SendMessagesAsync(request);

			var ar = new ActionResult<TestServiceResult>(result);
			return ar;
		}

		//// Only For Testing
		//private IManagedClient GetManagedClient(IGateway<IMessageClient> gateway)
		//{
		//	try
		//	{
		//		IManagedClient managedClient = Task.Run(() => gateway.GetManagedClientAsync()).GetAwaiter().GetResult();
		//		return managedClient;
		//	}
		//	catch (Exception e)
		//	{
		//		Debug.WriteLine($"The SendMessagesController could not get a client from the gateway. {e.GetType()}: {e.Message}");
		//		return null;
		//	}
		//}
	}

}
