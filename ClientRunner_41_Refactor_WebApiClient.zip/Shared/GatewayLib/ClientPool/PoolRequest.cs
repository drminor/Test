﻿using System;
using System.Threading.Tasks;
using GatewayLib.Tcp;

namespace GatewayLib.ClientPool
{
	internal struct PoolRequest<T> where T: class, IMessageClient
	{
		public readonly string Id;
		public readonly DateTime ExpireDate;
		public readonly bool IsGetClient;
		public readonly TaskCompletionSource<T> Tcs;
		public readonly T Client;

		public bool IsReturn => !IsGetClient;
		public bool IsEmpty => Tcs == null && Client == null;

		public PoolRequest(TimeSpan timeout, TaskCompletionSource<T> tcs)
		{
			Id = $"G:{Guid.NewGuid()}";
			ExpireDate = DateTime.Now + timeout;
			IsGetClient = true;
			Tcs = tcs ?? throw new ArgumentNullException(nameof(tcs));
			Client = null;
		}

		public PoolRequest(T clientToReturn)
		{
			Id = $"R:{Guid.NewGuid()}";
			ExpireDate = DateTime.Now;
			IsGetClient = false;
			Tcs = null;
			Client = clientToReturn ?? throw new ArgumentNullException(nameof(clientToReturn));
		}

		private PoolRequest(string id)
		{
			Id = id;
			ExpireDate = DateTime.Now;
			IsGetClient = false;
			Tcs = null;
			Client = null;
		}

		public static PoolRequest<T> Empty
		{
			get
			{
				return new PoolRequest<T>("Empty");
			}
		}
	}

}
