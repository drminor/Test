﻿using GatewayLib.ClientPool;
using System;
using System.Threading.Tasks;

namespace GatewayLib.Tcp
{
	public interface IMessageClient : IPooledClient, IDisposable
	{
		string SendAndReadResponse(string message, string correlationId, CorrelationIdInfo correlationIdInfo, string opId);

		Task<string> SendAndReadResponseAsync(string message, string correlationId, CorrelationIdInfo correlationIdInfo, string opId);
	}
}
