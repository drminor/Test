﻿using TcpProtocolLib;

namespace GatewayLib.Tcp
{
	internal class ReadMessageResult
	{
		public readonly string Message;
		public readonly SendRequestException Exception;

		public ReadMessageResult(string message)
		{
			Message = message;
			Exception = null;
		}

		public ReadMessageResult(SendRequestException exception)
		{
			Message = null;
			Exception = exception;
		}
	}
}
