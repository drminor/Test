﻿namespace GatewayLib.Gateway
{
	public enum GatewayError
	{
		//Success = 0,
		ClientPoolIsDisposed = 1,
		Timeout = 2,
		OperationCancelled = 3,
		Other = 4
	}
}
