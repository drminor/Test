﻿using AppProtocolLib;
using System;
using System.Text;

namespace ClientRunnerLib
{
	public class TestMessage001 : IFixedWidthMessage<TestMessage001>
	{
		public static ColumnDictionary _columnDefinitions;

		static TestMessage001()
		{
			_columnDefinitions = new ColumnDictionary();
			_columnDefinitions
				.AddColumnDefinition(nameof(DateCreated), 20)
				.AddColumnDefinition(nameof(Command), 200)
				.AddColumnDefinition(nameof(Extra), 50)
				.AddColumnDefinition(nameof(CorrelationId), 40);
		}

		public string MessageName => nameof(TestMessage001);

		public IColumnDictionary ColumnDefinitions => _columnDefinitions;

		public DateTime DateCreated;
		public string Command;
		public string Extra;
		public string CorrelationId { get; set; }

		public TestMessage001() : this(null, null)
		{
		}

		public TestMessage001(string command, string correlationId)
		{
			DateCreated = DateTime.Now;
			Command = command;
			Extra = null;
			CorrelationId = correlationId;
		}

		public string ToMessage()
		{
			StringBuilder sb = new StringBuilder();

			sb.Append(DateCreated.ToLongTimeString().PadRight(GetLength(nameof(DateCreated))));
			sb.Append(Command.PadRight(GetLength(nameof(Command))));
			sb.Append( (Extra ?? string.Empty).PadRight(GetLength(nameof(Extra))));
			sb.Append(CorrelationId.PadRight(GetLength(nameof(CorrelationId))));

			return sb.ToString();
		}

		public static TestMessage001 CreateNewFromMessage(string m)
		{
			TestMessage001 result = new TestMessage001();

			ColumnDefinition cd = _columnDefinitions[nameof(DateCreated)];
			result.DateCreated = DateTime.Parse(m.Substring(cd.Start, cd.Length));

			cd = _columnDefinitions[nameof(Command)];
			result.Command = m.Substring(cd.Start, cd.Length).TrimEnd();

			cd = _columnDefinitions[nameof(Extra)];
			result.Extra = m.Substring(cd.Start, cd.Length).TrimEnd();

			cd = _columnDefinitions[nameof(CorrelationId)];
			result.CorrelationId = m.Substring(cd.Start, cd.Length).TrimEnd();

			return result;
		}
		
		private int GetLength(string columnName)
		{
			int length = _columnDefinitions[columnName].Length;
			return length;
		}

	}
}
