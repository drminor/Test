﻿using AppProtocolLib;
using System;
using System.Diagnostics;
using System.Text;

namespace ClientRunnerLib
{
	public class TestResponse001 : IFixedWidthMessage<TestResponse001>
	{
		public static ColumnDictionary _columnDefinitions;

		static TestResponse001()
		{
			_columnDefinitions = new ColumnDictionary();
			_columnDefinitions
				.AddColumnDefinition(nameof(DateCreated), 20)
				.AddColumnDefinition(nameof(Response), 200)
				.AddColumnDefinition(nameof(Succeeded), 6)
				.AddColumnDefinition(nameof(CorrelationId), 40);
		}

		public string MessageName => nameof(TestResponse001);

		public IColumnDictionary ColumnDefinitions => _columnDefinitions;

		public DateTime DateCreated { get; set; }
		public string Response { get; set; }
		public bool Succeeded { get; set; }
		public string CorrelationId { get; set; }

		public TestResponse001() 
		{
			DateCreated = DateTime.Now;
			Response = null;
			Succeeded = false;
			CorrelationId = null;
		}

		public TestResponse001(string response, string correlationId) : this(response, correlationId, true)
		{
		}

		public TestResponse001(string response, string correlationId, bool succeeded)
		{
			DateCreated = DateTime.Now;
			Response = response;
			Succeeded = succeeded;
			CorrelationId = correlationId;
		}

		public string ToMessage()
		{
			StringBuilder sb = new StringBuilder();

			sb.Append(DateCreated.ToLongTimeString().PadRight(GetLength(nameof(DateCreated))));
			sb.Append(Response.PadRight(GetLength(nameof(Response))));
			sb.Append(Succeeded.ToString().PadRight(GetLength(nameof(Succeeded))));
			sb.Append(CorrelationId.PadRight(GetLength(nameof(CorrelationId))));

			return sb.ToString();
		}

		//public string GetRequestCorrelationId(string message)
		//{
		//	TestMessage001 temp = TestMessage001.CreateNewFromMessage(message);
		//	string result = temp.CorrelationId;
		//	return result;
		//}

		public static TestResponse001 CreateNewFromMessage(string m)
		{
			TestResponse001 result = new TestResponse001();

			ColumnDefinition cd = _columnDefinitions[nameof(DateCreated)];
			result.DateCreated = DateTime.Parse(m.Substring(cd.Start, cd.Length));

			cd = _columnDefinitions[nameof(Response)];
			result.Response = m.Substring(cd.Start, cd.Length).TrimEnd();

			cd = _columnDefinitions[nameof(Succeeded)];
			result.Succeeded = bool.Parse(m.Substring(cd.Start, cd.Length));

			cd = _columnDefinitions[nameof(CorrelationId)];
 			result.CorrelationId = m.Substring(cd.Start, cd.Length).TrimEnd();

			return result;
		}

		private int GetLength(string columnName)
		{
			int length = _columnDefinitions[columnName].Length;
			return length;
		}

		// Just for testing
		public void CheckTestResponse001(string s)
		{
			TestResponse001 tm = CreateNewFromMessage(s);

			string t = tm.ToMessage();

			Debug.Assert(s == t, "TestResponse001 cannot roundtrip.");
		}


	}
}
