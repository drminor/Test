﻿using GatewayLib.ClientPool;
using GatewayLib.Gateway;
using GatewayLib.Tcp;

namespace ClientRunnerLib
{
	/// <remarks>
	/// This class has been created only for testing.
	/// 
	/// This class supports the use of the ClientPoolSettingsController in being able to change the ClientPoolSettings while the Web Service is running.
	/// 
	/// In production, we only need to build a single instance of a Gateway and register it as a singleton.
	/// </remarks>

	public class GatewayFactory<T> where T : class, IMessageClient
	{
		public ClientPoolSettings ClientPoolSettings { get; private set; }
		public bool UseClientPool2Implementation { get; private set; }

		private IGateway<T> _gateway;

		public GatewayFactory(ClientPoolSettings initialSettings, bool useClientPool2Implementation = false)
		{
			ClientPoolSettings = initialSettings;
			UseClientPool2Implementation = useClientPool2Implementation;
		}

		public IGateway<T> Gateway
		{
			get
			{
				if (_gateway == null)
				{
					_gateway = BuildGateway(ClientPoolSettings, UseClientPool2Implementation);
				}
				return _gateway;
			}

			private set
			{
				_gateway = value;
			}
		}

		public void RefreshGateway(ClientPoolSettings newSettings, bool? useClientPool2Implementation)
		{
			ClientPoolSettings = newSettings;

			if(useClientPool2Implementation.HasValue)
				UseClientPool2Implementation = useClientPool2Implementation.Value;

			if(_gateway != null) 
				_gateway.Dispose();

			_gateway = null;
		}

		public override string ToString()
		{
			return $"Current Gateway = {_gateway}, \nCurrent Settings = \n{ClientPoolSettings}, \nUsePool2 = {UseClientPool2Implementation}.";
		}

		private IGateway<T> BuildGateway(ClientPoolSettings clientPoolSettings, bool useClientPool2Implementation)
		{
			// TODO: Consider making GatewayModule Generic
			IGateway<T> result = (IGateway<T>)GatewayModule.BuildGateway(clientPoolSettings, useClientPool2Implementation);
			return result;
		}
	}

}
