﻿using AppProtocolLib;
using GatewayLib.Tcp;
using System;
using System.Net;
using System.Threading.Tasks;
using TcpProtocolLib;

namespace ClientRunnerLib
{
	public class TcpServerControllerClient : IDisposable
	{
		private readonly IMessageClient _messageClient;

		private readonly CorrelationIdInfo _responseCorrelationIdInfo;

		public TcpServerControllerClient(IPEndPoint endPoint, CertInfo certInfo)
		{
			_messageClient = new MessageClient(
				endPoint: endPoint
				, messageEncoder: new ASCII_MessageEncoder(4)
				, messageResponseTimeout: TimeSpan.FromMilliseconds(25 * 1000)
				, certInfo
			);

			ColumnDefinition corCd = TcpServerControlResponse._columnDefinitions["CorrelationId"];
			_responseCorrelationIdInfo = new CorrelationIdInfo(corCd.Start, corCd.Length);
		}

		public string Start(string key, TcpServerSettings settings)
		{
			TcpServerControlRequest request = new TcpServerControlRequest("Start", key, settings);

			string opId = MessageHelper.GetOpId(1, 1, _messageClient.Identifier);
			string strResponse = _messageClient.SendAndReadResponse(request.ToMessage(), request.CorrelationId, _responseCorrelationIdInfo, opId);
			TcpServerControlResponse response = TcpServerControlResponse.CreateNewFromMessage(strResponse);
			return response.Response;
		}

		public async Task<string> StartAsync(string key, TcpServerSettings settings)
		{
			TcpServerControlRequest request = new TcpServerControlRequest("Start", key, settings);

			string opId = MessageHelper.GetOpId(1, 1, _messageClient.Identifier);
			string strResponse = await _messageClient.SendAndReadResponseAsync(request.ToMessage(), request.CorrelationId, _responseCorrelationIdInfo, opId);
			TcpServerControlResponse response = TcpServerControlResponse.CreateNewFromMessage(strResponse);
			return response.Response;
		}

		public string Stop(string key)
		{
			TcpServerControlRequest request = new TcpServerControlRequest("Stop", key, null);
			string opId = MessageHelper.GetOpId(1, 1, _messageClient.Identifier);
			string strResponse = _messageClient.SendAndReadResponse(request.ToMessage(), request.CorrelationId, _responseCorrelationIdInfo, opId);
			TcpServerControlResponse response = TcpServerControlResponse.CreateNewFromMessage(strResponse);

			return response.Response;
		}

		public async Task<string> StopAsync(string key)
		{
			TcpServerControlRequest request = new TcpServerControlRequest("Stop", key, null);
			string opId = MessageHelper.GetOpId(1, 1, _messageClient.Identifier);
			string strResponse = await _messageClient.SendAndReadResponseAsync(request.ToMessage(), request.CorrelationId, _responseCorrelationIdInfo, opId);
			TcpServerControlResponse response = TcpServerControlResponse.CreateNewFromMessage(strResponse);

			return response.Response;
		}

		#region IDisposable Support

		private bool disposedValue;

		protected virtual void Dispose(bool disposing)
		{
			if (!disposedValue)
			{
				if (disposing)
				{
					// Dispose managed state (managed objects)
					if (_messageClient != null)
						_messageClient.Dispose();
				}

				disposedValue = true;
			}
		}

		public void Dispose()
		{
			// Do not change this code. Put cleanup code in 'Dispose(bool disposing)' method
			Dispose(disposing: true);
			GC.SuppressFinalize(this);
		}

		#endregion
	}
}
