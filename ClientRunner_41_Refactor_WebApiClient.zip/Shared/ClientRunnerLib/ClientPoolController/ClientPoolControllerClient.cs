﻿using GatewayLib.ClientPool;
using System;
using System.Diagnostics;
using System.Net.Http;
using System.Text;
using System.Text.Json;
using System.Threading.Tasks;

namespace ClientRunnerLib
{
	public class ClientPoolControllerClient : IDisposable
	{
		private readonly string _endpoint;
		private readonly HttpClient _httpClient;

		public ClientPoolControllerClient(string webApiServiceBaseAddress)
		{
			_endpoint = webApiServiceBaseAddress + "/ClientPoolSettings";
			_httpClient = new HttpClient();
		}

		public void PostClientPoolSettings(ClientPoolSettings clientPoolSettings, bool useClientPool2Implementation)
		{
			try
			{
				Task.Run(() => PostClientPoolSettingsAsync(clientPoolSettings, useClientPool2Implementation)).GetAwaiter().GetResult();
			}
			catch (Exception e)
			{
				Debug.WriteLine($"WebApiClientPoolSettingsControllerClient received {e.GetType()}: {e.Message}");
				throw;
			}
		}

		public async Task PostClientPoolSettingsAsync(ClientPoolSettings clientPoolSettings, bool useClientPool2Implementation)
		{
			ClientPoolSettingsRequest request = new ClientPoolSettingsRequest(clientPoolSettings, useClientPool2Implementation);
			var jsonRequest = JsonSerializer.Serialize(request);
			StringContent content = new StringContent(jsonRequest, Encoding.UTF8, "application/json");

			using (var response = await _httpClient.PostAsync(_endpoint, content))
			{
				if (response.StatusCode != System.Net.HttpStatusCode.OK)
				{
					throw new InvalidOperationException("PostClientPoolSettings did not return status code = OK.");
				}
			}
		}

		#region IDisposable Support

		private bool disposedValue;

		protected virtual void Dispose(bool disposing)
		{
			if (!disposedValue)
			{
				if (disposing)
				{
					// Dispose managed state (managed objects)
					if (_httpClient != null)
						_httpClient.Dispose();
				}

				disposedValue = true;
			}
		}

		public void Dispose()
		{
			// Do not change this code. Put cleanup code in 'Dispose(bool disposing)' method
			Dispose(disposing: true);
			GC.SuppressFinalize(this);
		}

		#endregion
	}

}
