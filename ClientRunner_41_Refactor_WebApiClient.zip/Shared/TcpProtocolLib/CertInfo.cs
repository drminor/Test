﻿using System;
using System.Security.Cryptography.X509Certificates;
using System.IO;

namespace TcpProtocolLib
{
	public class CertInfo : IDisposable
	{
		public readonly string OurPrivateCertFilePath;
		public readonly string OurPrivateCertPassword;

		public readonly string PeersPublicCertFilePath;

		public X509Certificate OurPrivateCert { get; private set; }
		public X509Certificate PeersPublicCert { get; private set; }

		public CertInfo(string ourPrivateCertFilePath, string ourPrivateCertPassword, string peersPublicCertFilePath)
		{
			OurPrivateCertFilePath = ourPrivateCertFilePath ?? throw new ArgumentNullException(nameof(ourPrivateCertFilePath));
			OurPrivateCertPassword = ourPrivateCertPassword ?? throw new ArgumentNullException(nameof(ourPrivateCertPassword));
			PeersPublicCertFilePath = peersPublicCertFilePath ?? throw new ArgumentNullException(nameof(peersPublicCertFilePath));

			OurPrivateCert = GetCert(OurPrivateCertFilePath, OurPrivateCertPassword);
			PeersPublicCert = GetCert(PeersPublicCertFilePath, null);
		}

		public static X509Certificate GetCert(string path, string password)
		{
			try
			{
				var cert = new X509Certificate2(path, password);
				return cert;
			}
			catch (Exception e)
			{
				throw new SendRequestException($"Could not read Cert from path: {path}.", SendRequestOperation.Connect, SendRequestError.CertificateError, e);
			}
		}

		public override string ToString()
		{
			return $"Private Cert Filename: {Path.GetFileName(OurPrivateCertFilePath)}, Peers Public Cert Filename: {Path.GetFileName(PeersPublicCertFilePath)}";
		}

		#region IDisposable Support

		private bool disposedValue;

		protected virtual void Dispose(bool disposing)
		{
			if (!disposedValue)
			{
				if (disposing)
				{
					// Dispose managed state (managed objects)
					if (OurPrivateCert != null) OurPrivateCert.Dispose();
					if (PeersPublicCert != null) PeersPublicCert.Dispose();
				}

				disposedValue = true;
			}
		}

		public void Dispose()
		{
			// Do not change this code. Put cleanup code in 'Dispose(bool disposing)' method
			Dispose(disposing: true);
			GC.SuppressFinalize(this);
		}

		#endregion
	}

}
