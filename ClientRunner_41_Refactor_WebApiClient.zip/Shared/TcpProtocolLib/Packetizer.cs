﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.Diagnostics;

namespace TcpProtocolLib
{
	public class Packetizer : IEnumerable<string>, IEnumerator<string>
	{
        private readonly int _maxMessageSize;
        private readonly IMessageEncoder _messageEncoder;

        private byte[] _data;
        private int _bufferLength;
        private int _readIndex;

        private readonly byte[] _lengthBuffer;
        private readonly int _lengthBufferSize;

        private byte[] _dataBuffer;
        private int _bytesReceived;

        private bool _isReadingPrefix;

		public Packetizer(int maxMessageSize, IMessageEncoder messageEncoder)
        {
            _maxMessageSize = maxMessageSize;
            _messageEncoder = messageEncoder;
            _lengthBufferSize = messageEncoder.LengthPrefixSizeInBytes;

            _lengthBuffer = new byte[_lengthBufferSize];

            // Initially we are looking for the prefix.
            _isReadingPrefix = true;
            _dataBuffer = null;

            _data = null;
            _bufferLength = 0;
            _readIndex = 0;

            _current = null;
        }

        public IEnumerable<string> PushData(byte[] data, int bufferLength)
        {
            _data = data;
            _bufferLength = bufferLength;
            if(_readIndex != 0)
			{
                throw new InvalidOperationException("The previous set of messages resulting from a call to PushData were not completely consumed via the returned enumerator.");
			}

            return this;
        }

        // Returns true if _data has not been completely read.
        private bool TryGetNextMessage(out string message)
		{
            message = null;

            if(_readIndex == _bufferLength)
			{
                _readIndex = 0; // Reset for next call to PushData
                return false;
			}
            
            int bytesAvailable = _bufferLength - _readIndex;

            while (message == null && bytesAvailable > 0)
            {
                int bytesTransferred;
                if (_isReadingPrefix)
                {
                    // Transfer as many bytes as possible to completely read a length prefix
                    bytesTransferred = Transfer(_data, _readIndex, bytesAvailable, _lengthBuffer, _bytesReceived);
                }
                else
                {
                    // Transfer as many bytes as possible to completely read a message
                    bytesTransferred = Transfer(_data, _readIndex, bytesAvailable, _dataBuffer, _bytesReceived);
                }

                _readIndex += bytesTransferred;

                // Will return null if not enough bytes have been transferred to build a complete message
                message = ReadCompleted(bytesTransferred);
                bytesAvailable = _bufferLength - _readIndex;
            }

            return true;
        }

        // Determine how many bytes we want to transfer to the buffer and transfer them
        private int Transfer(byte[] readBuffer, int readIndex, int dataBytesAvailable, byte[] writeBuffer, int writeIndex)
		{
            int bytesRemainingToWrite = writeBuffer.Length - writeIndex;
            int bytesTransferred = Math.Min(bytesRemainingToWrite, dataBytesAvailable);

            Array.Copy(readBuffer, readIndex, writeBuffer, writeIndex, bytesTransferred);
            return bytesTransferred;
        }

        private string ReadCompleted(int count)
        {
            string result;

            // Get the number of bytes read into the buffer
            _bytesReceived += count;

            if (_isReadingPrefix)
            {
                if (_bytesReceived == _lengthBufferSize)
                {
                    // We've gotten the length buffer
                    if (!TryParsePrefix(_lengthBuffer, out int length))
                    {
                        string lengthBufferAsHexDigits = BitConverter.ToString(_lengthBuffer);
                        throw new System.Net.ProtocolViolationException($"Message prefix: {lengthBufferAsHexDigits} cannot be parsed into an integer.");
                    }

                    if (length < 0)
                        throw new System.Net.ProtocolViolationException("Message length is less than zero");

                    if (_maxMessageSize > 0 && length > _maxMessageSize)
                        throw new System.Net.ProtocolViolationException($"Message length {length} is larger than maximum message size {_maxMessageSize}.");

                    // Zero-length packets are allowed as keepalives
                    if (length == 0)
                    {
                        _bytesReceived = 0;
                        result = _messageEncoder.GetString(new byte[0], 0);
                    }
                    else
                    {
                        // Create the data buffer and start reading into it
                        _dataBuffer = new byte[length];
                        _isReadingPrefix = false;
                        _bytesReceived = 0;
                        result = null;
                    }
                }
                else
				{
                    result = null;
				}
            }
            else
            {
                if (_bytesReceived == _dataBuffer.Length)
                {
                    // We've gotten an entire packet
                    result = _messageEncoder.GetString(_dataBuffer, _dataBuffer.Length); //OnMessageArrived(_dataBuffer);

                    // Start reading the length buffer again
                    _dataBuffer = null;
                    _isReadingPrefix = true;
                    _bytesReceived = 0;
                }
                else
				{
                    result = null;
				}
            }

            return result;
        }

        private bool TryParsePrefix(byte[] readBuffer, out int messageLength)
        {
            string prefix = _messageEncoder.GetString(readBuffer, _lengthBufferSize);
            return int.TryParse(prefix, out messageLength);
        }

        #region IEnumerable Implementation

        private string _current;
        public string Current
		{
			get => _current;
			private set { _current = value; }
		}

        object IEnumerator.Current => _current;

        public bool MoveNext()
		{
            return TryGetNextMessage(out _current);
		}

		public void Reset()
		{
            Debug.WriteLine("The Packetizer is being reset, but nothing is being done, because this implementation of IEnumberable is not resetable.");
		}

		#endregion

		#region IEnumerator Implementation

		public IEnumerator<string> GetEnumerator()
        {
            return this;
        }

        IEnumerator IEnumerable.GetEnumerator()
        {
            return (IEnumerator)GetEnumerator();
        }

		#endregion
        
		#region IDisposable Support

		private bool disposedValue;

        protected virtual void Dispose(bool disposing)
		{
			if (!disposedValue)
			{
				if (disposing)
				{
                    // Set current to null
				}

				disposedValue = true;
			}
		}

		public void Dispose()
		{
			// Do not change this code. Put cleanup code in 'Dispose(bool disposing)' method
			Dispose(disposing: true);
			GC.SuppressFinalize(this);
		}

		#endregion
	}
}
