﻿using System.Text;

namespace TcpProtocolLib
{

	public class EBCDIC_MessageEncoder : IMessageEncoder
	{
		public readonly static int EBCDIC_CODE_PAGE = 37;

		public EBCDIC_MessageEncoder(int lengthPrefixSizeInChars)
		{
			LengthPrefixSizeInBytes = lengthPrefixSizeInChars; // ASCII uses 1 byte per char
		}

		public int LengthPrefixSizeInBytes { get; }

		//public string ZeroLengthMessage => string.Empty;

		public byte[] CreatePacket(string message)
		{
			// Prepare a new byte array to return the result
			byte[] result = new byte[LengthPrefixSizeInBytes + message.Length];

			// Prepare the packet prefix
			string prefix = message.Length.ToString().PadLeft(LengthPrefixSizeInBytes);

			// Fill the result with the prefix 
			Encoding.GetEncoding(EBCDIC_CODE_PAGE).GetBytes(prefix, 0, LengthPrefixSizeInBytes, result, 0);

			// Fill the result with the message
			Encoding.GetEncoding(EBCDIC_CODE_PAGE).GetBytes(message, 0, message.Length, result, LengthPrefixSizeInBytes);

			return result;
		}

		public string GetString(byte[] buffer, int count)
		{
			return Encoding.GetEncoding(EBCDIC_CODE_PAGE).GetString(buffer, 0, count);
		}

		public override string ToString()
		{
			return $"EBCDIC, LengthPrefixSize: {LengthPrefixSizeInBytes}";
		}
	}
}
