﻿namespace AppProtocolLib
{
	public interface IFixedWidthMessage<T> 
	{
		string MessageName { get; }
        IColumnDictionary ColumnDefinitions { get; }
		string CorrelationId { get; }

		string ToMessage();
	}

}
