﻿using ClientRunnerLib;
using ClientRunnerConsole.ServiceReference2;
using GatewayLib.ClientPool;
using System;
using System.Diagnostics;
using System.Threading;
using System.Threading.Tasks;

namespace ClientRunnerConsole
{
	class Test001WcfClient
	{
		private readonly bool _useDetailedDebug = false;

		public Task<JobResult> SendRequests(int runCounter, TestServiceRequest request, long startingTickCount)
		{
			var callingThread = Thread.CurrentThread;
			Task<JobResult> result = Task<JobResult>.Factory.StartNew(s =>
			{
				var runnerThread = Thread.CurrentThread;
				if (_useDetailedDebug) Debug.WriteLine($"Thread: {callingThread.ManagedThreadId}(TP={callingThread.IsThreadPoolThread}) is calling the WebService, using runner Thread: {runnerThread.ManagedThreadId}.");
				try
				{
					return SendRequestsInternal(runCounter, request, startingTickCount);
				}
				catch (Exception e)
				{
					Debug.WriteLine($"The Test001WcfClient Got {e.GetType()}: {e.Message}.");
					return null;
				}
			}, null, CancellationToken.None, TaskCreationOptions.None, TaskScheduler.Default
			);

			return result;
		}

		public void UpdateClientPoolSettings(ClientPoolSettings newSettings, bool useClientPool2Implementation)
		{
			Service1SyncClient webService = new Service1SyncClient();

			ClientPoolSettingsRequest request = new ClientPoolSettingsRequest(newSettings, useClientPool2Implementation);
			webService.UpdateClientPoolSettings(request);
		}

		private JobResult SendRequestsInternal(int runCounter, TestServiceRequest request, long startingTickCount)
		{
			Service1SyncClient webService = new Service1SyncClient();

			TimeSpan elapsed;

			Stopwatch s = Stopwatch.StartNew();

			ServiceReference2.TestServiceResult serviceResult;
			try
			{
				serviceResult = webService.SendMessages(request);
			}
			catch (Exception e)
			{
				serviceResult = null;
				string errorMessage = e.GetBaseException().Message;
				Debug.WriteLine($"Job received {errorMessage}");
			}

			s.Stop();
			webService.Close();

			elapsed = s.Elapsed;

			int messagesSent = serviceResult?.MessagesSent ?? 0;
			string resultStatus = $"Sent {messagesSent} out of {request.MessagesToSend}";
			Console.WriteLine("Run={0} | Job={1} | TickCount={2} | Thread={3} | elapsed={4} | sent:{5}",
				runCounter, request.JobCntr, startingTickCount, Thread.CurrentThread.ManagedThreadId, elapsed.ToString(@"mm\:ss\.fff"), resultStatus);

			Debug.WriteLine("Run={0} | Job={1} | TickCount={2} | Thread={3} | elapsed={4} | sent:{5}",
				runCounter, request.JobCntr, startingTickCount, Thread.CurrentThread.ManagedThreadId, elapsed.ToString(@"mm\:ss\.fff"), resultStatus);

			JobResult result = new JobResult(startingTickCount, Thread.CurrentThread.ManagedThreadId, elapsed, messagesSent)
			{
				AverageTimeToSendMessageMs = serviceResult?.AverageTimeToSendMessageMs ?? 0,
				AverageTimeToGetManagedClientMs = serviceResult?.AverageTimeToGetManagedClientMs ?? 0,
				NumberUniqueMessageClientsUsed = serviceResult?.NumberUniqueMessageClientsUsed ?? 0
			};

			return result;
		}

	}
}
