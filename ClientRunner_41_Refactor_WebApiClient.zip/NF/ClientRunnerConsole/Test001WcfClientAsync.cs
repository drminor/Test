﻿using ClientRunnerLib;
using ClientRunnerConsole.ServiceReference1;
using GatewayLib.ClientPool;
using System;
using System.Diagnostics;
using System.Threading;
using System.Threading.Tasks;

namespace ClientRunnerConsole
{
	class Test001WcfClientAsync
	{
		public async Task<JobResult> SendRequestsAsync(int runCounter, TestServiceRequest request, long startingTickCount)
		{
			Service1Client webService= new Service1Client();

			TimeSpan elapsed;

			Stopwatch s = Stopwatch.StartNew();

			ServiceReference1.TestServiceResult serviceResult;
			try
			{
				serviceResult = await webService.SendMessagesAsync(request);
			}
			catch (Exception e)
			{
				serviceResult = null;
				string errorMessage = e.GetBaseException().Message;
				Debug.WriteLine($"Job received {errorMessage}");
			}

			s.Stop();
			webService.Close();

			elapsed = s.Elapsed;

			int messagesSent = serviceResult?.MessagesSent ?? 0;
			string resultStatus = $"Sent {messagesSent} out of {request.MessagesToSend}";
			Console.WriteLine("Run={0} | Job={1} | TickCount={2} | Thread={3} | elapsed={4} | sent:{5}",
				runCounter, request.JobCntr, startingTickCount, Thread.CurrentThread.ManagedThreadId, elapsed.ToString(@"mm\:ss\.fff"), resultStatus);

			Debug.WriteLine("Run={0} | Job={1} | TickCount={2} | Thread={3} | elapsed={4} | sent:{5}",
				runCounter, request.JobCntr, startingTickCount, Thread.CurrentThread.ManagedThreadId, elapsed.ToString(@"mm\:ss\.fff"), resultStatus);

			JobResult result = new JobResult(startingTickCount, Thread.CurrentThread.ManagedThreadId, elapsed, messagesSent)
			{
				AverageTimeToSendMessageMs = serviceResult?.AverageTimeToSendMessageMs ?? 0,
				AverageTimeToGetManagedClientMs = serviceResult?.AverageTimeToGetManagedClientMs ?? 0,
				NumberUniqueMessageClientsUsed = serviceResult?.NumberUniqueMessageClientsUsed ?? 0
			};

			return result;
		}

		public void UpdateClientPoolSettings(ClientPoolSettings newSettings, bool useClientPool2Implementation)
		{
			Service1Client webService = new Service1Client();
			ClientPoolSettingsRequest request = new ClientPoolSettingsRequest(newSettings, useClientPool2Implementation);
			webService.UpdateClientPoolSettings(request);
		}

	}
}
