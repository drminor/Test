﻿using ClientRunnerLib;
using GatewayLib.ClientPool;
using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.IO;
using System.Linq;
using System.Threading;
using System.Threading.Tasks;

namespace ClientRunnerConsole
{
	class WcfJobRunner
	{
		private long _currentTickCount = -1;

		public RunResult[] Run(bool runSynchronously, JobSettings settings, TcpServerControllerClient serverController, TcpServerSettings tcpServerSettings, ClientPoolSettings clientPoolSettings)
		{
			string filePath = settings.FilePath;
			int taskCount = settings.NumberOfTasks;
			int taskSpacingMs = settings.TaskSpacingMs;
			int messagesToSendPerTask = settings.MessagesToSendPerTask;
			int repeatCnt = settings.RepeatCnt;
			int serviceWorkDelayMs = settings.ServiceWorkDelayMs;
			bool useClientPool2Implementation = settings.UseClientPool2Implementation;

			RunResult[] runResults = Enumerable.Repeat<RunResult>(new RunResult(), taskCount).ToArray();

			Console.WriteLine("Press the Enter key to start run.");
			Console.ReadLine();

			try
			{
				string servResponse = serverController.Start("Test1", tcpServerSettings);
				Console.WriteLine($"Response from TcpServerController: {servResponse}");
				Debug.WriteLine($"Response from TcpServerController: {servResponse}");
			}
			catch
			{
				Console.WriteLine("Could not contact the TcpServerController.");
				Debug.WriteLine("Could not contact the TcpServerController.");
				return runResults;
			}

			try
			{
				// Update the Web Service's ClientPoolSettings
				if (runSynchronously)
				{
					Test001WcfClient client = new Test001WcfClient();
					client.UpdateClientPoolSettings(clientPoolSettings, useClientPool2Implementation);
				}
				else
				{
					Test001WcfClientAsync client = new Test001WcfClientAsync();
					client.UpdateClientPoolSettings(clientPoolSettings, useClientPool2Implementation);
				}
			}
			catch
			{
				Console.WriteLine("Could update the WebService's ClientPoolSettings.");
				Debug.WriteLine("Could update the WebService's ClientPoolSettings.");
				return runResults;
			}

			using (var sw = new StreamWriter(filePath))
			{
				for (int runCounter = 0; runCounter < repeatCnt; runCounter++)
				{
					Stopwatch mainSw = Stopwatch.StartNew();

					sw.WriteLine($"For Run {runCounter}");
					sw.WriteLine("Job|StartingTickCount|Thread|Elapsed|Actual|Target|TimePerMessage{ms}|TimeToGetManagedClient(ms)|NumUniqueMessageClients");

					Task<JobResult>[] tasks = new Task<JobResult>[taskCount];
					//object[] clients = new object[taskCount];
					for (int jobCounter = 0; jobCounter < taskCount; jobCounter++)
					{
						string messageTemplate = $"Job:{jobCounter}, Sample Message";
						Thread.Sleep(taskSpacingMs);

						long startingTickCount = JobRunnerHelper.GetDurationInTicks(ref _currentTickCount);
						TestServiceRequest request = new TestServiceRequest(jobCounter, messagesToSendPerTask, messageTemplate, serviceWorkDelayMs);
						Task<JobResult> task;

						// Call the Web Service
						if (runSynchronously)
						{
							Test001WcfClient client = new Test001WcfClient();
							task = client.SendRequests(runCounter, request, startingTickCount);
						}
						else
						{
							Test001WcfClientAsync client = new Test001WcfClientAsync();
							task = client.SendRequestsAsync(runCounter, request, startingTickCount);
						}
						tasks[jobCounter] = task;
					}

					try
					{
						Task.WaitAll(tasks);
						mainSw.Stop();
					}
					catch (AggregateException e)
					{
						mainSw.Stop();
						Console.WriteLine("\nThe following exceptions have been thrown by WaitAll():");
						for (int j = 0; j < e.InnerExceptions.Count; j++)
						{
							Console.WriteLine("\n-------------------------------------------------\n{0},{1}", j, e.InnerExceptions[j].ToString());
							if (e.InnerExceptions[j].InnerException != null)
							{
								Console.WriteLine("\n-------------------------------------------------\n{0},{1}", j, e.InnerExceptions[j].InnerException.ToString());
							}
						}
					}

					TimeSpan overallDuration = mainSw.Elapsed;

					IList<int> uniqueThreads = new List<int>();
					TimeSpan totalElapsed = TimeSpan.Zero;
					int totalMessagesSent = 0;
					double[] sendTimes = new double[taskCount];

					for (int jobCounter = 0; jobCounter < taskCount; jobCounter++)
					{
						string oLine;

						Task<JobResult> t = tasks[jobCounter];
						if (!(t.IsCanceled || t.IsFaulted))
						{
							JobResult r = t.Result;
							oLine = string.Format("{0}|{1}|{2}|{3}|{4}|{5}|{6:F3}|{7}|{8}", 
								jobCounter, r.StartingTickCount, r.ThreadId, r.Elapsed.ToString(@"mm\:ss\.fff"), r.MessagesSent, messagesToSendPerTask, r.AverageTimeToSendMessageMs, r.AverageTimeToGetManagedClientMs, r.NumberUniqueMessageClientsUsed);

							if (!uniqueThreads.Contains(r.ThreadId)) uniqueThreads.Add(r.ThreadId);

							totalElapsed += r.Elapsed;
							totalMessagesSent += r.MessagesSent;
							sendTimes[jobCounter] = r.AverageTimeToSendMessageMs;
						}
						else
						{
							oLine = string.Format("{0}|{1}|{2}|{3}|{4}|{5}",
								runCounter, jobCounter, 0, 0, 0, 0, messagesToSendPerTask);
							sendTimes[jobCounter] = 0;
						}

						tasks[jobCounter] = null;

						sw.WriteLine(oLine);
					}

					double sentPerSec = totalMessagesSent / overallDuration.TotalSeconds;
					double timePerWebServiceCall = overallDuration.TotalSeconds / taskCount;
					timePerWebServiceCall *= 1000;

					Console.WriteLine($"Sent {totalMessagesSent} messages in {overallDuration.TotalSeconds} for {sentPerSec} m/s.");

					sw.WriteLine();
					sw.WriteLine(string.Format("Run={0}|NumberUniqueThreads={1}|TotalSent={2}|TotalTime(sec)={3:F4}|MessagePerSecond={4:F3}|TimePerWebServiceCall(ms)={5:F3}|AverageTimeToSendMessage(ms)={6:F3}",
								runCounter, uniqueThreads.Count, totalMessagesSent, overallDuration.TotalSeconds, sentPerSec, timePerWebServiceCall, JobRunnerHelper.GetAverage(sendTimes)));
					sw.WriteLine();

					runResults[runCounter] = new RunResult(uniqueThreads.Count, totalMessagesSent, overallDuration, JobRunnerHelper.GetAverage(sendTimes));

					if (runCounter < repeatCnt)
					{
						//	Console.WriteLine($"Run {runCounter} completed, press Enter to continue.");
						//	Console.ReadLine();

						Thread.Sleep(settings.PauseDurationBeforeRepeatingMs);
						_currentTickCount = -1;
						mainSw.Restart();
					}
				}
			}

			string servResponse2 = serverController.Stop("Test1");
			Console.WriteLine($"TcpServer sent stop request, has returned {servResponse2}");

			Console.WriteLine("All completed, press Enter to continue.");
			Console.ReadLine();

			return runResults;
		}

	}
}
