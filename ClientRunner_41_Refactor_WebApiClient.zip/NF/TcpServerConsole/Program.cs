﻿using ClientRunnerLib;
using System;
using System.Net;
using System.Net.Sockets;

namespace TcpServerConsole
{
	class Program
    {
        private static IMessageServer _messageServer;
        private static IRequestHandler _requestHandler;

        static void Main(string[] args)
        {
            JobRunnerHelper.IsRunningOnNetCore = false;

            //IPAddress address = ParseArgs(args);

            IPAddress address = IPAddress.Loopback;
            //IPAddress address = IPAddress.Parse("192.168.3.126");

            IPEndPoint endPoint = new IPEndPoint(address, SharedSettings.TCP_SERVER_CONTROL_PORT);

            //Console.WriteLine("Press the Enter key to start the main TcpServerController.");
            //Console.ReadLine();

			TcpServerSettings settings = new TcpServerSettings
			{
				CloseConnsAfterNoActivitySeconds = -1,
				ResponseDelayMs1 = -1,
				ResponseDelayMs2 = -1,
				UseResponseDelayMs2Frequency = 0,
				MessageType = -1,
				Port = -1
			};

            _requestHandler = new TcpServerRequestHandler(address);

			_messageServer = new MessageServer("TcpServerController", endPoint, settings, _requestHandler);
            _messageServer.Start();

            Console.WriteLine(@"
            =======================================================
               Started listening at: {0}, port:{1}
            =======================================================",
            endPoint.Address, endPoint.Port);

            Console.WriteLine("Press the Enter key to stop.");
            Console.ReadLine();

            string stopStatus = _messageServer.Stop(out bool _);

            Console.WriteLine($"{stopStatus}, Press the Enter key to exit.");
            Console.ReadLine();
        }

        private static IPAddress ParseArgs(string[] args)
		{
            IPAddress address;

            if (args.Length > 0)
            {
                if (args[0].ToLower() == "localhost")
                    address = IPAddress.Loopback;
                else
                    address = IPAddress.Parse(args[0]);
            }
            else
            {
                address = GetLocalHostIpAddress();
            }

            return address;
        }

        private static IPAddress GetLocalHostIpAddress()
        {
            IPHostEntry host = Dns.GetHostEntry(Environment.MachineName);
            foreach (IPAddress IP in host.AddressList)
            {
                if (IP.AddressFamily == AddressFamily.InterNetwork)
                {
                    return IP;
                }
            }

            return null;
        }

    }
}
