﻿using Autofac;
using Autofac.Integration.Wcf;
using ClientRunnerLib;
using GatewayLib.Tcp;
using System;

namespace Test001WcfService
{
	public class Global : System.Web.HttpApplication
	{
		public static readonly int TEST_SERVER_PORT = 11234;

		protected void Application_Start(object sender, EventArgs e)
		{
			// These must be set to make sure the certificate files can be found.
			JobRunnerHelper.IsRunningOnNetCore = false;
			JobRunnerHelper.IsWebServerApp = true;

			// WCF integration docs are at:
			// https://autofac.readthedocs.io/en/latest/integration/wcf.html
			var builder = new ContainerBuilder();

			// Register your service implementations.
			builder.RegisterType<Test001Service>();
			builder.RegisterType<Test001ServiceSync>();

			// Register your dependencies.

			// Shared Gateway Service

			GatewayFactory<IMessageClient> gatewayFactory = GatewayFactoryHelper.GetGatewayFactory();
			builder.RegisterInstance(gatewayFactory).As<GatewayFactory<IMessageClient>>().SingleInstance();

			// Set the dependency resolver. This works for both regular WCF services and REST-enabled services.
			var container = builder.Build();
			AutofacHostFactory.Container = container;

			//var gwf = container.Resolve<GatewayFactory<IMessageClient>>();
			//System.Diagnostics.Debug.Assert(gwf != null);
		}

		protected void Session_Start(object sender, EventArgs e)
		{

		}

		protected void Application_BeginRequest(object sender, EventArgs e)
		{

		}

		protected void Application_AuthenticateRequest(object sender, EventArgs e)
		{

		}

		protected void Application_Error(object sender, EventArgs e)
		{

		}

		protected void Session_End(object sender, EventArgs e)
		{

		}

		protected void Application_End(object sender, EventArgs e)
		{
			// TODO: Dispose AutofacHostFactory.Container

			//var container = AutofacHostFactory.Container;

			//var gw = container.Resolve<IGateway<IMessageClient>>();
			//gw.Dispose();

		}
	}
}