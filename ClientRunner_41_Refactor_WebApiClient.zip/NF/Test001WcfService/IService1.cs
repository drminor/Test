﻿using ClientRunnerLib;
using System.ServiceModel;
using System.Threading.Tasks;

namespace Test001WcfService
{
	[ServiceContract]
	public interface IService1
	{
		[OperationContract]
		Task<TestServiceResult> SendMessagesAsync(TestServiceRequest request);

		[OperationContract]
		void UpdateClientPoolSettings(ClientPoolSettingsRequest request);
	}

}
