﻿using ClientRunnerLib;
using System.ServiceModel;

namespace Test001WcfService
{
	[ServiceContract]
	public interface IService1Sync
	{
		[OperationContract]
		TestServiceResult SendMessages(TestServiceRequest request);

		[OperationContract]
		void UpdateClientPoolSettings(ClientPoolSettingsRequest request);
	}

}
