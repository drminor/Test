﻿using AppProtocolLib.WebApiDTOs;
using System;
using System.Collections.Generic;
using System.Net.Http;
using System.Text;
using System.Text.Json;
using System.Threading.Tasks;

namespace ClientRunnerConsole
{
    class WebApiClient : IDisposable
    {
        private readonly string _endpoint;
        private readonly HttpClient _client;

        public WebApiClient(string endpoint)
        {
            _endpoint = endpoint;
            _client = new HttpClient();
        }

        public async Task<TestServiceResult> SendMessagesAsync(TestServiceRequest request)
        {
            TestServiceResult result;

            var jsonRequest = JsonSerializer.Serialize(request);
            StringContent content = new StringContent(jsonRequest, Encoding.UTF8, "application/json");

            using var response = await _client.PostAsync(_endpoint, content);

            if (response.StatusCode == System.Net.HttpStatusCode.OK)
            {
                string strResponse = await response.Content.ReadAsStringAsync();
                using var responseStream = await response.Content.ReadAsStreamAsync();
                result = await JsonSerializer.DeserializeAsync<TestServiceResult>(responseStream);
            }
            else
            {
                result = null;
            }

            return result;
        }

		#region IDisposable Support

		private bool disposedValue;

		protected virtual void Dispose(bool disposing)
		{
			if (!disposedValue)
			{
				if (disposing)
				{
                    // Dispose managed state (managed objects)
                    if (_client != null) _client.Dispose();
				}

				disposedValue = true;
			}
		}

		public void Dispose()
		{
			// Do not change this code. Put cleanup code in 'Dispose(bool disposing)' method
			Dispose(disposing: true);
			GC.SuppressFinalize(this);
		}

		#endregion
	}

}

