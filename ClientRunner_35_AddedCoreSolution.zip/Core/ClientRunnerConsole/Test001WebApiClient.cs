﻿using AppProtocolLib.WebApiDTOs;
using System;
using System.Diagnostics;
using System.Threading;
using System.Threading.Tasks;

namespace ClientRunnerConsole
{
	class Test001WebApiClient
	{
		public async Task<RunResult> SendRequestsAsync(int runCounter, TestServiceRequest request, string webApiEndpoint, long currentTickCount)
		{
			int messagesToSend = request.MessagesToSend;
			int jobCounter = request.JobCntr;

			TimeSpan elapsed;
			Stopwatch s = Stopwatch.StartNew();
			TestServiceResult serviceResult;

			using WebApiClient webApiClient = new WebApiClient(webApiEndpoint);

			try
			{
				//serviceResult = null; //await webService.SendMessagesAsync(messagesToSend, jobCounter, messageTemplate, serviceWorkDelayMs);
				serviceResult = await webApiClient.SendMessagesAsync(request);
			}
			catch (Exception e)
			{
				serviceResult = null;
				string errorMessage = e.GetBaseException().Message;
				Debug.WriteLine($"Job received {errorMessage}");
			}

			s.Stop();
			//webService.Close();

			elapsed = s.Elapsed;

			int messagesSent = serviceResult?.MessagesSent ?? 0;
			string resultStatus = $"Sent {messagesSent} out of {messagesToSend}";
			Console.WriteLine("Run={0} | Job={1} | TickCount={2} | Thread={3} | elapsed={4} | sent:{5}",
				runCounter, jobCounter, currentTickCount, Thread.CurrentThread.ManagedThreadId, elapsed.ToString(@"mm\:ss\.fff"), resultStatus);

			Debug.WriteLine("Run={0} | Job={1} | TickCount={2} | Thread={3} | elapsed={4} | sent:{5}",
				runCounter, jobCounter, currentTickCount, Thread.CurrentThread.ManagedThreadId, elapsed.ToString(@"mm\:ss\.fff"), resultStatus);

			RunResult result = new RunResult(currentTickCount, Thread.CurrentThread.ManagedThreadId, elapsed, messagesSent)
			{
				AverageTimeToSendMessageMs = serviceResult?.AverageTimeToSendMessageMs ?? 0,
				AverageTimeToGetManagedClientMs = serviceResult?.AverageTimeToGetManagedClientMs ?? 0,
				NumberUniqueMessageClientsUsed = serviceResult?.NumberUniqueMessageClientsUsed ?? 0
			};

			return result;
		}
	}
}
