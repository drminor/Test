﻿namespace TcpServerConsole
{
	interface IMessageServer
	{
		string TypeName { get; }

		bool IsStarted { get; }

		void Start();
		string Stop(out bool success);
	}
}