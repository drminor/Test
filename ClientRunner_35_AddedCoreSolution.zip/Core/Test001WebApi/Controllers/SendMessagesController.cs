﻿using AppProtocolLib.WebApiDTOs;
using GatewayLib.Gateway;
using GatewayLib.Tcp;
using Microsoft.AspNetCore.Mvc;
using System.Diagnostics;
using System.Threading.Tasks;
using Test001WebApi.Handlers;

namespace Test001WebApi.Controllers
{
	// https://localhost:44370/SendMessages
	[ApiController]
	[Route("[controller]")]
	public class SendMessagesController : ControllerBase
	{
		private readonly IGateway<IMessageClient> _gateway;

		public SendMessagesController(IGateway<IMessageClient> gateway)
		{
			_gateway = gateway;
		}

		[HttpGet]
		public string Ping()
		{
			return "Hi There";
		}

		// POST: api/SendMessages
		[HttpPost]
		[ProducesResponseType(200)]
		public async Task<ActionResult<TestServiceResult>> PostSendMessages(TestServiceRequest request)
		{
			//Debug.WriteLine($"Received request: {request}.");

			//await Task.Delay(100);
			//TestServiceResult result = new TestServiceResult(1, 1, 1.2, 2.3);

			Test001Handler test001Handler = new Test001Handler(_gateway);
			TestServiceResult result = await test001Handler.SendMessagesAsync(request.MessagesToSend, request.JobCntr, request.MessageTemplate, request.DelayToSimulateOtherWorkMs);

			var ar = new ActionResult<TestServiceResult>(result);
			return ar;
		}

	}
}
