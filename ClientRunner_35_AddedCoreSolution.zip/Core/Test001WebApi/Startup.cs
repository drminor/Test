using GatewayLib.ClientPool;
using GatewayLib.Gateway;
using GatewayLib.Tcp;
using Microsoft.AspNetCore.Builder;
using Microsoft.AspNetCore.Hosting;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.DependencyInjection;
using Microsoft.Extensions.Hosting;
using System;
using System.Net;
using TcpProtocolLib;

namespace Test001WebApi
{
	public class Startup
	{
		public static readonly int TEST_SERVER_PORT = 11234;

		private static readonly string CERT_PATH = @"C:\Users\david\ClientRunner.pfx";
		private static readonly string CERT_PASS = "Mary";
		private static readonly string PEER_PUBLIC_CERT_PATH = @"C:\Users\david\TcpServer.cer";

		private readonly IGateway<IMessageClient> _gatewaySingleton;

		public Startup(IConfiguration configuration)
		{
			_gatewaySingleton = BuildGateway();
			Configuration = configuration;
		}

		public IConfiguration Configuration { get; }

		// This method gets called by the runtime. Use this method to add services to the container.
		public void ConfigureServices(IServiceCollection services)
		{
			Type gatewayType = typeof(IGateway<IMessageClient>);
			services.AddSingleton(gatewayType, _gatewaySingleton);

			services.AddControllers().AddJsonOptions(jsonOptions =>
			{
				jsonOptions.JsonSerializerOptions.PropertyNamingPolicy = null;
			}
			).SetCompatibilityVersion(CompatibilityVersion.Version_3_0);

			//IMvcBuilder builder = services.AddControllers();
			//builder.AddJsonOptions(jsonOptions => jsonOptions.JsonSerializerOptions.PropertyNamingPolicy = null);
			//builder.SetCompatibilityVersion(CompatibilityVersion.Version_3_0);
		}

		// This method gets called by the runtime. Use this method to configure the HTTP request pipeline.
		public void Configure(IApplicationBuilder app, IWebHostEnvironment env)
		{
			if (env.IsDevelopment())
			{
				app.UseDeveloperExceptionPage();
			}

			app.UseHttpsRedirection();

			app.UseRouting();

			app.UseAuthorization();

			app.UseEndpoints(endpoints =>
			{
				endpoints.MapControllers();
			});
		}

		private IGateway<IMessageClient> BuildGateway()
		{
			//IPAddress remoteTcpServerAddress = IPAddress.Parse("192.168.3.126");
			IPAddress remoteTcpServerAddress = IPAddress.Loopback;

			CertInfo certInfo = new CertInfo(CERT_PATH, CERT_PASS, PEER_PUBLIC_CERT_PATH);

			ClientPoolSettings clientPoolSettings = new ClientPoolSettings
			(
				serverEndPoint: new IPEndPoint(remoteTcpServerAddress, TEST_SERVER_PORT),
				minConnections: 3, //3
				maxConnections: 30,
				allocateClientTimeoutMs: TimeSpan.FromMilliseconds(3 * 1000),
				messageEncoder: new ASCII_MessageEncoder(4),
				messageResponseTimeout: TimeSpan.FromMilliseconds(5150),
				certInfo: certInfo
			);

			IGateway<IMessageClient> result = GatewayModule2.BuildGateway(clientPoolSettings);
			return result;
		}
	}
}
