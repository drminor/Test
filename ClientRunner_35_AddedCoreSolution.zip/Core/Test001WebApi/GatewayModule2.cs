﻿using Autofac;
using GatewayLib.ClientPool;
using GatewayLib.Gateway;
using GatewayLib.Tcp;

namespace Test001WebApi
{
	// NOTE: There is another copy of this in the ClientRunnerConsole project.
	// TODO: Move GatewayModule to a shared project, so we can have just one.

	class GatewayModule2
	{
		public static IContainer Container { get; set; }

		static GatewayModule2()
		{
			var builder = new ContainerBuilder();
			
			// Gateway -- When resolving IGateway<IMessageClient> create a new instanced of Gateway<IMessageClient>
			builder.RegisterType<Gateway<IMessageClient>>().As<IGateway<IMessageClient>>();

			// MessageClient -- Use the MessageClientCreator defined as static method of the MessageClient class.
			builder.RegisterInstance(MessageClient.MessageClientCreator).As<CreateMessageClient>();

			// ClientPoolCreator -- Use the ClientPoolCreator defined as the static method of the ClientPool class.
			builder.RegisterInstance(ClientPool<IMessageClient>.ClientPoolCreator).As<CreateClientPool<IMessageClient>>();

			//// ClientPoolCreator2 -- Use the ClientPoolCreator defined as the static method of the ClientPool2 class.
			//builder.RegisterInstance(ClientPool2<IMessageClient>.ClientPoolCreator).As<CreateClientPool<IMessageClient>>();

			// ManagedClient -- Use the ManagedClientCreator defined as a static method of the ManagedClient class.
			builder.RegisterInstance(ManagedClient<IMessageClient>.ManagedClientCreator).As<CreateManagedClient<IMessageClient>>();

			Container = builder.Build();
		}

		public static IGateway<IMessageClient> BuildGateway(ClientPoolSettings clientPoolSettings)
		{
			var clientPoolCreator = Container.Resolve<CreateClientPool<IMessageClient>>();
			var messageClientCreator = Container.Resolve<CreateMessageClient>();
			var clientPool = clientPoolCreator(clientPoolSettings, messageClientCreator);

			var managedClientCreator = Container.Resolve<CreateManagedClient<IMessageClient>>();

			var gateway = Container.Resolve<IGateway<IMessageClient>>(
				new NamedParameter("clientPool", clientPool)
				, new NamedParameter("managedClientCreator", managedClientCreator)
			);

			return gateway;
		}
	}

}
