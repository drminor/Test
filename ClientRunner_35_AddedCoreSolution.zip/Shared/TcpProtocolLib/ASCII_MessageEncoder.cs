﻿using System.Text;

namespace TcpProtocolLib
{

	public class ASCII_MessageEncoder : IMessageEncoder
	{
		public ASCII_MessageEncoder(int lengthPrefixSizeInChars)
		{
			LengthPrefixSizeInBytes = lengthPrefixSizeInChars; // ASCII uses 1 byte per char
		}

		public int LengthPrefixSizeInBytes { get; }

		//public string ZeroLengthMessage => string.Empty;

		public byte[] CreatePacket(string message)
		{
			// Prepare a new byte array to return the result
			byte[] result = new byte[LengthPrefixSizeInBytes + message.Length];

			// Prepare the packet prefix
			string prefix = message.Length.ToString().PadLeft(LengthPrefixSizeInBytes);

			// Fill the result with the prefix 
			Encoding.ASCII.GetBytes(prefix, 0, LengthPrefixSizeInBytes, result, 0);

			// Fill the result with the message
			Encoding.ASCII.GetBytes(message, 0, message.Length, result, LengthPrefixSizeInBytes);

			return result;
		}

		public string GetString(byte[] buffer, int count)
		{
			return Encoding.ASCII.GetString(buffer, 0, count);
		}
	}
}
