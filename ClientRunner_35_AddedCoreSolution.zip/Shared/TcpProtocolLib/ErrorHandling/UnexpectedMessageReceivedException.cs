﻿using System;

namespace TcpProtocolLib
{
	[Serializable]
	public class UnexpectedMessageReceivedException : Exception
	{
		public static readonly string DEFAULT_NOTE = "Received a message prior to the current SendRequest operation.";
		public readonly DateTime DateReceived;
		public readonly string ReceivedMessage;

		public UnexpectedMessageReceivedException(string receivedMessage, DateTime dateReceived) : this(DEFAULT_NOTE, receivedMessage, dateReceived)
		{
		}

		public UnexpectedMessageReceivedException(string note, string receivedMessage, DateTime dateReceived) : base(note)
		{
			DateReceived = dateReceived;
			ReceivedMessage = receivedMessage;
		}

		public override string ToString()
		{
			string note = Message != DEFAULT_NOTE ? $", note: {Message}" : null;
			return $"UnexpectedMessageReceivedException: receivedMessage:{Message}, time:{DateReceived}{note}";
		}

	}
}
