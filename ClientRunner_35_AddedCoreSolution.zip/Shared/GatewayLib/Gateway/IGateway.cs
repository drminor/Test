﻿using GatewayLib.ClientPool;
using GatewayLib.Tcp;
using System;
using System.Threading.Tasks;

namespace GatewayLib.Gateway
{
	public interface IGateway<T> : IDisposable where T : class, IMessageClient
	{
		//TimeSpan AllocateClientTimeout { get; set; }
		//int PollForFreeClientsDurationMs { get; set; }

		Task<IManagedClient> GetManagedClientAsync();

		//For diagnostics
		PoolStats GetPoolStats();
	}

}
