﻿using TcpProtocolLib;

namespace GatewayLib.Tcp
{
	internal class ReadBufferResult
	{
		public readonly int BytesRead;
		public readonly SendRequestException Exception;

		public ReadBufferResult(int bytesRead)
		{
			BytesRead = bytesRead;
			Exception = null;
		}

		public ReadBufferResult(SendRequestException exception)
		{
			BytesRead = -1;
			Exception = exception;
		}
	}
}
