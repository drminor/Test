﻿using System;

namespace GatewayLib.ClientPool
{
	public abstract class PooledClientBase : IPooledClient
	{
		public abstract string Identifier { get; }

		public abstract bool IsInitialized { get; }
		public abstract bool IsConnected { get; }
		public abstract bool IsClosed { get; }
		public abstract bool IsServicingCall { get; }

		public abstract void Close();

		public DateTime CreatedDate { get; }
		public DateTime LastFreedDate { get; set; }
		public DateTime LastProvidedDate { get; set; }
		public DateTime LastUsedDate { get; set; }

		public int ProvidedCount { get; set; }
		public int FreedCount { get; set; }

		public PooledClientBase() 
		{
			CreatedDate = DateTime.Now;
			LastFreedDate = CreatedDate;
			LastProvidedDate = CreatedDate;
			LastUsedDate = CreatedDate;
		}

		#region IDisposable Support

		private bool disposedValue;

		protected virtual void Dispose(bool disposing)
		{
			if (!disposedValue)
			{
				if (disposing)
				{
					// Dispose managed state (managed objects)
					Close();
				}

				disposedValue = true;
			}
		}

		public void Dispose()
		{
			// Do not change this code. Put cleanup code in 'Dispose(bool disposing)' method
			Dispose(disposing: true);
		}

		#endregion

	}
}
