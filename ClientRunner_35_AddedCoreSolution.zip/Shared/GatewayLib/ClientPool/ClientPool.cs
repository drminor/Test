﻿#define CHECK_FOR_DISPOSED_CLIENTS
#define CHECK_FOR_REGISTERED_CLIENTS

using System;
using System.Collections.Concurrent;
using System.Collections.Generic;
using System.Diagnostics;
using System.Linq;
using System.Net;
using System.Threading;
using System.Threading.Tasks;
using GatewayLib.Gateway;
using GatewayLib.Tcp;
using TcpProtocolLib;

namespace GatewayLib.ClientPool
{
	public class ClientPool<T> : IClientPool<T>, IDisposable where T : class, IMessageClient
	{
		public const int DEFAULT_POLL_FOR_FREE_CLIENT_DURATION_MS = 20;
		public const int DEFAULT_MINIMUM_INACTIVITY_DURATION_MS = 2500;

		//private readonly BlockingCollection<T> _pool;
		private readonly Queue<T> _pool;

		private readonly IList<IPooledClient> _allClients;
		private readonly BlockingCollection<PoolRequest<T>> _poolRequests;
		private readonly Queue<PoolRequest<T>> _clientRequests;
		private readonly Task _poolRequestProcesssingTask;

		public readonly IPEndPoint ServerEndPoint;
		public readonly int MinClients;
		public readonly int MaxClients;
		public readonly IMessageEncoder MessageEncoder;
		public readonly TimeSpan MessageResponseTimeout;
		private readonly CertInfo _certInfo;

		private int NumberAllocated;
		private int NumberFree;
		private string FreeAllocatedPhrase => $"free: {NumberFree}, allocated: {NumberAllocated}";

		private int NumberCreated;
		private int NumberDestroyed;
		private int NumberOfRequests;
		private int NumberOfHits;

		private int NumberOfGetClientTimeouts;

		private int NumberOfReturns;
		private int NumberOfDiscards;
		private int NumberOfPoolAdds;

		private readonly CreateMessageClient _clientCreator;
		private readonly ReaderWriterLockSlim _locker;

		private readonly bool _useDetailedDebug = true;
		private readonly bool _reportTimeToAllocateClient = false;

		private static int _poolInstanceCounter = 0;
		public int InstanceId { get; }

		public ClientPool(ClientPoolSettings clientPoolSettings, CreateMessageClient clientCreator)
		{
			InstanceId = _poolInstanceCounter++;

			ServerEndPoint = clientPoolSettings.ServerEndPoint;
			MinClients = clientPoolSettings.MinConnections;
			MaxClients = clientPoolSettings.MaxConnections;
			AllocateClientTimeout = clientPoolSettings.AllocateClientTimeout;
			MessageEncoder = clientPoolSettings.MessageEncoder;
			MessageResponseTimeout = clientPoolSettings.MessageResponseTimeout;
			_certInfo = clientPoolSettings.CertInfo;

			_clientCreator = clientCreator;

			//_pool = new BlockingCollection<T>();
			_pool = new Queue<T>();

			_allClients = new List<IPooledClient>();
			NumberAllocated = 0;

			_locker = new ReaderWriterLockSlim();

			PollForFreeClientDuration = TimeSpan.FromMilliseconds(DEFAULT_POLL_FOR_FREE_CLIENT_DURATION_MS);
			MinimumInactivityDuration = TimeSpan.FromMilliseconds(DEFAULT_MINIMUM_INACTIVITY_DURATION_MS);

			string valMsg = ValidateGetClientTimeout(AllocateClientTimeout, PollForFreeClientDuration);
			if (valMsg != null)
			{
				throw new ArgumentException(valMsg);
			}

			_poolRequests = new BlockingCollection<PoolRequest<T>>();
			_clientRequests = new Queue<PoolRequest<T>>();

			FillPool(MinClients);
			Debug.WriteLine($"ClientPool created, {FreeAllocatedPhrase}.");

			_poolRequestProcesssingTask = StartBackgroundProcessor(_poolRequests);
		}

		#region Public Properties

		public static CreateClientPool<T> ClientPoolCreator => (ClientPoolSettings clientPoolSettings, CreateMessageClient clientCreator)
			=> new ClientPool<T>(clientPoolSettings, clientCreator);

		public TimeSpan AllocateClientTimeout { get; private set; }
		public TimeSpan PollForFreeClientDuration { get; private set; }
		public TimeSpan MinimumInactivityDuration { get; private set; }

		public bool IsClosed
		{
			get
			{
				_locker.EnterReadLock();
				try
				{
					return disposedValue;
				}
				finally
				{
					_locker.ExitReadLock();
				}
			}
		}

		#endregion

		#region Public Methods
		
		public PoolStats GetPoolStats()
		{
			_locker.EnterReadLock(); // Keep writers out while making the copy.
			try
			{
				return PoolStatHelper.GetPoolStats(NumberAllocated, NumberFree,
				NumberCreated, NumberDestroyed,
				NumberOfRequests, NumberOfHits,
				NumberOfReturns, NumberOfDiscards,
				NumberOfPoolAdds, _allClients.AsEnumerable<IPooledClient>().ToList());
			}
			finally
			{
				_locker.ExitReadLock();
			}
		}

		public IList<IPooledClient> GetAllClients()
		{
			_locker.EnterReadLock(); // Keep writers out while making the copy.
			try
			{
				List<IPooledClient> result = _allClients.AsEnumerable<IPooledClient>().ToList();
				return result;
			}
			finally
			{
				_locker.ExitReadLock();
			}
		}

		public T GetClient(string opId)
		{
			T client = Task.Run(() => GetClientAsync(opId)).GetAwaiter().GetResult();
			return client;
		}

		public async Task<T> GetClientAsync(string opId)
		{
			return await (GetClientAsync(null, opId));
		}

		// Throws GatewayException,	ErrorCode = Timeout or ClientPoolIsDisposed
		public async Task<T> GetClientAsync(T clientToReturn, string opId)
		{
			if(_useDetailedDebug || _reportTimeToAllocateClient)
			{
				return await GetClientAsyncForDebug(clientToReturn);
			}

			bool requestSatisfiedImmediately = TrySatisfyRequestImmediately(clientToReturn, out T client);
			if (!requestSatisfiedImmediately)
			{
				TaskCompletionSource<T> tcs = new TaskCompletionSource<T>(TaskCreationOptions.RunContinuationsAsynchronously);
				PoolRequest<T> requestTaskHolder = new PoolRequest<T>(AllocateClientTimeout, tcs);

				_poolRequests.Add(requestTaskHolder);

				try
				{
					client = await tcs.Task.ConfigureAwait(continueOnCapturedContext: false);
					Interlocked.Increment(ref NumberOfHits);
				}
				catch (Exception e)
				{
					Debug.WriteLine($"Got error from await. ErrorMessage = {e.Message}");
					throw new GatewayException(GatewayOperationEnum.GetClientFromPool, e);
				}
			}

			if (client != null)
			{
				CheckClientDisposed(client, "Just provided by GetClientAsync.", true);
				CheckIsClientRegistered(client, "Just provided by GetClientAsync.");
				client.LastProvidedDate = DateTime.Now;
				client.ProvidedCount++;
			}
			else
			{
				Interlocked.Increment(ref NumberOfGetClientTimeouts);
				throw new GatewayException(GatewayOperationEnum.GetClientFromPool, GatewayError.Timeout);
			}

			return client;
		}

		// Throws GatewayException,	ErrorCode = Timeout or ClientPoolIsDisposed
		private async Task<T> GetClientAsyncForDebug(T clientToReturn)
		{
			PoolStats t0 = GetPoolStats();

			var requestingThread = Thread.CurrentThread;
			Stopwatch s = Stopwatch.StartNew();

			bool requestSatisfiedImmediately = TrySatisfyRequestImmediately(clientToReturn, out T client);
			if (!requestSatisfiedImmediately)
			{
				TaskCompletionSource<T> tcs = new TaskCompletionSource<T>(TaskCreationOptions.RunContinuationsAsynchronously);
				PoolRequest<T> requestTaskHolder = new PoolRequest<T>(AllocateClientTimeout, tcs);

				//Debug.WriteLine($"POOL REQUESTS COUNT = {_poolRequests.Count}.");
				_poolRequests.Add(requestTaskHolder);

				try
				{
					client = await tcs.Task.ConfigureAwait(continueOnCapturedContext: false);
					s.Stop();

					Interlocked.Increment(ref NumberOfHits);
				}
				catch (Exception e)
				{
					Debug.WriteLine($"Got error from await. ErrorMessage = {e.Message}");
					throw new GatewayException(GatewayOperationEnum.GetClientFromPool, e);
				}

				//Debug.WriteLine($"GetClientAsync has returned from waiting on the pool request {requestTaskHolder.Id}.");
			}
			else
			{
				s.Stop();
			}

			string ems = s.ElapsedMilliseconds.ToString("F4");

			PoolStats t1 = GetPoolStats();
			PoolStatPair pr = new PoolStatPair(t0, t1);
			//Debug.WriteLine(pr.ToString() + " Id=" + client?.Identifier ?? "No Client Found.");

			if (client != null)
			{
				CheckClientDisposed(client, "Just provided by GetClientAsync.", true);
				CheckIsClientRegistered(client, "Just provided by GetClientAsync.");
				client.LastProvidedDate = DateTime.Now;
				client.ProvidedCount++;

				var continueThread = Thread.CurrentThread;
				string threadInfo = (continueThread.ManagedThreadId != requestingThread.ManagedThreadId) ? $"ThreadInfo: Call made on {requestingThread.ManagedThreadId}, continuing on {continueThread.ManagedThreadId}." : null;
				string requestFullfilmentType = requestSatisfiedImmediately ? "immediately" : "from queue";

				Debug.WriteLine($"ClientPool::GetClient provided client: {client.Identifier} in {ems} milliseconds {requestFullfilmentType}. PoolStatDiff: {pr}. {threadInfo}");
			}
			else
			{
				Interlocked.Increment(ref NumberOfGetClientTimeouts);
				string requestFullfilmentType = requestSatisfiedImmediately ? "via direct call" : "by queuing.";
				Debug.WriteLine($"ClientPool::GetClient waited {ems} but was unable to provide a client {requestFullfilmentType}. PoolStatDiff: {pr}.");

				throw new GatewayException(GatewayOperationEnum.GetClientFromPool, GatewayError.Timeout);
			}

			return client;
		}
		
		public void ReturnClient(T client, string _)
		{
			if (client != null)
			{
				//if (_useDetailedDebug) Debug.WriteLine($"POOL REQUESTS COUNT = {_poolRequests.Count}. {opId}");
				_poolRequests.Add(new PoolRequest<T>(client));
			}
		}

		#endregion

		#region Private Methods

		private bool TrySatisfyRequestImmediately(T clientToReturn, out T client)
		{
			client = null;

			_locker.EnterUpgradeableReadLock();
			try
			{
				if (clientToReturn != null)
				{
					ReturnClientInternal(clientToReturn);
				}

				if (disposedValue)
				{
					throw new GatewayException(GatewayOperationEnum.GetClientFromPool, GatewayError.ClientPoolIsDisposed);
				}

				bool result;

				NumberOfRequests++;
				if (IsAnyClientRequestsPending())
				{
					// Other requestors are waiting for a client to become free, this requestor must "get in line."
					result = false;
				}
				else
				{
					result = TryGetClientNoWait(out client);
				}

				if(result)
				{
					NumberOfHits++;
				}

				return result;
			}
			finally
			{
				_locker.ExitUpgradeableReadLock();
			}
		}

		private bool TryGetClientNoWait(out T client)
		{
			if (TryTakeConnectedClient(out client))
			{
				// Found an available client, remove it from the pool and return it the caller.
				if(_useDetailedDebug) Debug.WriteLine($"ClientPool retrieved an existing client: {client.Identifier}, {FreeAllocatedPhrase}.");
				client.LastProvidedDate = DateTime.Now;
				client.ProvidedCount++;
				return true;
			}

			if (TryAddNewClient(out client))
			{
				// Added a new client, return it to the caller.
				if (_useDetailedDebug) Debug.WriteLine($"ClientPool had less than {MaxClients}. Created a brand new client. {FreeAllocatedPhrase}.");
				client.LastProvidedDate = DateTime.Now;
				client.ProvidedCount++;
				return true;
			}

			return false;
		}

		private bool TryTakeConnectedClient(out T client)
		{
			client = null;
			bool result = false;

			T testClient;
			bool connectedClientFound = false;
			bool clientFound;

			_locker.EnterWriteLock();

			try
			{
				if (disposedValue) return false;

				do
				{
					//clientFound = _pool.TryTake(out T testClient);

					if (_pool.Count > 0)
					{
						testClient = _pool.Dequeue();
						clientFound = true;
					}
					else
					{
						testClient = null;
						clientFound = false;
					}

					if (clientFound)
					{
						NumberFree--;

						bool clientIsDisposed = IsClientDisposed(testClient, out string id);
						if (clientIsDisposed) Debug.WriteLine("We must be in the process of being disposed.");
						if (clientIsDisposed || !testClient.IsConnected)
						{
							DiscardClient(testClient, id, true);
						}
						else
						{
							client = testClient;
							connectedClientFound = true;
							result = true;
						}
					}
				}
				while (clientFound && !connectedClientFound);
			}
			finally
			{
				_locker.ExitWriteLock();
			}

			return result;
		}

		private bool TryAddNewClient(out T client)
		{
			client = null;

			if (NumberAllocated < MaxClients)
			{
				_locker.EnterWriteLock();
				try
				{
					if (disposedValue) return false;
					client = (T)_clientCreator(ServerEndPoint, MessageEncoder, MessageResponseTimeout, _certInfo);

					_allClients.Add(client);
					NumberAllocated++;
					NumberCreated++;
				}
				finally
				{
					_locker.ExitWriteLock();
				}
				return true;
			}
			else
			{
				return false;
			}
		}

		private void ReturnClientInternal(T client)
		{
			CheckIsClientRegistered(client, "PoolRequestProcessor handling a return.");
			bool clientIsDisposed = IsClientDisposed(client, out string id);

			_locker.EnterWriteLock();
			try
			{
				if (disposedValue)
				{
					if (!clientIsDisposed) client.Dispose();
					return;
				}

				NumberOfReturns++;

				if (clientIsDisposed || client.IsClosed)
				{
					Debug.WriteLine($"ClientPool is discarding {id}. The Client's Tcp connection is closed.");
					NumberOfDiscards++;
					DiscardClient(client, id, clientIsDisposed);
				}
				else if (ShouldClientBeDiscarded(client, NumberAllocated, MinClients, MinimumInactivityDuration))
				{
					double secondsSinceLastUse = (DateTime.Now - client.LastUsedDate).TotalSeconds;
					Debug.WriteLine($"ClientPool is discarding {id}. Client has not been used in {secondsSinceLastUse} seconds and we are {NumberAllocated - MinClients} over the minimum of {MinClients}, {FreeAllocatedPhrase}.");
					NumberOfDiscards++;
					DiscardClient(client, id, clientIsDisposed);
				}
				else
				{
					if (_useDetailedDebug) Debug.WriteLine($"ClientPool is returning {id}. {FreeAllocatedPhrase}, Client used for {(DateTime.Now - client.LastFreedDate).TotalSeconds} seconds.");
					client.LastFreedDate = DateTime.Now;
					client.FreedCount++;
					_pool.Enqueue(client);
					NumberFree++;
					NumberOfPoolAdds++;
				}
			}
			finally
			{
				_locker.ExitWriteLock();
			}
		}

		private void DiscardClient(T client, string id, bool clientIsDisposed)
		{
			_allClients.Remove(client);
			NumberAllocated--;
			NumberDestroyed++;
			if(_useDetailedDebug) Debug.WriteLine($"ClientPool has removed {id}, {FreeAllocatedPhrase}.");

			if (!clientIsDisposed)
				client.Dispose();
		}

		private void FillPool(int size)
		{
			_locker.EnterWriteLock();
			try
			{
				if (disposedValue) return;
				while (_allClients.Count < size)
				{
					T client = (T)_clientCreator(ServerEndPoint, MessageEncoder, MessageResponseTimeout, _certInfo);

					_allClients.Add(client);
					NumberCreated++;
					NumberAllocated++;

					_pool.Enqueue(client);
					NumberFree++;
					NumberOfPoolAdds++;
				}
			}
			finally
			{
				_locker.ExitWriteLock();
			}
		}

		private bool ShouldClientBeDiscarded(IPooledClient client, int numberAllocated, int minimumClients, TimeSpan minimumInactivityDuration)
		{
			bool result;

			if (numberAllocated > minimumClients)
			{
				result = DateTime.Now - client.LastUsedDate > minimumInactivityDuration;
			}
			else
			{
				result = false;
			}

			return result;
		}

		#endregion

		#region Checks and Helpers

		[Conditional("CHECK_FOR_DISPOSED_CLIENTS")]
		private void CheckClientDisposed(IPooledClient client, string context, bool throwWhenDisposed)
		{
			try
			{
				string _ = client.Identifier;
			}
			catch (ObjectDisposedException)
			{
				Debug.WriteLine($"WARNING: The pooled client has already been disposed. Context={context}");
				if (throwWhenDisposed) throw;
			}
		}
		
		private bool IsClientDisposed(IPooledClient client, out string id)
		{
			try
			{
				id = client?.Identifier ?? "client is null";
				return false;
			}
			catch (ObjectDisposedException)
			{
				id = "disposed";
				return true;
			}
		}

		[Conditional("CHECK_FOR_REGISTERED_CLIENTS")]
		private void CheckIsClientRegistered(IPooledClient client, string context)
		{
			string id = "disposed";
			try
			{
				id = client.Identifier;
			}
			catch (ObjectDisposedException) { }

			if (!_allClients.Contains(client))
				Debug.WriteLine($"WARNING: The client: {id} is not being managed from this pool. Context={context}");
		}

		private string ValidateGetClientTimeout(TimeSpan timeout, TimeSpan pollForFreeClientDuration)
		{
			// The duration to wait for a client to become available must be at least 4 times the poll duration.
			const double factor = 4;
			double maxPollDuration = timeout.TotalMilliseconds / factor;

			if (pollForFreeClientDuration.TotalMilliseconds > maxPollDuration)
			{
				return $"The GetClientTimeout must be at least {factor} times as long as the PollForFreeClientDuration.";
			}
			else
			{
				return null;
			}
		}

		#endregion

		#region IDisposable Support

		private void Clear()
		{
			int free = _pool.Count;
			int total = _allClients.Count;

			if (free != total)
			{
				Debug.WriteLine($"Warning: There are {total - free} clients that not been returned to the pool. There are only {free} free clients out of {total}, total.");
			}

			// Remove all items from the blocking collection.
			NumberFree -= free;
			_pool.Clear();

			foreach (IPooledClient client in _allClients)
			{
				try
				{
					client.Dispose();
				}
				catch (ObjectDisposedException)
				{
					// ignore
				}
			}

			NumberDestroyed += total;
			_allClients.Clear();
		}

		private void StopBackgroundProcessor()
		{
			_poolRequests.CompleteAdding();
			if(! _poolRequestProcesssingTask.Wait(TimeSpan.FromSeconds(5)))
			{
				Debug.WriteLine("Was not able to stop the client pool's background thread.");
			}

			while (_poolRequests.TryTake(out PoolRequest<T> _));
		}

		private bool disposedValue = false; // To detect redundant calls

		protected virtual void Dispose(bool disposing)
		{
			if (!disposedValue)
			{
				if (disposing)
				{
					// Dispose managed state (managed objects).
					_locker.EnterWriteLock();
					try
					{
						StopBackgroundProcessor();
						Clear();
						//_pool.Dispose();
					}
					finally
					{
						disposedValue = true;
						_locker.ExitWriteLock();
						//_locker.Dispose();
					}
				}
			}
		}

		public void Dispose()
		{
			Dispose(true);
		}

		#endregion

		#region PoolRequestProcessor Support

		private Task StartBackgroundProcessor(BlockingCollection<PoolRequest<T>> poolRequests)
		{
			Task task = Task.Factory.StartNew(s =>
			{
				var x = (BlockingCollection<PoolRequest<T>>)s;
				ProcessPoolRequests(x);
			}
			, poolRequests, CancellationToken.None, TaskCreationOptions.LongRunning, TaskScheduler.Default);

			return task;
		}

		private int _baton = 0;
		private void SetWeHaveAClientRequest(bool newValue)
		{
			Debug.WriteLine($"PoolRequestProcessor is setting the AnyPendingClientRequests to {newValue}.");

			if(newValue)
			{
				// We expect baton to be currently 0.
				int previousValue = Interlocked.CompareExchange(ref _baton, 1, 0); // If _baton = 0, then replace it with 1. This should return 0. If not throw exception.
				if (previousValue != 0) throw new InvalidOperationException("Baton was already set on attempt to set it.");
			}
			else
			{
				// We expect baton to be currently 1.
				int previousValue = Interlocked.CompareExchange(ref _baton, 0, 1); // If _baton = 1, then replace it with 0. This should return 1. If not throw exception.
				if (previousValue != 1) throw new InvalidOperationException("Baton was already unset on attempt to unset it.");
			}

			Debug.WriteLine($"PoolRequestProcessor has set the AnyPendingClientRequests to {newValue}.");
		}

		private bool IsAnyClientRequestsPending()
		{
			//Debug.WriteLine("Requester is querying IsAnyClientRequestsPending.");
			// Compare current value to a value which we know it will never have,
			// so the we can get the current value without updating the existing value.
			int currentValue = Interlocked.CompareExchange(ref _baton, 100, 2);

			bool result;
			if (currentValue == 1)
				result = true;
			else if (currentValue == 0)
				result = false;
			else
				throw new InvalidOperationException("Baton was neither 0 or 1 on read.");

			//Debug.WriteLine($"Requester has queryed IsAnyClientRequestsPending and found {result}.");
			return result;
		}

		#endregion

		#region Pool Request Processor

		// --------------------
		//		Long Running Task on dedicated thread
		// --------------------
		private void ProcessPoolRequests(BlockingCollection<PoolRequest<T>> poolRequests)
		{
			Debug.Assert(!IsAnyClientRequestsPending(), "Expected to have no client requests at startup.");

			// While we are not stopping
			while (!poolRequests.IsAddingCompleted && !poolRequests.IsCompleted)
			{
				// While we are not servicing a client request,	we can block on the PoolReqeusts work queue.
				ServicePoolRequests(poolRequests);

				// We have a client request 
				SetWeHaveAClientRequest(true);

				ServiceClientRequests(poolRequests);

				// All ClientRequests have been processed, Let requestors know that they can attempt to make direct requests.
				SetWeHaveAClientRequest(false);
			}

			// The blocking collection is being closed
			Debug.WriteLine($"PoolRequestProcessor is stopping -- adding complete. There are {_poolRequests.Count} Pool Requests and {_clientRequests.Count} remaining.");
		}

		private void ServicePoolRequests(BlockingCollection<PoolRequest<T>> poolRequests)
		{
			if (_useDetailedDebug) Debug.WriteLine($"Beginning to ServicePoolRequests: {_clientRequests.Count} client requests in queue, {poolRequests.Count} pool requests to be handled.");

			do
			{
				//Debug.Assert(!IsAnyClientRequestsPending(), "IsAnyClientsPending returns true, but _clientRequests.Count == 0.");
				FindNextClientRequest(poolRequests);
			}
			while (_clientRequests.Count == 0 && !poolRequests.IsAddingCompleted);
		}

		private void ServiceClientRequests(BlockingCollection<PoolRequest<T>> poolRequests)
		{
			if (_useDetailedDebug) Debug.WriteLine($"Beginning to ServiceClientRequests: {_clientRequests.Count} client requests in queue, {poolRequests.Count} pool requests to be handled.");

			do
			{
				RemoveExpiredRequests(_clientRequests);

				if (_clientRequests.Count == 0)
					break;

				bool foundOne = TrySatisfyClientRequest();
				if (_useDetailedDebug && !foundOne)
				{
					//PoolStats ps = GetPoolStats();
					Debug.WriteLine($"PoolRequestProcessor found no client.");
				}

				if (_clientRequests.Count == 0)
					break;

				bool foundAReturnRequest = ProcessReturnRequests(poolRequests);

				if(!foundAReturnRequest)
				{
					if (_useDetailedDebug) Debug.WriteLine($"No return requests were found, sleeping for {PollForFreeClientDuration.TotalMilliseconds}.");
					Thread.Sleep(PollForFreeClientDuration);
				}
			}
			while (_clientRequests.Count > 0 && !poolRequests.IsAddingCompleted);
		}

		private bool TrySatisfyClientRequest()
		{
			bool result;

			try
			{
				_locker.EnterUpgradeableReadLock(); // Allow reader to read, but keep writers out
				try
				{
					if (TryGetClientNoWait(out T client))
					{
						PoolRequest<T> cRequest = _clientRequests.Dequeue();
						DateTime n = DateTime.Now;
						if (cRequest.ExpireDate > n)
						{
							if(_useDetailedDebug) Debug.WriteLine($"PoolRequestProcessor is providing a client for {cRequest.Id}.");
							CompleteTcs(cRequest, client);
							result = true;
						}
						else
						{
							Debug.WriteLine($"PoolRequestProcessor could not provide a client for {cRequest.Id}. Timeout expired.  ExpireDate = {cRequest.ExpireDate}, now = {n}.");

							// Return the client to the free pool.
							ReturnClientInternal(client);

							CompleteTcs(cRequest, null);
							result = false;
						}
					}
					else
					{
						result = false;
					}

					return result;
				}
				catch (Exception e)
				{
					Debug.WriteLine($"FATAL ERROR: PoolRequestProcessor encountered exception {e.GetType()}: {e.Message}");
					throw e;
				}
			}
			finally
			{
				_locker.ExitUpgradeableReadLock();
			}
		}

		// Returns as soon as a ClientRequest is found or there are no more poolRequests.
		private void FindNextClientRequest(BlockingCollection<PoolRequest<T>> poolRequests)
		{
			bool foundAClientRequest = false;

			while (!poolRequests.IsAddingCompleted && !foundAClientRequest)
			{
				try
				{
					Debug.Assert(_clientRequests.Count == 0, "Blocking when we have a pending client request.");

					if (_useDetailedDebug && poolRequests.Count == 0)
					{
						Debug.WriteLine("All pool requests have been processed, PoolRequestProcessor is blocked until a new PoolRequest is received.");
					}

					PoolRequest<T> pRequest = poolRequests.Take();

					if (_useDetailedDebug) Debug.WriteLine($"PoolRequestProcessor received a pool request: {pRequest.Id}.");

					foundAClientRequest = pRequest.IsGetClient;
					ProcessAPoolRequest(pRequest);
				}
				catch (InvalidOperationException)
				{
					if (_useDetailedDebug) Debug.WriteLine("PoolRequestProcessor caught IOE.");
					break;
				}
			};
		}

		// Returns as soon as a return request is found and processed or there are no more poolRequests.
		private bool ProcessReturnRequests(BlockingCollection<PoolRequest<T>> poolRequests)
		{
			bool foundAReturnRequest = false;

			while (!poolRequests.IsAddingCompleted && poolRequests.Count > 0 && !foundAReturnRequest)
			{
				try
				{
					if(poolRequests.TryTake(out PoolRequest<T> pRequest))
					{
						if (_useDetailedDebug) Debug.WriteLine($"PoolRequestProcessor received a pool request: {pRequest.Id}.");
						foundAReturnRequest = pRequest.IsReturn;
						ProcessAPoolRequest(pRequest);
					}
				}
				catch (InvalidOperationException)
				{
					if (_useDetailedDebug) Debug.WriteLine("PoolRequestProcessor caught IOE.");
					return false;
				}
			};

			return foundAReturnRequest;
		}

		private void ProcessAPoolRequest(PoolRequest<T> pRequest)
		{
			if (pRequest.IsReturn)
			{
				try
				{
					ReturnClientInternal(pRequest.Client);
					if (_useDetailedDebug) Debug.WriteLine($"PoolRequestProcessor handled {pRequest.Id}.");
				}
				catch (Exception e)
				{
					Debug.WriteLine($"PoolRequestProcessor got exception: {e.Message} while returning client.");
				}
			}
			else
			{
				Debug.Assert(!pRequest.IsEmpty, "Pool Request has a null Tcs upon queueing.");
				try
				{
					_clientRequests.Enqueue(pRequest);
				} 
				catch (Exception e)
				{
					Debug.WriteLine($"PoolRequestProcessor got exception: {e.Message} while enqueuing a client request. Throwing!");
					throw;
				}
			}
		}

 		private void RemoveExpiredRequests(Queue<PoolRequest<T>> clientRequests)
		{
			DateTime n = DateTime.Now;
			while (clientRequests.Count > 0 && clientRequests.Peek().ExpireDate < n)
			{
				PoolRequest<T> cRequest = _clientRequests.Dequeue();
				if (_useDetailedDebug) Debug.WriteLine($"ClientRequest {cRequest.Id} has expired, completing the task. ExpireDate = {cRequest.ExpireDate}, now = {n}.");
				CompleteTcs(cRequest, null);
			};
		}

		private void CompleteTcs(PoolRequest<T> cRequest, T client)
		{
			try
			{
				cRequest.Tcs.SetResult(client);
			}
			catch (Exception e)
			{
				Debug.WriteLine($"The PoolRequestProcessor could not complete the task for {cRequest.Id}. Received exception {e.GetType()}: {e.Message}.");
			}
		}

		#endregion
	}

}
