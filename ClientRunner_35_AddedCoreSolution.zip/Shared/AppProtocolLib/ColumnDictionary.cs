﻿using System.Collections.Generic;
using System.Linq;

namespace AppProtocolLib
{
	public interface IColumnDictionary : IDictionary<string, ColumnDefinition>
	{
		IColumnDictionary AddColumnDefinition(string name, int Length);
	}

	public class ColumnDictionary : Dictionary<string, ColumnDefinition>, IColumnDictionary
	{
        private int _size = 0;

		public IColumnDictionary AddColumnDefinition(string name, int Length)
		{
			if(Count == 0)
			{
                Add(name, new ColumnDefinition(0, Length));
                _size = Length;
			}
            else
			{
                Add(name, new ColumnDefinition(_size, Length));
                _size += Length;
            }

            return this;
		}

        public override string ToString()
		{
			ICollection<KeyValuePair<string, ColumnDefinition>> t = this;
            string s = string.Join(", ", t.Select(x => $"{x.Key} - {x.Value}"));

			return s;
        }
	}
}
