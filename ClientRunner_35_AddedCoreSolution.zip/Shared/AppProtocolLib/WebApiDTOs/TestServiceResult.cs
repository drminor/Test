﻿
namespace AppProtocolLib.WebApiDTOs
{
	public class TestServiceResult
	{
		public int MessagesSent { get; set; }
		public int NumberUniqueMessageClientsUsed { get; set; }
		public double AverageTimeToSendMessageMs { get; set; }
		public double AverageTimeToGetManagedClientMs { get; set; }

		public TestServiceResult()
		{
		}

		public TestServiceResult(int messagesSent, int numberUniqueMessageClientsUsed, double averageTimeToSendMessageMs, double averageTimeToGetManagedClientMs)
		{
			MessagesSent = messagesSent;
			NumberUniqueMessageClientsUsed = numberUniqueMessageClientsUsed;
			AverageTimeToSendMessageMs = averageTimeToSendMessageMs;
			AverageTimeToGetManagedClientMs = averageTimeToGetManagedClientMs;
		}

		public override string ToString()
		{
			return $"MessagesSent: {MessagesSent}; NumberUniqueMessageClientsUsed: {NumberUniqueMessageClientsUsed}; AverageTimeToSendMessagesMs: {AverageTimeToSendMessageMs}; AverageTimeToGetManagedClientsMs: {AverageTimeToGetManagedClientMs}";
		}

	}
}