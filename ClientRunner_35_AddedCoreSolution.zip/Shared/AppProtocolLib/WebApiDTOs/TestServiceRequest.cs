﻿using System;

namespace AppProtocolLib.WebApiDTOs
{
	public class TestServiceRequest
	{
		public int JobCntr { get; set; }
		public int MessagesToSend { get; set; }
		public string MessageTemplate { get; set; }
		public int DelayToSimulateOtherWorkMs { get; set; }

		public TestServiceRequest()
		{
		}

		public TestServiceRequest(int jobCntr, int messagesToSend, string messageTemplate, int delayToSimulateOtherWorkMs)
		{
			MessagesToSend = messagesToSend;
			JobCntr = jobCntr;
			MessageTemplate = messageTemplate ?? throw new ArgumentNullException(nameof(messageTemplate));
			DelayToSimulateOtherWorkMs = delayToSimulateOtherWorkMs;
		}

		public override string ToString()
		{
			return $"JobCntr: {JobCntr}; MessagesToSend: {MessagesToSend};  MessageTemplate: {MessageTemplate}; DelayToSimulateOtherWorkMs: {DelayToSimulateOtherWorkMs}";
		}

	}
}
