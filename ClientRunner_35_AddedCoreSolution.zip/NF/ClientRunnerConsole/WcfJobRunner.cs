﻿using AppProtocolLib.TcpServerControl;
using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.IO;
using System.Linq;
using System.Threading;
using System.Threading.Tasks;

namespace ClientRunnerConsole
{
	class WcfJobRunner
	{
		private long _currentTickCount = -1;

		// TODO: Make this a Async method, and consider calling it from an Async Main Entry Point.
		public void Run(bool runSynchronously, JobSettings settings, TcpServerControllerClient serverController, TcpServerSettings tcpServerSettings)
		{
			string filePath = settings.FilePath;
			int taskCount = settings.NumberOfTasks;
			int taskSpacingMs = settings.TaskSpacingMs;
			int messagesToSendPerTask = settings.MessagesToSendPerTask;
			int serviceWorkDelayMs = settings.ServiceWorkDelayMs;
			int repeatCnt = settings.RepeatCnt;

			Console.WriteLine("Press the Enter key to start run.");
			Console.ReadLine();

			string servResponse = serverController.Start("Test1", tcpServerSettings);
			Console.WriteLine($"Response from TcpServerController: {servResponse}");
			Debug.WriteLine($"Response from TcpServerController: {servResponse}");

			using (var sw = new StreamWriter(filePath))
			{
				for (int runCounter = 0; runCounter < repeatCnt; runCounter++)
				{
					Stopwatch mainSw = Stopwatch.StartNew();

					sw.WriteLine($"For Run {runCounter}");
					sw.WriteLine("Job|StartingTickCount|Thread|Elapsed|Actual|Target|TimePerMessage{ms}|TimeToGetManagedClient(ms)|NumUniqueMessageClients");

					Task<RunResult>[] tasks = new Task<RunResult>[taskCount];
					//object[] clients = new object[taskCount];
					for (int jobCounter = 0; jobCounter < taskCount; jobCounter++)
					{
						string messageTemplate = $"Job:{jobCounter}, Sample Message";
						Thread.Sleep(taskSpacingMs);

						JobRunnerHelper.GetDurationInTicks(ref _currentTickCount);

						if (runSynchronously)
						{
							Test001WcfClient client = new Test001WcfClient();
							tasks[jobCounter] = client.SendRequests(runCounter, jobCounter, messagesToSendPerTask, messageTemplate, serviceWorkDelayMs, _currentTickCount);
							//clients[jobCounter] = client;
						}
						else
						{
							Test001WcfClientAsync client = new Test001WcfClientAsync();
							tasks[jobCounter] = client.SendRequestsAsync(runCounter, jobCounter, messagesToSendPerTask, messageTemplate, serviceWorkDelayMs, _currentTickCount);
							//clients[jobCounter] = client;
						}
					}

					try
					{
						Task.WaitAll(tasks);
						mainSw.Stop();
					}
					catch (AggregateException e)
					{
						mainSw.Stop();
						Console.WriteLine("\nThe following exceptions have been thrown by WaitAll():");
						for (int j = 0; j < e.InnerExceptions.Count; j++)
						{
							Console.WriteLine("\n-------------------------------------------------\n{0},{1}", j, e.InnerExceptions[j].ToString());
							if (e.InnerExceptions[j].InnerException != null)
							{
								Console.WriteLine("\n-------------------------------------------------\n{0},{1}", j, e.InnerExceptions[j].InnerException.ToString());
							}
						}
					}

					TimeSpan overallDuration = mainSw.Elapsed;

					IList<int> uniqueThreads = new List<int>();
					TimeSpan totalElapsed = TimeSpan.Zero;
					double[] sendTimes = new double[taskCount];

					for (int jobCounter = 0; jobCounter < taskCount; jobCounter++)
					{
						string oLine;

						Task<RunResult> t = tasks[jobCounter];
						if (!(t.IsCanceled || t.IsFaulted))
						{
							RunResult r = t.Result;
							oLine = string.Format("{0}|{1}|{2}|{3}|{4}|{5}|{6:F3}|{7}|{8}", 
								jobCounter, r.StartingTickCount, r.ThreadId, r.Elapsed.ToString(@"mm\:ss\.fff"), r.MessagesSent, messagesToSendPerTask, r.AverageTimeToSendMessageMs, r.AverageTimeToGetManagedClientMs, r.NumberUniqueMessageClientsUsed);

							if (!uniqueThreads.Contains(r.ThreadId)) uniqueThreads.Add(r.ThreadId);

							totalElapsed += r.Elapsed;
							sendTimes[jobCounter] = r.AverageTimeToSendMessageMs;
						}
						else
						{
							oLine = string.Format("{0}|{1}|{2}|{3}|{4}|{5}",
								runCounter, jobCounter, 0, 0, 0, 0, messagesToSendPerTask);
							sendTimes[jobCounter] = 0;
						}

						//clients[jobCounter] = null;

						sw.WriteLine(oLine);
					}

					int totalSent = taskCount * messagesToSendPerTask;
					double sentPerSec = totalSent / overallDuration.TotalSeconds;
					double timePerWebServiceCall = overallDuration.TotalSeconds / taskCount;
					timePerWebServiceCall *= 1000;

					Console.WriteLine($"Sent {totalSent} messages in {overallDuration.TotalSeconds} for {sentPerSec} m/s.");

					sw.WriteLine();
					sw.WriteLine(string.Format("Run={0}|NumberUniqueThreads={1}|TotalSent={2}|TotalTime(sec)={3:F4}|MessagePerSecond={4:F3}|TimePerWebServiceCall(ms)={5:F3}|AverageTimeToSendMessage(ms)={6:F3}",
								runCounter, uniqueThreads.Count, totalSent, overallDuration.TotalSeconds, sentPerSec, timePerWebServiceCall, sendTimes.Average()));
					sw.WriteLine();

					if (runCounter < repeatCnt)
					{
						//	Console.WriteLine($"Run {runCounter} completed, press Enter to continue.");
						//	Console.ReadLine();

						Thread.Sleep(settings.PauseDurationBeforeRepeatingMs);
						_currentTickCount = -1;
						mainSw.Restart();
					}
				}
			}

			servResponse = serverController.Stop("Test1");
			Console.WriteLine($"TcpServer sent stop request, has returned {servResponse}");

			Console.WriteLine("All completed, press Enter to continue.");
			Console.ReadLine();
		}

	}
}
