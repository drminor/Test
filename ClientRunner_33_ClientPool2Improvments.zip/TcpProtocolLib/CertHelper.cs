﻿using System;
using System.Net.Security;
using System.Security.Cryptography.X509Certificates;
using System.Diagnostics;

namespace TcpProtocolLib
{
	public static class CertHelper
	{
		public static readonly bool _useDetailedDebug = false;

		public static bool ValidateRemoteCert(object sender, X509Certificate certificate, X509Chain chain, SslPolicyErrors sslPolicyErrors)
		{
			if (_useDetailedDebug) Debug.WriteLine($"The sender is {sender.GetType()}, the cert subject is{certificate.Subject}, the chain is {chain}.");

			if (sslPolicyErrors == SslPolicyErrors.None) { return true; }
			if (sslPolicyErrors == SslPolicyErrors.RemoteCertificateChainErrors) { return true; } //we don't have a proper certificate tree, but that's ok for testing.;

			// Some other error, return false.
			return false;
		}

		public static X509Certificate SelectLocalCertificate(object sender, string targetHost,
			X509CertificateCollection localCertificates, X509Certificate remoteCertificate,
			string[] acceptableIssuers)
		{
			if (_useDetailedDebug) Debug.WriteLine($"The sender is {sender.GetType()}, the targetHost is{targetHost}, the remote certificate is {remoteCertificate}.");

			X509Certificate result;

			if (localCertificates != null && localCertificates.Count > 0)
			{
				if (acceptableIssuers != null && acceptableIssuers.Length > 0)
				{
					// Use the first certificate that is from an acceptable issuer.
					foreach (X509Certificate certificate in localCertificates)
					{
						string issuer = certificate.Issuer;
						if (Array.IndexOf(acceptableIssuers, issuer) != -1)
						{
							result = certificate;
							break;
						}
					}

					result = null;
				}
				else
				{
					result = localCertificates[0];
				}
			}
			else
			{
				result = null;
			}

			return result;
		}


	}
}
