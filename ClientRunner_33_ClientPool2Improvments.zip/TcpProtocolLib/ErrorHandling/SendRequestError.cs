﻿namespace TcpProtocolLib
{
	public enum SendRequestError
	{
		//Success = 0,
		ClientIsDisposed = 1,
		Timeout = 2,
		SocketException = 3,
		IOException = 4,
		IOExceptionWithInnerSocketException = 5,
		PeerClosedTheConnection = 6,
		OperationCancelled = 7,
		TooManyMessagesReceived = 8,
		CertificateError = 9,
		Other = 10
	}
}
