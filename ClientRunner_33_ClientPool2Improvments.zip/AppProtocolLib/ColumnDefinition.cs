﻿namespace AppProtocolLib
{
	public class ColumnDefinition
    {
        public readonly int Start;
        public readonly int Length;

        public int End => Start + Length - 1;

        public ColumnDefinition(int start, int length)
        {
            Start = start;
            Length = length;
        }

        public override string ToString()
        {
            return $"ColumnDefinition({Start}-{End})";
        }
    }
}
