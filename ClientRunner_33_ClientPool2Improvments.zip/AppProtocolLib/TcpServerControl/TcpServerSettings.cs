﻿using System;

namespace AppProtocolLib.TcpServerControl
{
	[Serializable]
	public class TcpServerSettings
	{
		public int Port { get; set; }
		public int MessageType { get; set; } // 1 = TestResponse001. Currently only value 1 is supported.
		public int CloseConnsAfterNoActivitySeconds { get; set; }
		public int ResponseDelayMs1 { get; set; }
		public int ResponseDelayMs2 { get; set; }
		public double UseResponseDelayMs2Frequency { get; set; }

		public string CertificateFilePath { get; set; }

		public TcpServerSettings()
		{
		}

		public TcpServerSettings(TcpServerSettings settings)
		{
			Port = settings.Port;
			MessageType = settings.MessageType;
			CloseConnsAfterNoActivitySeconds = settings.CloseConnsAfterNoActivitySeconds;
			ResponseDelayMs1 = settings.ResponseDelayMs1;
			ResponseDelayMs2 = settings.ResponseDelayMs2;
			UseResponseDelayMs2Frequency = settings.UseResponseDelayMs2Frequency;
			CertificateFilePath = settings.CertificateFilePath;
		}

	}
}
