﻿using AppProtocolLib.TcpServerControl;
using GatewayLib.ClientPool;
using System;
using System.Diagnostics;
using System.IO;
using System.Net;
using System.Net.Sockets;
using TcpProtocolLib;

namespace ClientRunnerConsole
{
	class Program
	{
		public static readonly int TCP_SERVER_CONTROL_PORT = 11233;
		public static readonly int TEST_SERVER_PORT = 11234;

		public static readonly string OUT_PUT_PATH = @"C:\Users\david\SocketTestOutput";

		public static readonly string CERT_PATH = @"C:\Users\david\ClientRunner.pfx";
		private static readonly string CERT_PASS = "Mary";
		private static readonly string PEER_PUBLIC_CERT_PATH = @"C:\Users\david\TcpServer.cer";

		static void Main(string[] args)
		{
			IPAddress localIpAddress = GetLocalHostIpAddress();

			RunSettings runSettings = ParseArgs(args);
			string folderName = runSettings.GetShortJobTypeName() + JobRunnerHelper.GetFolderName(DateTime.Now);
			string filePath = Path.Combine(OUT_PUT_PATH, folderName);
			filePath = Path.ChangeExtension(filePath, "txt");

			Console.WriteLine($"Running {runSettings.JobType}, Sync = {runSettings.RunSynchronously}");
			Debug.WriteLine($"Running {runSettings.JobType}, Sync = {runSettings.RunSynchronously}");

			Console.WriteLine("Press the Enter key to connect to the Test TcpServer.");
			Console.ReadLine();

			TcpServerSettings tcpServerSettings = new TcpServerSettings
			{
				Port = TEST_SERVER_PORT,
				MessageType = 1,
				CloseConnsAfterNoActivitySeconds = 60,
				ResponseDelayMs1 = 500, //35,
				ResponseDelayMs2 = 4120, // 200,
				UseResponseDelayMs2Frequency = 0 // 0.12 //0.66
			};

			JobSettings jobSettings = new JobSettings(
				filePath: filePath,
				numberOfTasks: 24, 
				messagesToSendPerTask: 5,
				taskSpacingMs: 30,
				repeatCnt: 10,
				pauseDurationBeforeRepeatingMs: 100,
				webServiceWorkDelayMs: 0
			);

			IPEndPoint endPoint = new IPEndPoint(runSettings.TcpServerAddress, TCP_SERVER_CONTROL_PORT);
			Console.WriteLine($"Connecting to TcpServerController: {endPoint} from {localIpAddress}.");
			Debug.WriteLine($"Connecting to TcpServerController: {endPoint} from {localIpAddress}.");

			CertInfo certInfo = new CertInfo(CERT_PATH, CERT_PASS, PEER_PUBLIC_CERT_PATH);
			using (TcpServerControllerClient serverController = new TcpServerControllerClient(endPoint, certInfo))
			{
				switch(runSettings.JobType)
				{
					case JobType.ManagedClients:
						{
							ClientPoolSettings clientPoolSettings = new ClientPoolSettings
								(
								serverEndPoint: new IPEndPoint(runSettings.TcpServerAddress, TEST_SERVER_PORT),
								minConnections: 3, //3
								maxConnections: 10,
								allocateClientTimeoutMs: TimeSpan.FromMilliseconds(3 * 1000),
								messageEncoder: new ASCII_MessageEncoder(4),
								messageResponseTimeout: TimeSpan.FromMilliseconds(150),
								certInfo: certInfo
								);

							ManagedClientJobRunner managedClientJobRunner = new ManagedClientJobRunner();
							managedClientJobRunner.Run(jobSettings, serverController, tcpServerSettings, clientPoolSettings);
							break;
						}

					case JobType.ManagedClientsAsync:
						{
							ClientPoolSettings clientPoolSettings = new ClientPoolSettings
								(
								serverEndPoint: new IPEndPoint(runSettings.TcpServerAddress, TEST_SERVER_PORT),
								minConnections: 3, //3
								maxConnections: 8,
								allocateClientTimeoutMs: TimeSpan.FromMilliseconds(8 * 1000),
								messageEncoder: new ASCII_MessageEncoder(4),
								messageResponseTimeout: TimeSpan.FromMilliseconds(5150),
								certInfo: certInfo
								);

							ManagedClientJobRunnerAsync managedClientJobRunner = new ManagedClientJobRunnerAsync();
							managedClientJobRunner.Run(jobSettings, serverController, tcpServerSettings, clientPoolSettings);
							break;
						}

					case JobType.WebServiceClients:
						{
							WcfJobRunner wcfJobRunner = new WcfJobRunner();
							wcfJobRunner.Run(false, jobSettings, serverController, tcpServerSettings);
							break;
						}

					case JobType.WebServiceClientsAsync:
						{
							WcfJobRunner wcfJobRunner = new WcfJobRunner();
							wcfJobRunner.Run(true, jobSettings, serverController, tcpServerSettings);
							break;
						}

				}
			}

			Console.WriteLine("Press the Enter key to exit.");
			Console.ReadLine();
		}

		private static RunSettings ParseArgs(string[] args)
		{
			IPAddress address;
			JobType jobType;

			if (args.Length > 0)
			{
				if (args[0].ToLower() == "localhost")
					address = IPAddress.Loopback;
				else
					address = IPAddress.Parse(args[0]);
			}
			else
			{
				address = GetLocalHostIpAddress();
			}

			if (args.Length > 1)
			{
				string strJobType = args[1].ToLower();
				if (strJobType.Contains("managed-async"))
				{
					jobType = JobType.ManagedClientsAsync;
				}
				else if (strJobType.Contains("managed"))
				{
					jobType = JobType.ManagedClients;
				}
				else if (strJobType.Contains("web-async"))
				{
					jobType = JobType.WebServiceClientsAsync;
				}
				else if (strJobType.Contains("web"))
				{
					jobType = JobType.WebServiceClients;
				}
				else
				{
					throw new ArgumentException("The 2nd argument is missing or does not specify a supported JobType.");
				}
			}
			else
			{
				jobType = JobType.ManagedClients;
			}

			return new RunSettings(address, jobType);
		}

		private static IPAddress GetLocalHostIpAddress()
		{
			IPHostEntry host = Dns.GetHostEntry(Environment.MachineName);
			foreach (IPAddress IP in host.AddressList)
			{
				if (IP.AddressFamily == AddressFamily.InterNetwork)
				{
					return IP;
				}
			}

			return null;
		}

	}
}
