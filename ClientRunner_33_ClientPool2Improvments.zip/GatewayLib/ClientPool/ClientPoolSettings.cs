﻿using System;
using System.Net;

using TcpProtocolLib;

namespace GatewayLib.ClientPool
{
	public class ClientPoolSettings
	{
		public readonly IPEndPoint ServerEndPoint;
		public readonly int MinConnections;
		public readonly int MaxConnections;
		public readonly TimeSpan AllocateClientTimeout;
		public readonly IMessageEncoder MessageEncoder;
		public readonly TimeSpan MessageResponseTimeout;
		public readonly CertInfo CertInfo;

		public ClientPoolSettings(IPEndPoint serverEndPoint, int minConnections, int maxConnections, TimeSpan allocateClientTimeoutMs, IMessageEncoder messageEncoder
			, TimeSpan messageResponseTimeout, CertInfo certInfo)
		{
			ServerEndPoint = serverEndPoint ?? throw new ArgumentNullException(nameof(serverEndPoint));
			MinConnections = minConnections;
			MaxConnections = maxConnections;
			AllocateClientTimeout = allocateClientTimeoutMs;
			MessageEncoder = messageEncoder ?? throw new ArgumentException(nameof(messageEncoder));
			MessageResponseTimeout = messageResponseTimeout;
			CertInfo = certInfo;

			if (!(minConnections > 0))
			{
				throw new ArgumentException("MinConnections must be greater than 0");
			}

			if (!(maxConnections >= minConnections))
			{
				throw new ArgumentException("MaxConnection must be greater than or equal to MinConnections.");
			}

		}
	}
}
