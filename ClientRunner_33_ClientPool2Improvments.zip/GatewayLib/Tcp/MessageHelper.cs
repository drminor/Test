﻿using System;

namespace GatewayLib.Tcp
{
	public static class MessageHelper
	{
		public static bool DoesResponseHaveExpectedCorId(string response, string correlationId, CorrelationIdInfo correlationIdInfo)
		{
			string respCorrelationId = GetCorrelationId(response, correlationIdInfo);
			return correlationId == respCorrelationId;
		}

		public static string GetCorrelationId(string response, CorrelationIdInfo correlationIdInfo)
		{
			try
			{
				string responseCorrId = response.Substring(correlationIdInfo.Offset, correlationIdInfo.Length);
				return responseCorrId.TrimEnd();
			}
			catch (Exception e)
			{
				//Debug.WriteLine($"Could not get correlationId from the response. Exception: {e.GetType()}:{e.Message}.");
				throw new InvalidOperationException("Could not get correlationId from the response.", e);
			}
		}

		private static readonly long _historicalDateTicks = (new DateTime(2020, 1, 1, 0, 0, 0)).Ticks;

		public static string GetOpId()
		{
			string id = "o:" + (DateTime.UtcNow.Ticks - _historicalDateTicks).ToString("X");
			return id;
		}

		public static string GetOpId(int poolId, int managedClientId, string messageClientId)
		{
			string id = "o:" + (DateTime.UtcNow.Ticks - _historicalDateTicks).ToString("X") + "-t:" + messageClientId + "-m:" + managedClientId.ToString() + "-p:" + poolId.ToString();
			return id;
		}

		public static string GetOpId(string oldOpId, int poolId, int managedClientId, string messageClientId)
		{
			int prevPartEnd = oldOpId.IndexOf("-t:");
			if (prevPartEnd == -1) prevPartEnd = oldOpId.Length;

			string prevOperationId  = oldOpId.Substring(0, prevPartEnd - 1);
			string id = prevOperationId + "-t:" + messageClientId + "-m:" + managedClientId.ToString() + "-p:" + poolId.ToString();
			return id;
		}



	}
}
