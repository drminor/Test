﻿using AppProtocolLib.TcpServerControl;
using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Net;

namespace TcpServerConsole
{
	class TcpServerRequestHandler : IRequestHandler
	{
		private readonly IPAddress _newServerAddress;
		private readonly IDictionary<string, IMessageServer> _messageServers;
		private readonly Test001RequestHandler _test001RequestHandler;

		public TcpServerRequestHandler(IPAddress newServerAddress)
		{
			_newServerAddress = newServerAddress;
			_messageServers = new Dictionary<string, IMessageServer>();
			_test001RequestHandler = new Test001RequestHandler();
		}

		public string GetResponse(string message)
		{
			TcpServerControlRequest request = TcpServerControlRequest.CreateNewFromMessage(message);

			TcpServerControlResponse response;

			if (request.Command == "Start")
			{
				if (_messageServers.TryGetValue(request.Key, out IMessageServer existingMmessageServer))
				{
					if (existingMmessageServer.IsStarted)
					{
						response = new TcpServerControlResponse($"An existing, currently running message server exists with key: {request.Key}.", request.CorrelationId, false);
						return response.ToMessage();
					}
					else
					{
						_messageServers.Remove(request.Key);
					}
				}

				IMessageServer messageServer = GetMessageServer(_newServerAddress, request.Settings);
				_messageServers.Add(request.Key, messageServer);
				messageServer.Start();

				Debug.WriteLine($"Starting {messageServer.TypeName}.");
				response = new TcpServerControlResponse($"Started new {messageServer.TypeName}.", request.CorrelationId, true);
			}
			else if (request.Command == "Stop")
			{
				if (_messageServers.TryGetValue(request.Key, out IMessageServer messageServer))
				{
					string stopStatus = messageServer.Stop(out bool success);
					response = new TcpServerControlResponse(stopStatus, request.CorrelationId, success);
				}
				else
				{
					response = new TcpServerControlResponse($"Could not find a message server with Key = {request.Key}.", request.CorrelationId, false);
				}
			}
			else
			{
				response = new TcpServerControlResponse("Command not recognized", request.CorrelationId, false);
			}

			return response.ToMessage();
		}

		private IMessageServer GetMessageServer(IPAddress currentAddress, TcpServerSettings settings)
		{
			IMessageServer result;

			int messageType = settings.MessageType;
			switch (messageType)
			{
				case 1:
					{
						IPEndPoint endPoint = new IPEndPoint(currentAddress, settings.Port);
						Debug.WriteLine($"Starting a new TestResponse001 server @ {endPoint}.");
						result = new MessageServer("Test001Server", endPoint, settings, _test001RequestHandler);
						break;
					}
				default:
					{
						throw new ArgumentException($"MessageType: {messageType} is not supported.");
					}
			}

			return result;
		}

	}
}
