﻿using System;
using System.Collections.Generic;
using System.Text;

namespace AppProtocolLib.TcpServerControl
{
	public enum OperationEnum
	{
		Start = 1,
		Stop = 2,
	}
}
