﻿using System;
using System.Diagnostics;
using System.Text;

namespace AppProtocolLib.TcpServerControl
{
	public class TcpServerControlResponse : IFixedWidthMessage<TcpServerControlResponse>
	{
		public static ColumnDictionary _columnDefinitions;

		static TcpServerControlResponse()
		{
			_columnDefinitions = new ColumnDictionary();
			_columnDefinitions
				.AddColumnDefinition(nameof(DateCreated), 20)
				.AddColumnDefinition(nameof(Response), 200)
				.AddColumnDefinition(nameof(Succeeded), 6)
				.AddColumnDefinition(nameof(CorrelationId), 40);
		}

		public string MessageName => nameof(TcpServerControlResponse);

		public IColumnDictionary ColumnDefinitions => _columnDefinitions;

		public DateTime DateCreated { get; set; }
		public string Response { get; set; }
		public bool Succeeded { get; set; }
		public string CorrelationId { get; set; }

		public TcpServerControlResponse() 
		{
			DateCreated = DateTime.Now;
			Response = null;
			Succeeded = false;
			CorrelationId = null;
		}

		public TcpServerControlResponse(string response, string correlationId) : this(response, correlationId, true)
		{
		}

		public TcpServerControlResponse(string response, string correlationId, bool succeeded)
		{
			DateCreated = DateTime.Now;
			Response = response;
			Succeeded = succeeded;
			CorrelationId = correlationId;
		}

		public string ToMessage()
		{
			StringBuilder sb = new StringBuilder();

			sb.Append(DateCreated.ToLongTimeString().PadRight(GetLength(nameof(DateCreated))));
			sb.Append(Response.PadRight(GetLength(nameof(Response))));
			sb.Append(Succeeded.ToString().PadRight(GetLength(nameof(Succeeded))));
			sb.Append(CorrelationId.PadRight(GetLength(nameof(CorrelationId))));

			return sb.ToString();
		}

		public string GetRequestCorrelationId(string message)
		{
			TcpServerControlRequest temp = TcpServerControlRequest.CreateNewFromMessage(message);
			string result = temp.CorrelationId;
			return result;
		}

		public static TcpServerControlResponse CreateNewFromMessage(string m)
		{
			TcpServerControlResponse result = new TcpServerControlResponse();

			ColumnDefinition cd = _columnDefinitions[nameof(DateCreated)];
			result.DateCreated = DateTime.Parse(m.Substring(cd.Start, cd.Length));

			cd = _columnDefinitions[nameof(Response)];
			result.Response = m.Substring(cd.Start, cd.Length).TrimEnd();

			cd = _columnDefinitions[nameof(Succeeded)];
			result.Succeeded = bool.Parse(m.Substring(cd.Start, cd.Length));

			cd = _columnDefinitions[nameof(CorrelationId)];
			result.CorrelationId = m.Substring(cd.Start, cd.Length).TrimEnd();

			return result;
		}

		private int GetLength(string columnName)
		{
			int length = _columnDefinitions[columnName].Length;
			return length;
		}

		// Just for testing.
		public void CheckTestResponse001(string s)
		{
			TcpServerControlResponse tm = CreateNewFromMessage(s);

			string t = tm.ToMessage();

			Debug.Assert(s == t, "TestResponse001 cannot roundtrip.");
		}

	}
}
