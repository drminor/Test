﻿using GatewayLib.Gateway;
using GatewayLib.Tcp;
using System;
using System.Diagnostics;
using System.Threading.Tasks;

namespace ClientRunnerConsole
{
	static class JobRunnerHelper
	{
		public static long GetDurationInTicks(ref long previousTickCounter)
		{
			long tickCount = Environment.TickCount;
			long diff = previousTickCounter == -1 ? 0 : tickCount - previousTickCounter;
			previousTickCounter = tickCount;

			return diff;
		}

		public static string GetFolderName(DateTime t)
		{
			return t.ToString("yyyy_MM_dd_HH_mm_ss");
		}
	}
}
