﻿using System;

namespace ClientRunnerConsole
{
	class JobSettings
	{
		public readonly bool RunSynchronously;
		public readonly string FilePath;
		public readonly int NumberOfTasks;
		public readonly int MessagesToSendPerTask;
		public readonly int TaskSpacingMs;
		public readonly int RepeatCnt;
		public readonly int PauseDurationBeforeRepeatingMs;
		public readonly int ServiceWorkDelayMs;

		public JobSettings(bool runSynchronously, string filePath, int numberOfTasks, int messagesToSendPerTask,
			int taskSpacingMs, int repeatCnt, int pauseDurationBeforeRepeatingMs, int webServiceWorkDelayMs)
		{
			RunSynchronously = runSynchronously;
			FilePath = filePath ?? throw new ArgumentNullException(nameof(filePath));
			NumberOfTasks = numberOfTasks;
			TaskSpacingMs = taskSpacingMs;
			MessagesToSendPerTask = messagesToSendPerTask;
			ServiceWorkDelayMs = webServiceWorkDelayMs;
			RepeatCnt = repeatCnt;
			PauseDurationBeforeRepeatingMs = pauseDurationBeforeRepeatingMs;
		}

	}
}
