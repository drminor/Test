﻿using ClientRunnerConsole.ServiceReference2;
using System;
using System.Diagnostics;
using System.Threading;
using System.Threading.Tasks;

namespace ClientRunnerConsole
{
	class Test001WcfClient
	{
		private readonly bool _useDetailedDebug = false;

		public Task<RunResult> SendRequests(int runCounter, int jobCounter, int messagesToSend, string messageTemplate, int serviceWorkDelayMs, long currentTickCount)
		{
			var callingThread = Thread.CurrentThread;
			Task<RunResult> result = Task<RunResult>.Factory.StartNew(s =>
			{
				var runnerThread = Thread.CurrentThread;
				if (_useDetailedDebug) Debug.WriteLine($"Thread: {callingThread.ManagedThreadId}(TP={callingThread.IsThreadPoolThread}) is calling the WebService, using runner Thread: {runnerThread.ManagedThreadId}.");
				try
				{
					return SendRequestsInternal(runCounter, jobCounter, messagesToSend, messageTemplate, serviceWorkDelayMs, currentTickCount);
				}
				catch (Exception e)
				{
					Debug.WriteLine($"The Test001WcfClient Got {e.GetType()}: {e.Message}.");
					return null;
				}
			}, null, CancellationToken.None, TaskCreationOptions.None, TaskScheduler.Default
			);

			return result;
		}

		private RunResult SendRequestsInternal(int runCounter, int jobCounter, int messagesToSend, string messageTemplate, int serviceWorkDelayMs, long currentTickCount)
		{
			long startingTickCount = JobRunnerHelper.GetDurationInTicks(ref currentTickCount);

			Service1SyncClient webService = new Service1SyncClient();

			TimeSpan elapsed;

			Stopwatch s = Stopwatch.StartNew();

			TestServiceResult serviceResult;
			try
			{
				serviceResult = webService.SendMessages(messagesToSend, jobCounter, messageTemplate, serviceWorkDelayMs);
			}
			catch (Exception e)
			{
				serviceResult = null;
				string errorMessage = e.GetBaseException().Message;
				Debug.WriteLine($"Job received {errorMessage}");
			}

			s.Stop();
			webService.Close();

			elapsed = s.Elapsed;

			int messagesSent = serviceResult?.MessagesSent ?? 0;
			string resultStatus = $"Sent {messagesSent} out of {messagesToSend}";
			Console.WriteLine("Run={0} | Job={1} | TickCount={2} | Thread={3} | elapsed={4} | sent:{5}",
				runCounter, jobCounter, startingTickCount, Thread.CurrentThread.ManagedThreadId, elapsed.ToString(@"mm\:ss\.fff"), resultStatus);

			Debug.WriteLine("Run={0} | Job={1} | TickCount={2} | Thread={3} | elapsed={4} | sent:{5}",
				runCounter, jobCounter, startingTickCount, Thread.CurrentThread.ManagedThreadId, elapsed.ToString(@"mm\:ss\.fff"), resultStatus);

			RunResult result = new RunResult(startingTickCount, Thread.CurrentThread.ManagedThreadId, elapsed, messagesSent)
			{
				AverageTimeToSendMessageMs = serviceResult?.AverageTimeToSendMessageMs ?? 0,
				AverageTimeToGetManagedClientMs = serviceResult?.AverageTimeToGetManagedClientMs ?? 0,
				NumberUniqueMessageClientsUsed = serviceResult?.NumberUniqueMessageClientsUsed ?? 0
			};

			return result;
		}

	}
}
