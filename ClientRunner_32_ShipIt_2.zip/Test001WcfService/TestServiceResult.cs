﻿using System.Runtime.Serialization;

namespace Test001WcfService
{
	[DataContract ]
	public class TestServiceResult
	{
		[DataMember]
		public readonly int MessagesSent;

		[DataMember]
		public readonly int NumberUniqueMessageClientsUsed;

		[DataMember]
		public readonly double AverageTimeToSendMessageMs;

		[DataMember]
		public readonly double AverageTimeToGetManagedClientMs;

		public TestServiceResult(int messagesSent, int numberUniqueMessageClientsUsed, double averageTimeToSendMessageMs, double averageTimeToGetManagedClientMs)
		{
			MessagesSent = messagesSent;
			NumberUniqueMessageClientsUsed = numberUniqueMessageClientsUsed;
			AverageTimeToSendMessageMs = averageTimeToSendMessageMs;
			AverageTimeToGetManagedClientMs = averageTimeToGetManagedClientMs;
		}
	}
}