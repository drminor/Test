﻿using AppProtocolLib;
using GatewayLib.Gateway;
using GatewayLib.Tcp;
using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Linq;
using System.Threading;
using System.Threading.Tasks;

namespace Test001WcfService
{
	public class Test001ServiceSync : IService1Sync
	{
		static readonly CorrelationIdInfo ResponseCorrelationIdInfo;

		static Test001ServiceSync()
		{
			ColumnDefinition coreIdCd = TestResponse001._columnDefinitions["CorrelationId"];
			ResponseCorrelationIdInfo = new CorrelationIdInfo(coreIdCd.Start, coreIdCd.Length);
		}

		private readonly IGateway<IMessageClient> _gateway;

		public Test001ServiceSync(IGateway<IMessageClient> gateway)
		{
			_gateway = gateway;
		}

		public TestServiceResult SendMessages(int messagesToSend, int jobCntr, string messageTemplate, int delayToSimulateOtherWorkMs)
		{
			int messagesSent = 0;
			IList<string> uniqueMessageClientIds = new List<string>();
			IList<double> sendTimeMs = Enumerable.Repeat(0d, messagesToSend).ToList();
			long timeToGetClient;

			if (delayToSimulateOtherWorkMs > 14)
			{
				//Debug.WriteLine($"TestService waiting {delayToSimulateOtherWorkMs}ms to simulate other work.");
				Thread.Sleep(delayToSimulateOtherWorkMs);
			}

			Stopwatch s = Stopwatch.StartNew();
			using (IManagedClient managedClient = GetManagedClient(_gateway))
			{
				if (managedClient == null)
				{
					s.Stop();
					timeToGetClient = s.ElapsedMilliseconds;
					Debug.WriteLine($"The Test001Service could not get a ManagedClient from the pool. Took {s.ElapsedMilliseconds} ms");
				}
				else
				{
					s.Stop();
					timeToGetClient = s.ElapsedMilliseconds;

					string strJobCntr = jobCntr.ToString().PadLeft(3);

					for (int messageCounter = 0; messageCounter < messagesToSend; messageCounter++)
					{
						string strMessageCntr = messageCounter.ToString().PadLeft(5);
						string command = $"{messageTemplate}{strMessageCntr}";

						TestMessage001 message = new TestMessage001
						{
							DateCreated = DateTime.Now,
							Command = command,
							Extra = string.Empty,
							CorrelationId = strJobCntr + strMessageCntr
						};

						s.Restart();
						try
						{
							string id = managedClient.MessageClientIdentifier;
							if (!uniqueMessageClientIds.Contains(id)) uniqueMessageClientIds.Add(id);

							TestResponse001 response = SendRequest(managedClient, message, s);
							s.Stop();

							if (response.Succeeded)
								messagesSent++;
						}
						catch (Exception e)
						{
							s.Stop();
							string errorMessage = e.GetBaseException().Message;
							Debug.WriteLine($"Test001Service received {e.GetType()}: {errorMessage}");
						}

						sendTimeMs[messageCounter] = s.ElapsedMilliseconds;
					}
				}

				TestServiceResult result = new TestServiceResult(messagesSent, uniqueMessageClientIds.Count, sendTimeMs.Average(), timeToGetClient);

				return result;
			}
		}

		private TestResponse001 SendRequest(IManagedClient managedClient, TestMessage001 message, Stopwatch s)
		{
			TestResponse001 result;

			string strMessage = message.ToMessage();
			string strResponse;
			long e1 = s.ElapsedMilliseconds;

			try
			{
				// TODO: Implement the "non-async" method here, instead of in the IManagedClient implementation.
				strResponse = managedClient.SendAndReadResponse(strMessage, message.CorrelationId, ResponseCorrelationIdInfo);

				result = new TestResponse001(strResponse, strMessage);
				Debug.WriteLine($"The Test001Service took {s.ElapsedMilliseconds - e1} ms to send {message.Command}.");
			}
			catch (Exception e)
			{
				strResponse = $"The Test001Service took {s.ElapsedMilliseconds - e1} ms, and then raised exception {e.GetType()}:{e.Message} while sending {message.Command}.";
				Debug.WriteLine(strResponse);

				result = new TestResponse001(strResponse, strMessage)
				{
					Succeeded = false
				};
			}

			return result;
		}

		private IManagedClient GetManagedClient(IGateway<IMessageClient> gateway)
		{
			try
			{
				IManagedClient managedClient = Task.Run(() => gateway.GetManagedClientAsync()).GetAwaiter().GetResult();
				return managedClient;
			}
			catch
			{
				Debug.WriteLine($"The Test001ServiceSync could not get a client from the gateway.");
				return null;
			}
		}

	}
}
