﻿using GatewayLib.Tcp;

namespace GatewayLib.ClientPool
{
	public delegate IClientPool<T> CreateClientPool<T>(ClientPoolSettings clientPoolSettings, CreateMessageClient clientCreator) where T : class, IMessageClient;
}
