﻿#define CHECK_FOR_DISPOSED_CLIENTS
#define CHECK_FOR_REGISTERED_CLIENTS

using GatewayLib.Gateway;
using GatewayLib.Tcp;
using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Linq;
using System.Net;
using System.Threading;
using System.Threading.Tasks;
using TcpProtocolLib;

namespace GatewayLib.ClientPool
{
	public class ClientPool2<T> : IClientPool<T>, IDisposable where T : class, IMessageClient
	{
		#region Private Properties

		private readonly CertInfo _certInfo;
		private readonly IList<IPooledClient> _allClients;
		private readonly Queue<T> _pool;
		private readonly LinkedList<TcsPlus> _waiters;

		private int NumberAllocated;
		private int NumberFree;
		private string FreeAllocatedPhrase => $"free: {NumberFree}, allocated: {NumberAllocated}";

		private int NumberCreated;
		private int NumberDestroyed;
		private int NumberOfRequests;
		private int NumberOfHits;

		private int NumberOfGetClientTimeouts;

		private int NumberOfReturns;
		private int NumberOfDiscards;
		private int NumberOfPoolAdds;

		private readonly CreateMessageClient _clientCreator;
		private readonly ReaderWriterLockSlim _locker;

		private readonly bool _useDetailedDebug = false;
		//private readonly bool _reportTimeToAllocateClient = false;

		private static int _poolInstanceCounter = 0;

		#endregion

		#region Constructor

		public ClientPool2(ClientPoolSettings clientPoolSettings, CreateMessageClient clientCreator)
		{
			InstanceId = _poolInstanceCounter++;

			ServerEndPoint = clientPoolSettings.ServerEndPoint;
			MinClients = clientPoolSettings.MinConnections;
			MaxClients = clientPoolSettings.MaxConnections;
			AllocateClientTimeout = clientPoolSettings.AllocateClientTimeout;
			MessageEncoder = clientPoolSettings.MessageEncoder;
			MessageResponseTimeout = clientPoolSettings.MessageResponseTimeout;
			_certInfo = clientPoolSettings.CertInfo;

			_clientCreator = clientCreator;

			_allClients = new List<IPooledClient>();
			_pool = new Queue<T>();
			_waiters = new LinkedList<TcsPlus>();

			NumberAllocated = 0;

			_locker = new ReaderWriterLockSlim();

			PollForFreeClientDuration = TimeSpan.FromMilliseconds(DEFAULT_POLL_FOR_FREE_CLIENT_DURATION_MS);
			MinimumInactivityDuration = TimeSpan.FromMilliseconds(DEFAULT_MINIMUM_INACTIVITY_DURATION_MS);

			string valMsg = ValidateGetClientTimeout(AllocateClientTimeout, PollForFreeClientDuration);
			if (valMsg != null)
			{
				throw new ArgumentException(valMsg);
			}

			FillPool(MinClients);
			Debug.WriteLine($"ClientPool created, {FreeAllocatedPhrase}.");
		}

		#endregion

		#region Public Properties

		public static CreateClientPool<T> ClientPoolCreator => (ClientPoolSettings clientPoolSettings, CreateMessageClient clientCreator)
			=> new ClientPool2<T>(clientPoolSettings, clientCreator);

		public TimeSpan AllocateClientTimeout { get; private set; }
		public TimeSpan PollForFreeClientDuration { get; private set; }
		public TimeSpan MinimumInactivityDuration { get; private set; }

		public const int DEFAULT_POLL_FOR_FREE_CLIENT_DURATION_MS = 20;
		public const int DEFAULT_MINIMUM_INACTIVITY_DURATION_MS = 2500;

		public int InstanceId { get; }

		public readonly IPEndPoint ServerEndPoint;
		public readonly int MinClients;
		public readonly int MaxClients;
		public readonly IMessageEncoder MessageEncoder;
		public readonly TimeSpan MessageResponseTimeout;

		public bool IsClosed
		{
			get
			{
				_locker.EnterReadLock();
				try
				{
					return disposedValue;
				}
				finally
				{
					_locker.ExitReadLock();
				}
			}
		}

		#endregion

		#region Public Methods -- Read Only
		
		public PoolStats GetPoolStats()
		{
			_locker.EnterReadLock(); // Keep writers out while making the copy.
			try
			{
				return GetPoolStatsInternal();
			}
			finally
			{
				_locker.ExitReadLock();
			}
		}

		public IList<IPooledClient> GetAllClients()
		{
			_locker.EnterReadLock(); // Keep writers out while making the copy.
			try
			{
				List<IPooledClient> result = _allClients.AsEnumerable().ToList();
				return result;
			}
			finally
			{
				_locker.ExitReadLock();
			}
		}

		#endregion

		#region Public Methods -- Can Change State

		public T GetClient(string opId)
		{
			T client = Task.Run(() => GetClientAsync(opId)).GetAwaiter().GetResult();
			return client;
		}

		public async Task<T> GetClientAsync(string opId)
		{
			return await GetClientAsync(null, opId);
		}

		// Throws GatewayException,	ErrorCode = Timeout, ClientPoolIsDisposed, or Other.
		public async Task<T> GetClientAsync(T clientToReturn, string opId)
		{
			if (IsClosed)
			{
				if (clientToReturn != null)
				{
					ReturnClient(clientToReturn);
				}
				throw new GatewayException(GatewayOperationEnum.GetClientFromPool, GatewayError.ClientPoolIsDisposed);
			}

			Thread requestingThread = Thread.CurrentThread;
			Stopwatch s = null;
			PoolStats t0 = null;
			PoolStatPair pr = null;

			T client;
			bool requestSatisfiedImmediately;
			TcsPlus tcs = null;

			_locker.EnterUpgradeableReadLock();
			try
			{
				NumberOfRequests++;

				t0 = GetPoolStatsInternal();

				if (clientToReturn != null)
				{
					ReturnClient(clientToReturn);
				}

				s = Stopwatch.StartNew();

				requestSatisfiedImmediately = TrySatisfyRequestImmediately(out client);
				if (requestSatisfiedImmediately)
				{
					s.Stop();
				}
				else
				{
					tcs = new TcsPlus(opId);
					_waiters.AddLast(tcs);
				}
			}
			catch (Exception e)
			{
				throw new GatewayException("Unexpected Exception occured while retrieving a client.", GatewayOperationEnum.GetClientFromPool, GatewayError.Other, e);
			}
			finally
			{
				_locker.ExitUpgradeableReadLock();
			}

			if (!requestSatisfiedImmediately)
			{
				Debug.Assert(tcs != null, "tcs is null");
				if (_useDetailedDebug) Debug.WriteLine($"Thread {Thread.CurrentThread.ManagedThreadId} is waiting on the FreeClientQ - AAResetEvent to become signaled or timed-out at {GetTime()}. {opId}");

				Task winner = await Task.WhenAny(tcs.Task, Task.Delay(AllocateClientTimeout, CancellationToken.None));

				_locker.EnterUpgradeableReadLock();
				try
				{
					if (winner == tcs.Task)
					{
						// The task was signaled.
						if (_useDetailedDebug) Debug.WriteLine($"FreeClientQ - AAResetEvent is returning true because we were signaled, using Thread: {Thread.CurrentThread.ManagedThreadId} at {GetTime()}. {GetSignaledInfo(useLock: true)}. {opId}");
						client = tcs.Client;
					}
					else
					{
						// We timed-out; remove our reference to the task.
						if (tcs.Result == true)
						{
							// Set has been called after Task.Delay completed, but before we could take the lock.
							if (_useDetailedDebug) Debug.WriteLine($"FreeClientQ - AAResetEvent is returning true after timeout, using the Delay Thread: {Thread.CurrentThread.ManagedThreadId} at {GetTime()}. {GetSignaledInfo(useLock: false)}. {opId}");
							client = tcs.Client;
						}
						else
						{
							bool removed = _waiters.Remove(tcs);
							if (!removed)
							{
								Debug.WriteLine("FreeClientQ - WARNING Tcs was not removed from the LList of waiters.");
							}
							Debug.Assert(removed);
							if (_useDetailedDebug) Debug.WriteLine($"FreeClientQ - AAResetEvent is returning false after timeout, using the Delay Thread: {Thread.CurrentThread.ManagedThreadId} at {GetTime()}. {GetSignaledInfo(useLock: false)}. {opId}");

							client = null;
						}
					}
				}
				finally
				{
					_locker.ExitUpgradeableReadLock();
				}
			}
			else
			{
				Debug.Assert(client != null, "The client is null, but requestSatisfiedImmediately is true.");
			}

			_locker.EnterReadLock();
			try
			{
				var continueThread = Thread.CurrentThread;
				string threadInfo = (continueThread.ManagedThreadId != requestingThread.ManagedThreadId) ? $"ThreadInfo: Call made on {requestingThread.ManagedThreadId}, continuing on {continueThread.ManagedThreadId}." : null;

				string ems = null;
				if (s != null)
				{
					s.Stop();
					ems = s.ElapsedMilliseconds.ToString("F4");
				}

				if (t0 != null)
				{
					PoolStats t1 = GetPoolStatsInternal();
					pr = new PoolStatPair(t0, t1);
				}

				if (client == null)
				{
					Debug.WriteLine($"ClientPool::GetClient waited {ems} but was unable to provide a client. PoolStatDiff: {pr}. {threadInfo}");
					Interlocked.Increment(ref NumberOfGetClientTimeouts);
					throw new GatewayException(GatewayOperationEnum.GetClientFromPool, GatewayError.Timeout);
				}
				else
				{
					CheckClientDisposed(client, "Just provided by GetClientAsync.", true);
					CheckIsClientRegistered(client, "Just provided by GetClientAsync.");
					client.LastProvidedDate = DateTime.Now;
					client.ProvidedCount++;

					NumberOfHits++;

					Debug.WriteLine($"ClientPool::GetClient provided client: {client.Identifier} in {ems} milliseconds. PoolStatDiff: {pr}. {threadInfo}");
					return client;
				}
			}
			finally
			{
				_locker.ExitReadLock();
			}
		}

		#endregion

		#region Private Methods

		private bool TrySatisfyRequestImmediately(out T client)
		{
			client = null;
			bool result;

			if (_waiters.Count > 0)
			{
				// Other requestors are waiting for a client to become free, this requestor must "get in line."
				result = false;
			}
			else
			{
				result = TryGetClientNoWait(out client);
			}

			return result;
		}

		private bool TryGetClientNoWait(out T client)
		{
			if (TryTakeConnectedClient(out client))
			{
				// Found an available client, remove it from the pool and return it the caller.
				if (_useDetailedDebug) Debug.WriteLine($"ClientPool retrieved an existing client: {client.Identifier}, {FreeAllocatedPhrase}.");
				return true;
			}

			if (TryAddNewClient(out client))
			{
				// Added a new client, return it to the caller.
				if (_useDetailedDebug) Debug.WriteLine($"ClientPool had less than {MaxClients}. Created a brand new client. {FreeAllocatedPhrase}.");
				return true;
			}

			return false;
		}

		private bool TryTakeConnectedClient(out T client)
		{
			client = null;
			bool result = false;

			T testClient;
			bool connectedClientFound = false;
			bool clientFound;

			_locker.EnterWriteLock();

			try
			{
				if (disposedValue) return false;

				do
				{
					if (_pool.Count > 0)
					{
						testClient = _pool.Dequeue();
						clientFound = true;
					}
					else
					{
						testClient = null;
						clientFound = false;
					}

					if (clientFound)
					{
						NumberFree--;

						bool clientIsDisposed = IsClientDisposed(testClient, out string id);
						if (clientIsDisposed) Debug.WriteLine("We must be in the process of being disposed.");
						if (clientIsDisposed || !testClient.IsConnected)
						{
							DiscardClient(testClient, id, true);
						}
						else
						{
							client = testClient;
							connectedClientFound = true;
							result = true;
						}
					}
				}
				while (clientFound && !connectedClientFound);
			}
			finally
			{
				_locker.ExitWriteLock();
			}

			return result;
		}

		private bool TryAddNewClient(out T client)
		{
			client = null;

			if (NumberAllocated < MaxClients)
			{
				_locker.EnterWriteLock();
				try
				{
					if (disposedValue) return false;
					client = (T)_clientCreator(ServerEndPoint, MessageEncoder, MessageResponseTimeout, _certInfo);

					_allClients.Add(client);
					NumberAllocated++;
					NumberCreated++;
				}
				finally
				{
					_locker.ExitWriteLock();
				}
				return true;
			}
			else
			{
				return false;
			}
		}

		#region NOT USED

		//private async Task<T> GetOrCreateClient(string opId)
		//{
		//	T client;

		//	// TODO: Use Interlocked
		//	NumberOfRequests++;

		//	client = await GetConnectedClientAsync(opId);
		//	if (client != null)
		//	{
		//		// Found an available client.
		//		if(_useDetailedDebug) Debug.WriteLine($"ClientPool retrieved an existing client: {client.Identifier}, {FreeAllocatedPhrase}.");
		//		client.LastProvidedDate = DateTime.Now;
		//		client.ProvidedCount++;
		//	}
		//	else
		//	{
		//		if (TryAddNewClient(out client))
		//		{
		//			// Added a new client, return it to the caller.
		//			if (_useDetailedDebug) Debug.WriteLine($"ClientPool had less than {MaxClients}. Created a brand new client. {FreeAllocatedPhrase}.");
		//			client.LastProvidedDate = DateTime.Now;
		//			client.ProvidedCount++;
		//		}
		//		else
		//		{
		//			client = null;
		//		}
		//	}

		//	// TODO: Use Interlocked
		//	NumberOfHits++;

		//	return client;
		//}

		//private async Task<T> GetConnectedClientAsync(string opId)
		//{
		//	T client = null;

		//	T testClient;
		//	bool connectedClientFound = false;

		//	if (IsClosed)
		//	{
		//		throw new GatewayException(GatewayOperationEnum.GetClientFromPool, GatewayError.ClientPoolIsDisposed);
		//	}

		//	do
		//	{
		//		testClient = await _pool.WaitForClient(AllocateClientTimeout, opId);

		//		if(testClient != null)
		//		{
		//			// TODO: Use Interlocked
		//			NumberFree--;

		//			bool clientIsDisposed = IsClientDisposed(testClient, out string id);
		//			if (clientIsDisposed) Debug.WriteLine("We must be in the process of being disposed.");
		//			if (clientIsDisposed || !testClient.IsConnected)
		//			{
		//				_locker.EnterWriteLock();
		//				try
		//				{
		//					if (disposedValue) return null;
		//					DiscardClient(testClient, id, true);
		//				}
		//				finally
		//				{
		//					_locker.ExitWriteLock();
		//				}
		//			}
		//			else
		//			{
		//				client = testClient;
		//				connectedClientFound = true;
		//			}
		//		}
		//	}
		//	while (testClient != null && !connectedClientFound);

		//	return client;
		//}

		//private bool TryAddNewClient(out T client)
		//{
		//	client = null;

		//	if (NumberAllocated < MaxClients)
		//	{
		//		_locker.EnterWriteLock();
		//		try
		//		{
		//			if (disposedValue) return false;
		//			client = (T)_clientCreator(ServerEndPoint, MessageEncoder, MessageResponseTimeout, _certInfo);

		//			_allClients.Add(client);
		//			NumberAllocated++;
		//			NumberCreated++;
		//		}
		//		finally
		//		{
		//			_locker.ExitWriteLock();
		//		}

		//		return true;
		//	}
		//	else
		//	{
		//		return false;
		//	}
		//}

		#endregion

		public void ReturnClient(T client)
		{
			if (client == null) return;

			CheckIsClientRegistered(client, "PoolRequestProcessor handling a return.");
			bool clientIsDisposed = IsClientDisposed(client, out string id);

			bool clientWasDiscarded;
			TcsPlus waiter = null;

			_locker.EnterWriteLock();
			try
			{
				if (disposedValue)
				{
					if (!clientIsDisposed) client.Dispose();
					return;
				}

				NumberOfReturns++;

				if (clientIsDisposed || client.IsClosed)
				{
					Debug.WriteLine($"ClientPool is discarding {id}. The Client's Tcp connection is closed.");
					DiscardClient(client, id, clientIsDisposed);
					clientWasDiscarded = true;
				}
				else if (ShouldClientBeDiscarded(client, NumberAllocated, MinClients, MinimumInactivityDuration))
				{
					double secondsSinceLastUse = (DateTime.Now - client.LastUsedDate).TotalSeconds;
					Debug.WriteLine($"ClientPool is discarding {id}. Client has not been used in {secondsSinceLastUse} seconds and we are {NumberAllocated - MinClients} over the minimum of {MinClients}, {FreeAllocatedPhrase}.");
					DiscardClient(client, id, clientIsDisposed);
					clientWasDiscarded = true;
				}
				else
				{
					if (_useDetailedDebug) Debug.WriteLine($"ClientPool is returning {id}. {FreeAllocatedPhrase}, Client used for {(DateTime.Now - client.LastFreedDate).TotalSeconds} seconds.");
					client.LastFreedDate = DateTime.Now;
					client.FreedCount++;
					NumberFree++;
					clientWasDiscarded = false;
				}

				if(_waiters.Count > 0)
				{
					waiter = _waiters.First.Value;
					_waiters.RemoveFirst();
				}
				else
				{
					if (!clientWasDiscarded)
					{
						_pool.Enqueue(client);
						NumberOfPoolAdds++;
					}
				}
			}
			finally
			{
				_locker.ExitWriteLock();
			}

			if (waiter != null)
			{
				if (clientWasDiscarded)
				{
					// Create a new client so that we can satisfy the pending waiting request.
					client = (T)_clientCreator(ServerEndPoint, MessageEncoder, MessageResponseTimeout, _certInfo);
					_allClients.Add(client);
					NumberCreated++;
					NumberAllocated++;
				}

				waiter.Client = client;
				waiter.Tcs.SetResult(true);
			}
		}

		private void DiscardClient(T client, string id, bool clientIsDisposed)
		{
			_allClients.Remove(client);
			NumberOfDiscards++;
			NumberDestroyed++;
			NumberAllocated--;

			if (_useDetailedDebug) Debug.WriteLine($"ClientPool has removed {id}, {FreeAllocatedPhrase}.");

			if (!clientIsDisposed)
				client.Dispose();
		}

		private void FillPool(int size)
		{
			_locker.EnterWriteLock();
			try
			{
				if (disposedValue) return;
				while (_allClients.Count < size)
				{
					T client = (T)_clientCreator(ServerEndPoint, MessageEncoder, MessageResponseTimeout, _certInfo);

					_allClients.Add(client);
					NumberCreated++;
					NumberAllocated++;

					_pool.Enqueue(client);
					NumberFree++;
					NumberOfPoolAdds++;
				}
			}
			finally
			{
				_locker.ExitWriteLock();
			}
		}

		private bool ShouldClientBeDiscarded(IPooledClient client, int numberAllocated, int minimumClients, TimeSpan minimumInactivityDuration)
		{
			bool result;

			if (numberAllocated > minimumClients)
			{
				result = DateTime.Now - client.LastUsedDate > minimumInactivityDuration;
			}
			else
			{
				result = false;
			}

			return result;
		}

		private PoolStats GetPoolStatsInternal()
		{
			return PoolStatHelper.GetPoolStats(NumberAllocated, NumberFree,
			NumberCreated, NumberDestroyed,
			NumberOfRequests, NumberOfHits,
			NumberOfReturns, NumberOfDiscards,
			NumberOfPoolAdds, _allClients.AsEnumerable().ToList());
		}

		#endregion

		#region Checks and Helpers

		[Conditional("CHECK_FOR_DISPOSED_CLIENTS")]
		private void CheckClientDisposed(IPooledClient client, string context, bool throwWhenDisposed)
		{
			try
			{
				string _ = client.Identifier;
			}
			catch (ObjectDisposedException)
			{
				Debug.WriteLine($"WARNING: The pooled client has already been disposed. Context={context}");
				if (throwWhenDisposed) throw;
			}
		}
		
		private bool IsClientDisposed(IPooledClient client, out string id)
		{
			try
			{
				id = client?.Identifier ?? "client is null";
				return false;
			}
			catch (ObjectDisposedException)
			{
				id = "disposed";
				return true;
			}
		}

		[Conditional("CHECK_FOR_REGISTERED_CLIENTS")]
		private void CheckIsClientRegistered(IPooledClient client, string context)
		{
			string id = "disposed";
			try
			{
				id = client.Identifier;
			}
			catch (ObjectDisposedException) { }

			if (!_allClients.Contains(client))
				Debug.WriteLine($"WARNING: The client: {id} is not being managed from this pool. Context={context}");
		}

		private string ValidateGetClientTimeout(TimeSpan timeout, TimeSpan pollForFreeClientDuration)
		{
			// The duration to wait for a client to become available must be at least 4 times the poll duration.
			const double factor = 4;
			double maxPollDuration = timeout.TotalMilliseconds / factor;

			if (pollForFreeClientDuration.TotalMilliseconds > maxPollDuration)
			{
				return $"The GetClientTimeout must be at least {factor} times as long as the PollForFreeClientDuration.";
			}
			else
			{
				return null;
			}
		}

		#endregion

		#region IDisposable Support

		private void Clear()
		{
			int free = _pool.Count();
			int total = _allClients.Count;

			if (free != total)
			{
				Debug.WriteLine($"Warning: There are {total - free} clients that not been returned to the pool. There are only {free} free clients out of {total}, total.");
			}

			// Remove all items from the blocking collection.
			NumberFree -= free;
			_pool.Clear();

			foreach (IPooledClient client in _allClients)
			{
				try
				{
					client.Dispose();
				}
				catch (ObjectDisposedException)
				{
					// ignore
				}
			}

			NumberDestroyed += total;
			_allClients.Clear();
		}

		private bool disposedValue = false; // To detect redundant calls

		protected virtual void Dispose(bool disposing)
		{
			if (!disposedValue)
			{
				if (disposing)
				{
					// Dispose managed state (managed objects).
					_locker.EnterWriteLock();
					try
					{
						//StopBackgroundProcessor();
						Clear();
						//_pool.Dispose();
					}
					finally
					{
						disposedValue = true;
						_locker.ExitWriteLock();
						//_locker.Dispose();
					}
				}
			}
		}

		public void Dispose()
		{
			Dispose(true);
		}

		#endregion

		#region Async Support

		#region NOT USED

		//private Task<T> WaitForClient(TimeSpan timeout, string opId)
		//{
		//	return WaitAsync(timeout, CancellationToken.None, opId);
		//}

		//private async Task<T> WaitAsync(TimeSpan timeout, CancellationToken cancellationToken, string opId)
		//{
		//	TcsPlus tcs;

		//	if (_useDetailedDebug) Debug.WriteLine($"FreeClientQ - at start wait: {GetSignaledInfo(useLock: false)}. {opId}");

		//	tcs = new TcsPlus(opId);
		//	_waiters.AddLast(tcs);

		//	if (_useDetailedDebug) Debug.WriteLine($"Thread {Thread.CurrentThread.ManagedThreadId} is waiting on the FreeClientQ - AAResetEvent to become signaled or timed-out at {GetTime()}. {opId}");

		//	Task winner = await Task.WhenAny(tcs.Task, Task.Delay(timeout, cancellationToken));

		//	//lock (_stateLock)
		//	//{
		//		if (winner == tcs.Task)
		//		{
		//			// The task was signaled.
		//			if (_useDetailedDebug) Debug.WriteLine($"FreeClientQ - AAResetEvent is returning true because we were signaled, using Thread: {Thread.CurrentThread.ManagedThreadId} at {GetTime()}. {GetSignaledInfo(useLock: true)}. {opId}");

		//			return GetResult(_pool);
		//		}
		//		else
		//		{
		//			// We timed-out; remove our reference to the task.
		//			if (tcs.Result == true)
		//			{
		//				// Set has been called after Task.Delay completed, but before we could take the lock.

		//				if (_useDetailedDebug) Debug.WriteLine($"FreeClientQ - AAResetEvent is returning true after timeout, using the Delay Thread: {Thread.CurrentThread.ManagedThreadId} at {GetTime()}. {GetSignaledInfo(useLock: false)}. {opId}");

		//				//Debug.Assert(_clients.Count > 0, "FreeClientQ - The TcsPlus result was set to true, but we have no messagees.");

		//				return GetResult(_pool);
		//			}
		//			else
		//			{
		//				//if (_waiter == null)
		//				//{
		//				//	Debug.WriteLine($"WARNING FreeClientQ - _waiter was null on timeout at {GetTime()} {opId}.");
		//				//}
		//				//_waiter = null;
		//				bool removed = _waiters.Remove(tcs);
		//				if (!removed)
		//				{
		//					Debug.WriteLine("FreeClientQ - WARNING Tcs was not removed from the LList of waiters.");
		//				}
		//				Debug.Assert(removed);
		//				if (_useDetailedDebug) Debug.WriteLine($"FreeClientQ - AAResetEvent is returning false after timeout, using the Delay Thread: {Thread.CurrentThread.ManagedThreadId} at {GetTime()}. {GetSignaledInfo(useLock: false)}. {opId}");

		//				throw new TimeoutException();
		//			}
		//		//}
		//	}
		//}

		//private T GetResult(Queue<T> clients)
		//{
		//	if (clients.Count > 0)
		//	{
		//		return clients.Dequeue();
		//	}
		//	else
		//	{
		//		return null;
		//	}
		//}

		//private TcsPlus Set()
		//{
		//	TcsPlus waiter;

		//	//lock (_stateLock)
		//	//{
		//		if (_useDetailedDebug) Debug.WriteLine($"FreeClientQ - at set: {GetSignaledInfo(useLock: false)}");

		//		//if (_waiter != null)
		//		//{
		//		//	// Signal the first task in the waiters list. This must be done on a new
		//		//	// thread to avoid stack-dives and situations where we try to complete the
		//		//	// same result multiple times.

		//		//	result = _waiter;
		//		//	result.Result = true;
		//		//	_waiter = null;
		//		//}

		//		if (_waiters.Count > 0)
		//		{
		//			// Signal the first task in the waiters list. This must be done on a new
		//			// thread to avoid stack-dives and situations where we try to complete the
		//			// same result multiple times.

		//			waiter = _waiters.First.Value;
		//			waiter.Result = true;
		//			_waiters.RemoveFirst();
		//		}
		//		else
		//		{
		//			// No tasks are pending
		//			waiter = null;

		//			//if (!_isSignaled)
		//			//{
		//			//	_isSignaled = true;
		//			//}
		//		}
		//	//}

		//	return waiter;
		//}

		//private void CompleteTcs(TcsPlus waiter)
		//{

		//	//tcs.Tcs.TrySetResult(true);

		//	try
		//	{
		//		waiter.Tcs.SetResult(true);
		//	}
		//	catch (InvalidOperationException)
		//	{
		//		throw new InvalidOperationException($"FreeClientQ wait task has already completed. SetResult failed. {waiter.OpId}");
		//	}
		//	catch (Exception e)
		//	{
		//		Debug.WriteLine($"FreeClientQ could not complete the task, received exception {e.GetType()}: {e.Message}. {waiter.OpId}");
		//	}

		//	//// TODO: Make sure that we must use a task instead of just calling TrySetResult directly.
		//	//// TODO: Make sure that we must use TrySetResult instead of SetResult.

		//	//var callingThread = Thread.CurrentThread;
		//	//Task.Factory.StartNew(s =>
		//	//{
		//	//	TcsPlus insideTcs = (TcsPlus)s;
		//	//	if (_useDetailedDebug) Debug.WriteLine($"Thread: {callingThread.ManagedThreadId} is setting the IMessage Client's AAResetEvent, using runner Thread: {Thread.CurrentThread.ManagedThreadId} and then waiting at {GetTime()}. {insideTcs.OpId}");

		//	//	bool succ = insideTcs.Tcs.TrySetResult(true);

		//	//	if (!succ) Debug.WriteLine($"Could not set the result of the TCS at {GetTime()}. {insideTcs.OpId}");
		//	//}
		//	//	, tcs, CancellationToken.None, TaskCreationOptions.PreferFairness, TaskScheduler.Default
		//	//);

		//	//// TODO: Make sure that we do not have to wait for the task to return
		//	//tcs.Task.Wait();
		//	//Debug.WriteLine($"IMessage Client's AAREvent Runner thread returned. {tcs.OpId}");
		//}

		#endregion

		private string GetSignaledInfo(bool useLock)
		{
			//if (useLock)
			//{
			//	lock (_stateLock)
			//	{
			//		return $"Signaled: {_isSignaled}, Waiters: {_waiters.Count}";
			//	}
			//}
			//else
			//{
			//	return $"Signaled: {_isSignaled}, Waiters: {_waiters.Count}";
			//}

			return $"Waiters: {_waiters.Count} -- {useLock}";
		}

		private string GetTime()
		{
			string t = DateTime.Now.ToString("HH:mm:ss:fff").Substring(3);
			return t;
		}

		class TcsPlus
		{
			public TaskCompletionSource<bool> Tcs;
			public bool? Result { get; set; }
			public T Client { get; set; }

			public string OpId { get; }

			public Task<bool> Task => Tcs.Task;

			public TcsPlus(string opId)
			{
				Tcs = new TaskCompletionSource<bool>(TaskCreationOptions.RunContinuationsAsynchronously);
				Result = null;
				Client = null;
				OpId = opId;
			}
		}

		#endregion
	}
}
