﻿using GatewayLib.Tcp;
using System;
using System.Threading.Tasks;

namespace GatewayLib.ClientPool
{
	public interface IClientPool<T> : IDisposable where T : class, IMessageClient
	{
		int InstanceId { get; }

		TimeSpan AllocateClientTimeout { get; }
		TimeSpan PollForFreeClientDuration { get; }
		TimeSpan MinimumInactivityDuration { get; }

		bool IsClosed { get; }

		T GetClient(string opId);
		Task<T> GetClientAsync(string opId);
		Task<T> GetClientAsync(T clientToRemove, string opId);

		void ReturnClient(T client);

		PoolStats GetPoolStats();
	}
}