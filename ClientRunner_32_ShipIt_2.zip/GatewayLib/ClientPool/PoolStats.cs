﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Diagnostics;

namespace GatewayLib.ClientPool
{
	public class PoolStats
	{
		public readonly DateTime SampleTime;
		public readonly int NumberAllocated;
		public readonly int NumberFree;

		public readonly int NumberCreated;
		public readonly int NumberDestroyed;

		public readonly int NumberOfRequests;
		public readonly int NumberOfHits;
		public readonly int NumberOfReturnsRequested;

		public readonly int NumberOfDiscards;
		public readonly int NumberOfPoolAdds;

		public readonly int ClientsSumOfProvidedCount;
		public readonly int ClientsSumOfFreedCount;

		public readonly bool IsDiff;
		public readonly TimeSpan SampleDuration;

		public int NumberOfFailedRequests => NumberOfRequests - NumberOfHits;
		public int NumberOfActualReturns => NumberOfReturnsRequested - NumberOfDiscards;

		public string RequestsSF => $"{NumberOfHits}/{NumberOfFailedRequests}";
		public string ReturnsSF => $"{NumberOfActualReturns}/{NumberOfDiscards}";
		public string CreatedDestroyed => $"{NumberCreated}/{NumberDestroyed}";

		public PoolStats(int numberAllocated, int numberFree,
			int numberCreated, int numberDestroyed,
			int numberOfRequests, int numberOfHits,
			int numberOfReturns, int numberOfDiscards,
			int numberOfPoolAdds,
			int clientsSumOfProvidedCount, int clientsSumOfFreedCount)
		{
			NumberAllocated = numberAllocated;
			NumberFree = numberFree;
			NumberCreated = numberCreated;
			NumberDestroyed = numberDestroyed;
			NumberOfRequests = numberOfRequests;
			NumberOfHits = numberOfHits;
			NumberOfReturnsRequested = numberOfReturns;
			NumberOfDiscards = numberOfDiscards;
			NumberOfPoolAdds = numberOfPoolAdds;

			ClientsSumOfProvidedCount = clientsSumOfProvidedCount;
			ClientsSumOfFreedCount = clientsSumOfFreedCount;

			SampleTime = DateTime.Now;
		}

		public PoolStats(DateTime sampleTime0, DateTime sampleTime1, int numberAllocated, int numberFree,
			int numberCreated, int numberDestroyed,
			int numberOfRequests, int numberOfHits,
			int numberOfReturns, int numberOfDiscards,
			int numberOfPoolAdds,
			int clientsSumOfProvidedCount, int clientsSumOfFreedCount)
		{
			NumberAllocated = numberAllocated;
			NumberFree = numberFree;
			NumberCreated = numberCreated;
			NumberDestroyed = numberDestroyed;
			NumberOfRequests = numberOfRequests;
			NumberOfHits = numberOfHits;
			NumberOfReturnsRequested = numberOfReturns;
			NumberOfDiscards = numberOfDiscards;
			NumberOfPoolAdds = numberOfPoolAdds;

			ClientsSumOfProvidedCount = clientsSumOfProvidedCount;
			ClientsSumOfFreedCount = clientsSumOfFreedCount;

			SampleTime = sampleTime0;
			SampleDuration = sampleTime1 - sampleTime0;
			IsDiff = true;

		}

		public override string ToString()
		{
			StringBuilder sb = new StringBuilder();
			if(IsDiff)
			{
				sb.Append($"PS_Diff st={FmtDate(SampleTime)}, dur={FmtDuration(SampleDuration)}, ");
				sb.Append($"a={NumberAllocated}, f={NumberFree}, c={NumberCreated}, d={NumberDestroyed}, r={NumberOfRequests}, h={NumberOfHits}, ret={NumberOfReturnsRequested}, dis={NumberOfDiscards}, padd={NumberOfPoolAdds}");
			}
			else
			{
				sb.Append($"PS st={FmtDate(SampleTime)}, ");
				sb.Append($"a={NumberAllocated}, f={NumberFree}, c={NumberCreated}, d={NumberDestroyed}, r={NumberOfRequests}, h={NumberOfHits}, ret={NumberOfReturnsRequested}, dis={NumberOfDiscards}, padd={NumberOfPoolAdds}");
			}

			return sb.ToString();
		}

		private string FmtDate(DateTime dt)
		{
			return dt.ToString("mm:ss:fff");
		}
		private string FmtDuration(TimeSpan ts)
		{
			return ts.TotalSeconds.ToString();
		}
	}

	public class PoolStatPair
	{
		public readonly PoolStats T0;
		public readonly PoolStats Df;

		public PoolStatPair(PoolStats t0, PoolStats t1)
		{
			T0 = t0;
			Df = PoolStatHelper.GetDiffPoolStats(t0, t1);
		}
		
		public override string ToString()
		{
			StringBuilder sb = new StringBuilder();
			sb.Append($"PS_Diff st={FmtDate(Df.SampleTime)}, dur={FmtDuration(Df.SampleDuration)}, ");
			sb.Append($"a={FmtVal(T0.NumberAllocated, Df.NumberAllocated)}, f={FmtVal(T0.NumberFree, Df.NumberFree)}, c={FmtVal(T0.NumberCreated, Df.NumberCreated)}, ");
			sb.Append($"d={FmtVal(T0.NumberDestroyed, Df.NumberDestroyed)}, r={FmtVal(T0.NumberOfRequests, Df.NumberOfRequests)}, h={FmtVal(T0.NumberOfHits, Df.NumberOfHits)}, ");
			sb.Append($"ret={FmtVal(T0.NumberOfReturnsRequested, Df.NumberOfReturnsRequested)}, dis={FmtVal(T0.NumberOfDiscards, Df.NumberOfDiscards)}, padd={FmtVal(T0.NumberOfPoolAdds, Df.NumberOfPoolAdds)}");

			return sb.ToString();
		}

		private string FmtVal(int t0, int df)
		{
			if(df == 0)
			{
				return t0.ToString();
			}
			if(df > 0)
			{
				return $"{t0}+{df}={t0 + df}";
			}
			else
			{
				return $"{t0}{df}={t0 + df}";
			}
		}

		private string FmtDate(DateTime dt)
		{
			return dt.ToString("mm:ss:fff");
		}
		private string FmtDuration(TimeSpan ts)
		{
			if(ts.TotalSeconds < 0.005)
			{
				return ts.TotalMilliseconds.ToString() + "ms";
			}
			else
			{
				return ts.TotalSeconds.ToString();
			}
		}
	}

	public class PoolStatHelper
	{
		public static PoolStats GetPoolStats(int numberAllocated, int numberFree,
			int numberCreated, int numberDestroyed,
			int numberOfRequests, int numberOfHits,
			int numberOfReturns, int numberOfDiscards,
			int numberOfPoolAdds,
			IList<IPooledClient> pooledClients)
		{
			int pc = pooledClients?.Count ?? 0;
			bool allocationCntsMatch = (numberAllocated == pc); 
			if(!allocationCntsMatch)
			{
				Debug.WriteLine($"Allocation Counts dont match from PoolStatsHelper.GetPoolStats. a={numberAllocated}, pc={pc}");
			}

			PoolStats result = new PoolStats(
				numberAllocated, numberFree, numberCreated, numberDestroyed, numberOfRequests, numberOfHits, numberOfReturns, numberOfDiscards, numberOfPoolAdds,
				pooledClients?.Sum(x => x.ProvidedCount) ?? 0,
				pooledClients?.Sum(x => x.FreedCount) ?? 0);

			return result;
		}

		public static PoolStats GetDiffPoolStats(PoolStats t0, PoolStats t1)
		{
			PoolStats result = new PoolStats(
				t0.SampleTime,
				t1.SampleTime,
				t1.NumberAllocated - t0.NumberAllocated,
				t1.NumberFree - t0.NumberFree,
				t1.NumberCreated - t0.NumberCreated,
				t1.NumberDestroyed - t0.NumberDestroyed,
				t1.NumberOfRequests - t0.NumberOfRequests,
				t1.NumberOfHits - t0.NumberOfHits,
				t1.NumberOfReturnsRequested - t0.NumberOfReturnsRequested,
				t1.NumberOfDiscards - t0.NumberOfDiscards,
				t1.NumberOfPoolAdds - t0.NumberOfPoolAdds,
				t1.ClientsSumOfProvidedCount - t0.ClientsSumOfProvidedCount,
				t1.ClientsSumOfFreedCount - t0.ClientsSumOfFreedCount
				);

			return result;
		}



	}
}
