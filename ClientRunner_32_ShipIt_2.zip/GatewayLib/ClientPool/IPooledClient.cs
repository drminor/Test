﻿using System;

namespace GatewayLib.ClientPool
{
	public interface IPooledClient : IDisposable
	{
		string Identifier { get; }

		bool IsConnected { get; }
		bool IsClosed { get; }

		bool IsInitialized { get; }
		bool IsServicingCall { get; }

		void Close();

		DateTime CreatedDate { get; }
		DateTime LastFreedDate { get; set; }
		DateTime LastProvidedDate { get; set; }
		DateTime LastUsedDate { get; set; }

		int ProvidedCount { get; set; }
		int FreedCount { get; set; }
	}
}
