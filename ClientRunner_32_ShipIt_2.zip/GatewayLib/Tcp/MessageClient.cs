﻿using GatewayLib.ClientPool;
using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.IO;
using System.Linq;
using System.Net;
using System.Net.Security;
using System.Net.Sockets;
using System.Security.Authentication;
using System.Security.Cryptography.X509Certificates;
using System.Threading;
using System.Threading.Tasks;
using TcpProtocolLib;

namespace GatewayLib.Tcp
{
	public delegate IMessageClient CreateMessageClient(IPEndPoint endpoint, IMessageEncoder messageEncoder, TimeSpan messageResponseTimeout, CertInfo certInfo);

	public class MessageClient : PooledClientBase, IMessageClient
	{
		private const int BUFFER_SIZE = 1024;
		private const int MAX_MESSAGE_SIZE = 0; // No Maximum.
		private const string DEFAULT_ID = "new client";

		private readonly TcpClient _tcpClient;
		private readonly IMessageEncoder _messageEncoder;
		private readonly CertInfo _certInfo;
		private SslStream _stream;

		private ReceivedMessagesQueue _receivedMessagesQueue;

		private readonly Task _initializeTask;
		private Task<ReadBufferResult> _messagesReceiverTask;

		private readonly object _stateLock = new object();
		private readonly object _isServicingCallLock = new object();
		private bool _isServicingCall = false;

		private readonly bool _useDetailedDebug = false;

		public MessageClient(IPEndPoint endPoint, IMessageEncoder messageEncoder, TimeSpan messageResponseTimeout, CertInfo certInfo)
		{
			_identifier = DEFAULT_ID;
			_messageEncoder = messageEncoder;
			ResponseTimeout = messageResponseTimeout;
			_certInfo = certInfo;

			_tcpClient = new TcpClient
			{
				ReceiveBufferSize = BUFFER_SIZE,
				SendBufferSize = BUFFER_SIZE
			};
			
			_receivedMessagesQueue = null;
			_initializeTask = Initialize(endPoint);
		}

		public static CreateMessageClient MessageClientCreator => (IPEndPoint endPoint, IMessageEncoder messageEncoder, TimeSpan messageResponseTimeout, CertInfo certInfo)
			=> new MessageClient(endPoint, messageEncoder, messageResponseTimeout, certInfo);

		#region Initialize and Continously Read

		private async Task Initialize(IPEndPoint endpoint)
		{
			//_cert = ClientCertHelper.GetCert(_certInfo);

			try
			{
				await _tcpClient.ConnectAsync(endpoint.Address, endpoint.Port);

				_stream = GetSslStream(_tcpClient, _certInfo);
				SetIdentifier();

				_receivedMessagesQueue = new ReceivedMessagesQueue();
				_messagesReceiverTask = ReceiveMessagesAsync(_stream);
			}
			catch (ObjectDisposedException)
			{
				Debug.WriteLine($"Received ObjectDisposedException while MessageClient trying to connect.");
				throw new SendRequestException("TcpClient is disposed while connecting.", SendRequestOperation.Connect, SendRequestError.ClientIsDisposed);
			}
			catch (SocketException se)
			{
				throw new SendRequestException("Could Not Connect", SendRequestOperation.Connect, se);
			}
			catch (System.IO.IOException ie)
			{
				throw new SendRequestException("Could Not Connect", SendRequestOperation.Connect, ie);
			}
			catch (Exception e)
			{
				Debug.WriteLine($"Received system exception: {e.Message} while MessageClient trying to connect. Re-Throwing Exception");
				throw new SendRequestException("Could Not Connect", SendRequestOperation.Connect, e);
			}
		}

		private SslStream GetSslStream(TcpClient client, CertInfo certInfo)
		{
			var clientCertificateCollection = new X509CertificateCollection(new X509Certificate[] { certInfo.OurPrivateCert });

			// TODO: Use GetNameInfo
			string targetName = certInfo.PeersPublicCert.Subject.Substring(3);

			var sslStream = new SslStream(client.GetStream(), false, CertHelper.ValidateRemoteCert, CertHelper.SelectLocalCertificate);
			sslStream.AuthenticateAsClient(targetName, clientCertificateCollection, SslProtocols.None, false);

			return sslStream;
		}

		private async Task<ReadBufferResult> ReceiveMessagesAsync(SslStream stream)
		{
			Packetizer packetizer = new Packetizer(MAX_MESSAGE_SIZE, _messageEncoder);
			byte[] myReadBuffer = new byte[BUFFER_SIZE];

			ReadBufferResult result;

			try
			{
				do
				{
					result = await ReadBufAsync(myReadBuffer, stream);
					if (result.BytesRead > 0)
					{
						IEnumerable<string> messages = packetizer.PushData(myReadBuffer, result.BytesRead);
						foreach(string s in messages)
						{
							if(s != null)
							{
								MessageWithTimestamp mwts = new MessageWithTimestamp(s);
								_receivedMessagesQueue.Enqueue(mwts);
							}
						}
					}
					else if(result.Exception != null && !ShouldStop(result.Exception))
					{
						// Post the exception and continue.
						MessageWithTimestamp mwts = new MessageWithTimestamp(result.Exception);
						_receivedMessagesQueue.Enqueue(mwts);
					}
				}
				while (result.BytesRead != 0 && !ShouldStop(result.Exception));

				// Do not close, it's our caller's responsibility to recognize that this Message Client's TcpClient has been closed
				// and to then close this Message Client instance.
				// By not closing, it gives our caller the ability to access the properties of this Message Client to get more info.
				//Close();

				if (_useDetailedDebug) Debug.WriteLine("A MessageClient's messageReceiverTask is stopping.");

				return result;
			}
			catch (Exception e)
			{
				// This should never happen.
				Debug.WriteLine($"A MessageClient's messagesReceiverTask encountered exception {e.GetType()}: {e.Message}");
				return new ReadBufferResult(new SendRequestException(SendRequestOperation.Read, e));
			}
		}

		private bool ShouldStop(Exception e)
		{
			if (e == null) return false;
			if (e is SendRequestException sre && sre.ErrorCode == SendRequestError.ClientIsDisposed) return true;
			if (e?.InnerException is IOException ioe && ioe?.InnerException is SocketException se && se.SocketErrorCode == SocketError.ConnectionReset) return true;
			return false ;
		}

		private async Task<ReadBufferResult> ReadBufAsync(byte[] myReadBuffer, SslStream stream)
		{
			try
			{
				int bytesRead = await stream.ReadAsync(myReadBuffer, 0, myReadBuffer.Length);
				return new ReadBufferResult(bytesRead);
			}
			catch (ObjectDisposedException)
			{
				if(_useDetailedDebug) Debug.WriteLine($"Received ObjectDisposedException while MessageClient trying to read.");
				return new ReadBufferResult(new SendRequestException("TcpClient is disposed while reading.", SendRequestOperation.Read, SendRequestError.ClientIsDisposed));
			}
			catch (SocketException se)
			{
				return new ReadBufferResult(new SendRequestException(SendRequestOperation.Read, se));
			}
			catch (IOException ie)
			{
				return new ReadBufferResult(new SendRequestException(SendRequestOperation.Read, ie));
			}
			catch (Exception e)
			{
				Debug.WriteLine($"Received system exception {e.GetType()}: {e.Message} while the MessageClient is trying to read from the stream.");
				return new ReadBufferResult(new SendRequestException("SystemException on Read, see inner exception for details", SendRequestOperation.Read, e));
			}
		}

		#endregion

		public string SendAndReadResponse(string message, string correlationId, CorrelationIdInfo correlationIdInfo, string opId)
		{
			string response = Task.Run(() => SendAndReadResponseAsync(message, correlationId, correlationIdInfo, opId)).GetAwaiter().GetResult();
			return response;
		}

		public async Task<string> SendAndReadResponseAsync(string message, string correlationId, CorrelationIdInfo correlationIdInfo, string opId)
		{
			if (!AquireIsServicingCallFlag())
			{
				throw new InvalidOperationException($"{nameof(SendAndReadResponseAsync)} is not re-entrant.");
			}

			LastUsedDate = DateTime.Now;

			MessageWithTimestamp.RefTicks = DateTime.Now.Ticks; // Reset the reference ticks value for use by the MessageWithTimestamp.ToString method.
			if(_useDetailedDebug) Debug.WriteLine($"SendAndReadResponseAsync was given a message to send with CorrelationId {correlationId}. {opId}");

			try
			{
				await _initializeTask;

				CheckReaderTask(_messagesReceiverTask, opId);
				CheckReceivedMessages(_receivedMessagesQueue, opId);

				byte[] packet = _messageEncoder.CreatePacket(message);

				//Debug.WriteLine($"{opId}: SendAndReadResponseAsync is sending {packet.Length} bytes asynchronously.");
				await WriteAsync(_stream, packet);

				string result = await ReadResponse(ResponseTimeout, _receivedMessagesQueue, _messagesReceiverTask, correlationId, correlationIdInfo, opId);
				if (_useDetailedDebug) Debug.WriteLine($"SendAndReadResponseAsync is returning a response, using {ThreadAndTime()}. {opId}: ");
				
				return result;
			}
			finally
			{
				bool weOwnedAndNowHaveReleasedTheServicingCallFlag = ReleaseIsServicingCallFlag();
				Debug.Assert(weOwnedAndNowHaveReleasedTheServicingCallFlag, $"The message client did not own, or could not release, the ServicingCallFlag upon exit of SendAndReadResponseAsync. {opId}");
			}
		}

		private async Task<string> ReadResponse(TimeSpan timeout, ReceivedMessagesQueue receivedMessagesQueue, Task<ReadBufferResult> messagesReceiverTask,
			string correlationId, CorrelationIdInfo correlationIdInfo, string opId)
		{
			Task<bool> receiveResponseTask = null;

			try
			{
				receiveResponseTask = receivedMessagesQueue.WaitForMessage(timeout, correlationId, correlationIdInfo, opId);
				string response = await Task.Factory.ContinueWhenAny(new Task[] { receiveResponseTask, messagesReceiverTask }, (completedTask) =>
				{
					if (completedTask == receiveResponseTask)
					{
						//if (_useDetailedDebug) Debug.WriteLine($"ReadResponse is finished waiting, winner = receiveResponse, using {ThreadAndTime()}. {opId}");
						return HandleReceiveResponseTask(receiveResponseTask, receivedMessagesQueue, opId);
					}
					else
					{
						if (_useDetailedDebug) Debug.WriteLine($"ReadResponse is finished waiting, winner = readerTask, using {ThreadAndTime()}. {opId}");
						return HandleReaderTask(messagesReceiverTask, opId);
					}
				});

				Debug.Assert(response != null, "If we are here, the response should be non-null.");
				return response;
			}
			catch (SendRequestException)
			{
				// Simply pass on the exeception already thrown.
				//if(_useDetailedDebug)	Debug.WriteLine($"WARNINIG: {opId}: ReadResponse is throwing an exception: {sre}.");
				throw;
			}
			catch (Exception e)
			{
				// An unhandled exception occured in either the receiveResponseTask or messagesReceiverTask task.

				Debug.WriteLine($" WARNING: {opId}: Got {e.GetType()}: {e.Message} after waiting for the receiveResponseTask or messagesReceiverTask task.");
				if (receiveResponseTask?.IsFaulted == true)
				{
					Debug.WriteLine($"WARNING: {opId}: AutoResetEvent faulted.");
					throw new SendRequestException("The receiveResponseTask failed.", SendRequestOperation.Read, receiveResponseTask.Exception);
				}
				else if (messagesReceiverTask.IsFaulted)
				{
					Debug.WriteLine($"WARNING: {opId}: Background ReceiveMessagesAsync Task faulted.");
					throw new SendRequestException("Background ReceiveAsync Thread faulted.", SendRequestOperation.Read, messagesReceiverTask.Exception);
				}
				else
				{
					Debug.WriteLine($"WARNING: {opId}: Neither the receiveResponseTask nor the ReceiveMessagesAsync was faulted.");
					throw new SendRequestException("ReadRespone method got an exception but neither the receiveResponseTask nor the messagesReceiverTask was faulted, the .", SendRequestOperation.Read, e);
				}
			}
		}

		private string HandleReceiveResponseTask(Task<bool> receiveResponseTask, ReceivedMessagesQueue receivedMessagesQueue, string opId)
		{
			bool responseReceived = receiveResponseTask.Result;
			if (responseReceived)
			{
				return GetMessage(receivedMessagesQueue, opId);
			}
			else
			{
				string errorMessage = $"No response was received within {ResponseTimeout.TotalMilliseconds} milliseconds. {opId}";
				Debug.WriteLine(errorMessage);
				throw new SendRequestException(errorMessage, SendRequestOperation.Read, SendRequestError.Timeout);
			}
		}

		// Returns the messsage matching the CorrelationId,
		// If more than one message has been received when the match is found or an execption is found
		// then all of the messages / exceptions are collected and used to throw a TooManyMessagesFound exception.
		private string GetMessage(ReceivedMessagesQueue receivedMessagesQueue, string opId)
		{
			IList<MessageWithTimestamp> messages = receivedMessagesQueue.DequeueAll();

			if (messages == null)
			{
				Debug.WriteLine($"WARNNG: No entry in the list of ReceivedMessages with a Message or an Exception. {opId}");
				if (_useDetailedDebug) Debug.WriteLine($"The received messages are null.");
				throw new SendRequestException("No entry in the list of ReceivedMessages was found with either a Message or an Exception.", SendRequestOperation.Read, SendRequestError.Other);
			}
			else
			{
				if (_useDetailedDebug) Debug.WriteLine($"The received messages are {string.Join("|", messages.Select(x => x.ToString()))}. {opId}");

				if (messages.Count() > 1 || messages.Where(x => x.IsException).Count() > 0)
				{
					Debug.WriteLine("GetMessage is throwing an SRE with ErroCode = TooManyMessagesReceived due to exception. {opId}");
					CollectMessagesAndThrow(messages, SendRequestOperation.Read);
				}

				return messages.First().Message;
			}
		}

		private string HandleReaderTask(Task<ReadBufferResult> readerTask, string opId)
		{
			if(readerTask.Result.BytesRead == 0)
			{
				Debug.WriteLine($"HandleReaderTask is returning an exception because the messagesReceiverTask is completed -- PeerClosedTheConnection. {opId}"); 
				throw new SendRequestException("The MessageClient was closed by the peer before any response was received.", SendRequestOperation.Read, SendRequestError.PeerClosedTheConnection);
			}
			else
			{
				if(readerTask.Result.Exception.ErrorCode == SendRequestError.ClientIsDisposed)
				{
					Debug.WriteLine($"HandleReaderTask is returning an exception because the messagesReceiverTask is cancelled. {opId}");
					throw new SendRequestException("The MessageClient was cancelled before any response was received.", SendRequestOperation.Read, SendRequestError.OperationCancelled);
				}
				else
				{
					// This should never happen.
					Debug.WriteLine($"HandleReaderTask is returning the reader task's exception because the messagesReceiverTask completed with an unexpected error. {opId}");
					throw new SendRequestException("The MessageClient's messagesReceiverTask has stopped. The InnerException is the exception thrown.", 
						SendRequestOperation.Read, SendRequestError.Other, readerTask.Result.Exception);
				}
			}
		}

		private void CheckReaderTask(Task<ReadBufferResult> readerTask, string opId)
		{
			if (!readerTask.IsCompleted) return;

			if (readerTask.Result.BytesRead == 0)
			{
				Debug.WriteLine($"CheckReaderTask is returning an exception because the messagesReceiverTask is completed -- PeerClosedTheConnection. {opId}");
				throw new SendRequestException("The MessageClient has been closed by the peer.", SendRequestOperation.PreWrite, SendRequestError.PeerClosedTheConnection);
			}
			else
			{
				if (readerTask.Result.Exception.ErrorCode == SendRequestError.ClientIsDisposed)
				{
					Debug.WriteLine($"CheckReaderTask is returning an exception because the messagesReceiverTask is cancelled. {opId}");
					throw new SendRequestException("The MessageClient has been cancelled.", SendRequestOperation.PreWrite, SendRequestError.OperationCancelled);
				}
				else
				{
					// This should never happen.
					Debug.WriteLine($"CheckReaderTask is returning the reader task's exception because the messagesReceiverTask completed with an unexpected error. {opId}");
					throw new SendRequestException("The MessageClient's messagesReceiverTask has stopped. The InnerException is the exception thrown.",
						SendRequestOperation.PreWrite, SendRequestError.Other, readerTask.Result.Exception);
				}
			}
		}

		private void CheckReceivedMessages(ReceivedMessagesQueue receivedMessagesQueue, string opId)
		{
			IEnumerable<MessageWithTimestamp> messages = receivedMessagesQueue.DequeueAll();

			if (messages != null)
			{
				Debug.WriteLine($"CheckReceivedMessages in throwing an SRE with ErrorCode = TooManyMessagesReceived {opId}");
				if (_useDetailedDebug) Debug.WriteLine($"The received messages are {string.Join("|", messages.Select(x => x.ToString()))}. {opId}");
				CollectMessagesAndThrow(messages, SendRequestOperation.PreWrite);
			}
		}

		private void CollectMessagesAndThrow(IEnumerable<MessageWithTimestamp> messages, SendRequestOperation operation)
		{
			string errorMessage = "One or more messages or exceptions were received from previous operation(s). " +
				"The list of messages / exceptions are contained in the InnerException's InnerExceptions property. " +
				"Make sure to cast the InnerException as an AggregateException.";

			IEnumerable<Exception> exceptions = ConvertMessages(messages);
			string aeErrorMessage = operation == SendRequestOperation.PreWrite
				? "List of Messages and Exceptions present prior to sending"
				: "List of Messages and Exceptions found during read";

			AggregateException ae = new AggregateException(aeErrorMessage, exceptions);
			throw new SendRequestException(errorMessage, operation, SendRequestError.TooManyMessagesReceived, ae);
		}

		private IEnumerable<Exception> ConvertMessages(IEnumerable<MessageWithTimestamp> messages)
		{
			return messages.Select<MessageWithTimestamp, Exception>(x =>
			{
				if (x.IsMessage)
				{
					return new UnexpectedMessageReceivedException(x.Message, x.Timestamp);
				}
				else
				{
					return x.Exception;
				}
			}
			);
		}

		private async Task WriteAsync(SslStream stream, byte[] packet)
		{
			try
			{
				//NetworkStream stream = client.GetStream();
				await stream.WriteAsync(packet, 0, packet.Length);
			}
			catch (ObjectDisposedException)
			{
				Debug.WriteLine($"Received Object Dispose Exception while MessageClient trying to send request.");
				throw new SendRequestException("Could not write", SendRequestOperation.Write, SendRequestError.ClientIsDisposed);
			}
			catch (SocketException se)
			{
				throw new SendRequestException("Could Not Write", SendRequestOperation.Connect, se);
			}
			catch (System.IO.IOException ie)
			{
				throw new SendRequestException("Could Not Write", SendRequestOperation.Connect, ie);
			}
			catch (Exception e)
			{
				Debug.WriteLine($"Received system exception: {e.Message} while MessageClient trying to send request. Re-Throwing Exception");
				throw new SendRequestException("Could Not Write", SendRequestOperation.Connect, e);
			}
		}

		private string ThreadAndTime()
		{
			string t = DateTime.Now.ToString("HH:mm:ss:fff").Substring(3);
			return $"{Thread.CurrentThread.ManagedThreadId} at {t}";
		}

		private bool AquireIsServicingCallFlag()
		{
			// TODO: Use Threading.Interlocked
			lock (_isServicingCallLock)
			{
				if (_isServicingCall)
				{
					// We are currently servicing a call, return false.
					return false;
				}
				else
				{
					// Currently not servicing, mark as servicing and return success
					_isServicingCall = true;
					return true;
				}
			}
		}

		private bool ReleaseIsServicingCallFlag()
		{
			// TODO: Use Threading.Interlocked
			lock (_isServicingCallLock)
			{
				if (_isServicingCall)
				{
					// We are currently servicing a call, return false.
					_isServicingCall = false;
					return true;
				}
				else
				{
					// Currently not servicing, mark as servicing and return success
					return false;
				}
			}
		}

		public override void Close()
		{
			lock (_stateLock)
			{
				if (!_isClosed)
				{
					_tcpClient.Close(); 
					// Note: Not disposing the tasks. see https://stackoverflow.com/questions/3734280/is-it-considered-acceptable-to-not-call-dispose-on-a-tpl-task-object

					if (_stream != null) _stream.Dispose();
					_isClosed = true;
				}
			}
		}

		#region Public Properties

		private string _identifier = null;
		public override string Identifier => _identifier;
		//public override string Identifier
		//{
		//	get
		//	{
		//		if (_identifier == DEFAULT_ID)
		//		{
		//			SetIdentifier();
		//		}
		//		return _identifier;
		//	}
		//}

		private void SetIdentifier()
		{
			try
			{
				IPEndPoint locEp = _tcpClient?.Client?.LocalEndPoint as IPEndPoint;
				_identifier = locEp?.Port.ToString() ?? "ep:unknown";

				Debug.WriteLine($"The new socket is at localEndPoint: {locEp.Port}.");
			}
			catch
			{
				_identifier = "ep:fault";
			}
		}

		public TimeSpan ResponseTimeout { get; set; }

		public override bool IsConnected
		{
			get
			{
				lock (_stateLock)
				{
					bool result;
					if(!_initializeTask.IsCompleted)
					{
						// Waiting for connect operation to complete
						result = true;
					}
					else
					{
						if (_isClosed)
						{
							Debug.WriteLine($"MessageClient: {Identifier} was found to be disposed when accessing its IsConnected property.");
							result = false;
						}
						else
						{
							result = _tcpClient.Connected;
						}
					}

					return result;
				}
			}
		}

		public override bool IsInitialized
		{
			get
			{
				lock (_stateLock)
				{
					return _initializeTask.IsCompleted;
				}
			}
		}

		private bool _isClosed;
		public override bool IsClosed
		{
			get
			{
				lock (_stateLock)
				{
					return _isClosed;
				}
			}
		}

		public override bool IsServicingCall
		{
			get
			{
				// TODO: Consider using Interlocked instead of a standard lock.
				lock (_isServicingCallLock)
				{
					return _isServicingCall;
				}
			}
		}

		#endregion
	}
}
