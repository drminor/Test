﻿using GatewayLib.ClientPool;
using GatewayLib.Tcp;
using System;
using System.Diagnostics;
using System.Linq;
using System.Net.Sockets;
using System.Threading.Tasks;
using TcpProtocolLib;

namespace GatewayLib.Gateway
{
	public delegate IManagedClient CreateManagedClient<T>(IClientPool<T> pool, T client, int managedClientId) where T : class, IMessageClient;

	public class ManagedClient<T> : IManagedClient, IDisposable where T : class, IMessageClient, IPooledClient, IDisposable
	{
		private  IClientPool<T> _clientPool;
		private T _messageClient;
		private readonly bool _useDetailedDebug = false;

		public ManagedClient(IClientPool<T> clientPool, T messageClient, int managedClientId)
		{
			_clientPool = clientPool;
			_messageClient = messageClient;
			Id = managedClientId;
		}

		public static CreateManagedClient<T> ManagedClientCreator => (IClientPool<T> clientPool, T messageClient, int managedClientId) => new ManagedClient<T>(clientPool, messageClient, managedClientId);

		public int Id { get; }
		public string MessageClientIdentifier => _messageClient?.Identifier;

		public string SendAndReadResponse(string message, string correlationId, CorrelationIdInfo correlationIdInfo)
		{
			string result = Task.Run(() => SendAndReadResponseAsync(message, correlationId, correlationIdInfo)).GetAwaiter().GetResult();
			return result;
		}

		public async Task<string> SendAndReadResponseAsync(string message, string correlationId, CorrelationIdInfo correlationIdInfo)
		{
			string opId;
			OperationStatus opStatus = new OperationStatus();
			string response = null;

			if (_messageClient == null)
			{
				opId = MessageHelper.GetOpId();
				try
				{
					_messageClient = await GetClientFromPool(null, opId);
					opId = MessageHelper.GetOpId(opId, _clientPool.InstanceId, Id, _messageClient.Identifier);
				}
				catch
				{
					Debug.WriteLine($"Timed out while getting a client from the pool, SendRequest failed before calling _messageClient.SendAndReadResponse.");
					throw;
				}
			}
			else
			{
				opId = MessageHelper.GetOpId(_clientPool.InstanceId, Id, _messageClient.Identifier);
			}

			do
			{
				try
				{
					response = await _messageClient.SendAndReadResponseAsync(message, correlationId, correlationIdInfo, opId);
					opStatus.Succeeded = true;
				}
				catch (SendRequestException sre)
				{
					opStatus = ErrorHandler(sre, opStatus, correlationId, correlationIdInfo, opId);
				}
				catch (Exception e)
				{
					Debug.WriteLine($"Received exception: {e.Message} from SendAndReadResponse. {opId}");
					opStatus.ErrorMessage = "Could not complete SendAndReadResponse";
					opStatus.Exception = e;
					opStatus.ShouldRetry = false;
				}

				if (opStatus.NeedNewClient)
				{
					Debug.WriteLine($"Error Handler says WE NEED A NEW CLIENT, reason: {opStatus.ErrorMessage}, retrying. RetryCount = {opStatus.RetryCount}. {opId}");

					try
					{
						_messageClient = await GetClientFromPool(_messageClient, opId);
						opId = MessageHelper.GetOpId(opId, _clientPool.InstanceId, Id, _messageClient.Identifier);
						opStatus.IsClientUsable = true;
					}
					catch
					{
						_messageClient = null;
						Debug.WriteLine($"Timed out while getting a client from the pool, SendRequest failed while getting a new client during retry attempt number: {opStatus.RetryCount}. {opId}");
						throw;
					}
				}

				if(!opStatus.Succeeded && opStatus.ShouldRetry && opStatus.RetryCount < 3)
				{
					Debug.WriteLine($"Retrying, reason: {opStatus.ErrorMessage}. RetryCount = {opStatus.RetryCount}. {opId}");
				}
			}
			while (!opStatus.Succeeded && opStatus.ShouldRetry && opStatus.RetryCount < 3);

			if (opStatus.Succeeded)
			{
				if (_useDetailedDebug) Debug.WriteLine($"ManagedClient succeeded. RetryCount = {opStatus.RetryCount}. {opId}.");
				return response;
			}
			else
			{
				Debug.WriteLine($"Here at opStatus.ShouldRetry = false; IsClientUsable = {opStatus.IsClientUsable}; errorMessage = {opStatus.ErrorMessage}; Exception is {opStatus.Exception}. {opId}");

				if (!opStatus.IsClientUsable)
				{
					try
					{
						_clientPool.ReturnClient(_messageClient);
					}
					finally
					{
						_messageClient = null;
					}
				}

				throw new GatewayException(opStatus.ErrorMessage, GatewayOperationEnum.SendAndReadResponse, opStatus.Exception);
			}
		}

		private OperationStatus ErrorHandler(SendRequestException sre, OperationStatus previousStatus, string correlationId, CorrelationIdInfo correlationIdInfo, string opId)
		{
			OperationStatus newStat = new OperationStatus(sre)
			{
				RetryCount = previousStatus.RetryCount + 1,
				ShouldRetry = false,
				IsClientUsable = false
			};

			switch (sre.Operation)
			{
				case SendRequestOperation.Connect:
					{
						switch (sre.ErrorCode)
						{
							case SendRequestError.SocketException:
								{
									switch (sre.SocketErrorCode)
									{
										case SocketError.ConnectionRefused:
											{
												newStat.ErrorMessage = "Server actively refused connection.";
												newStat.IsClientUsable = false;
												newStat.ShouldRetry = true;
												break;
											}
										case SocketError.TimedOut:
											{
												newStat.ErrorMessage = "Got NS-Timeout exc out while reading from TcpClient.";
												newStat.IsClientUsable = true;
												newStat.ShouldRetry = true;
												break;
											}
									}
									break;
								}
						}
						break;
					}

				case SendRequestOperation.PreWrite:
					{
						switch (sre.ErrorCode)
						{
							case SendRequestError.PeerClosedTheConnection:
								{
									newStat.RetryCount--; // Don't count connections closed by the peer as re-tries.
									newStat.ErrorMessage = "TcpConnection was found to be closed by the peer on pre-write.";
									newStat.ShouldRetry = true;
									break;
								}
							case SendRequestError.TooManyMessagesReceived:
								{
									if (sre.InnerException is AggregateException ae)
									{
										Exception e1 = ae.InnerExceptions.Where(x => !(x is UnexpectedMessageReceivedException)).FirstOrDefault();
										if(e1 != null)
										{
											Debug.WriteLine($"WARNING: Unhandled exceptions on Prewrite. {opId}");
											newStat.ErrorMessage = "Before sending, there were unhandled exceptions from a previous SendAndReadResponse operation.";
											newStat.Exception = e1;
										}
										else
										{
											foreach(UnexpectedMessageReceivedException umre in ae.InnerExceptions)
											{
												if(MessageHelper.DoesResponseHaveExpectedCorId(umre.ReceivedMessage, correlationId, correlationIdInfo))
												{
													newStat.ErrorMessage = "On PreWrite, message found from previous send operation that timed-out.";
													newStat.TestResponse = umre.ReceivedMessage;
													newStat.Succeeded = true;
													newStat.IsClientUsable = true;
													newStat.ShouldRetry = false;
												}
											}

											if(!newStat.Succeeded)
											{
												newStat.ErrorMessage = "On PreWrite, message(s) found from previous send operation that timed-out but none match.";
												newStat.IsClientUsable = true;
												newStat.ShouldRetry = true;
											}
										}
									}
									else
									{
										Debug.WriteLine($"WARNING: On PreWrite, Exception is TooManyMessagesReceived, but InnerException is not aggregate. {opId}");
									}

									break;
								}
						}
						break;
					}

				case SendRequestOperation.Write:
					{
						switch (sre.ErrorCode)
						{
							case SendRequestError.ClientIsDisposed:
								{
									newStat.ErrorMessage = "TcpConnection is found to be closed on write.";
									newStat.ShouldRetry = true;
									break;
								}
							case SendRequestError.Timeout:
								{
									newStat.ErrorMessage = "Got SendRequestError Timeout exception while writing to TcpClient.";
									newStat.IsClientUsable = true;
									newStat.ShouldRetry = true;
									break;
								}
							case SendRequestError.SocketException:
								switch (sre.SocketErrorCode)
								{
									case SocketError.TimedOut:
										{
											newStat.ErrorMessage = "Got NS-Timeout exc out while writing to TcpClient.";
											newStat.IsClientUsable = true;
											newStat.ShouldRetry = true;
											break;
										}
								}
								break;
						}
						break;
					}

				case SendRequestOperation.Read:
					{
						switch (sre.ErrorCode)
						{
							case SendRequestError.ClientIsDisposed:
								{
									newStat.ErrorMessage = "TcpConnection is found to be closed on read.";
									newStat.ShouldRetry = true;
									break;
								}
							case SendRequestError.PeerClosedTheConnection:
								{
									newStat.RetryCount--; // Don't count connections closed by the peer as re-tries.
									newStat.ErrorMessage = "TcpConnection was found to be closed by the peer on read.";
									newStat.ShouldRetry = true;
									break;
								}
							case SendRequestError.Timeout:
								{
									newStat.ErrorMessage = "Got SendRequestError Timeout exception while reading from TcpClient.";
									newStat.IsClientUsable = true;
									newStat.ShouldRetry = true;
									break;
								}
							case SendRequestError.SocketException:
								{
									switch (sre.SocketErrorCode)
									{
										case SocketError.TimedOut:
											{
												newStat.ErrorMessage = "Got NS-Timeout exc out while reading from TcpClient.";
												newStat.IsClientUsable = true;
												newStat.ShouldRetry = true;
												break;
											}
									}
									break;
								}
							case SendRequestError.TooManyMessagesReceived:
								{
									if (sre.InnerException is AggregateException ae)
									{
										Exception e1 = ae.InnerExceptions.Where(x => !(x is UnexpectedMessageReceivedException)).FirstOrDefault();
										if (e1 != null)
										{
											Debug.WriteLine($"WARNING: Unhandled exceptions on Read. {opId}");
											newStat.ErrorMessage = "On Read, there were unhandled exceptions from a previous SendAndReadResponse operation.";
											newStat.Exception = e1;
										}
										else
										{
											foreach (UnexpectedMessageReceivedException umre in ae.InnerExceptions)
											{
												if (MessageHelper.DoesResponseHaveExpectedCorId(umre.ReceivedMessage, correlationId, correlationIdInfo))
												{
													newStat.ErrorMessage = "On Read, message found from previous send operation that timed-out.";
													newStat.TestResponse = umre.ReceivedMessage;
													newStat.Succeeded = true;
													newStat.IsClientUsable = true;
													newStat.ShouldRetry = false;
												}
											}

											if (!newStat.Succeeded)
											{
												newStat.ErrorMessage = "On Read, message(s) found from previous send operation that timed-out but none match.";
												newStat.IsClientUsable = true;
												newStat.ShouldRetry = true;
											}
										}
									}
									else
									{
										Debug.WriteLine($"WARNING: On Read, Exception is TooManyMessagesReceived, but InnerException is not aggregate. {opId}");
									}

									break;
								}

						}
						break;
					}
			}

			if (newStat.ErrorMessage == null)
			{
				newStat.ErrorMessage = sre.ToString();
			}

			if (!newStat.Succeeded)
			{
				if (newStat.ShouldRetry)
				{
					Debug.WriteLine($"{newStat.ErrorMessage} is being handled by ManagedClient. NeedsNewClient={newStat.NeedNewClient}. {opId}");
				}
				else
				{
					Debug.WriteLine($"ManagedClient is not handling {sre}. {opId}");
					if (newStat.Exception == null)
					{
						newStat.Exception = sre;
					}
				}
			}

			return newStat;
		}

		private async Task<T> GetClientFromPool(T clientToRemove, string opId)
		{
			// Make sure that if the ManagedClient has concluded the client is not usable, then it gets discarded instead of returned to the pool.
			if (clientToRemove != null) CloseClient(clientToRemove);

			try
			{
				T messageClient = await _clientPool.GetClientAsync(clientToRemove, opId);
				return messageClient;
			}
			catch (GatewayException ge)
			{
				Debug.WriteLine($"ManagedClient received exception: {ge} while getting a client from the pool.");
				throw;
			}
			catch (Exception e)
			{
				Debug.WriteLine($"ManagedClient received exception: {e.Message} while getting a client from the pool.");
				throw new GatewayException(GatewayOperationEnum.GetClientFromPool, e);
			}
		}

		private void CloseClient(T client)
		{
			try
			{
				client.Dispose();
			}
			catch
			{
				// ignore all errors.
			}
		}

		class OperationStatus
		{
			public bool Succeeded { get; set; }
			public bool ShouldRetry { get; set; }
			public int RetryCount { get; set; }
			public bool IsClientUsable { get; set; }

			public Exception Exception { get; set; }
			public string ErrorMessage { get; set; }

			public SendRequestOperation? Operation { get; set; }
			public string TestResponse { get; set; }

			public bool NeedNewClient => ShouldRetry && !IsClientUsable;

			public OperationStatus() : this(null)
			{
			}

			public OperationStatus(Exception e)
			{
				Succeeded = false;
				ShouldRetry = false;
				RetryCount = 0;
				IsClientUsable = false;

				Exception = e;
				ErrorMessage = null;

				if (e is SendRequestException sre) Operation = sre.Operation;
				TestResponse = null;
			}
		}

		#region IDisposable Support

		private bool disposedValue = false; // To detect redundant calls

		protected virtual void Dispose(bool disposing)
		{
			if (!disposedValue)
			{
				if (disposing)
				{
					DateTime t0 = DateTime.Now;

					// Return the client to the pool.
					_clientPool.ReturnClient(_messageClient);

					DateTime t1 = DateTime.Now;
					if (_useDetailedDebug) Debug.WriteLine($"ManagedClient returned MessageClient at {FmtDate(t0)}, took {FmtDuration(t1 - t0)}");

					_messageClient = null;
					_clientPool = null;
				}

				disposedValue = true;
			}
		}

		public void Dispose()
		{
			Dispose(true);
		}
		
		private string FmtDate(DateTime dt)
		{
			return dt.ToString("mm:ss:fff");
		}

		private string FmtDuration(TimeSpan ts)
		{
			if (ts.TotalSeconds < 0.005)
			{
				return ts.TotalMilliseconds.ToString() + "ms";
			}
			else
			{
				return ts.TotalSeconds.ToString();
			}
		}

		#endregion

	}
}
