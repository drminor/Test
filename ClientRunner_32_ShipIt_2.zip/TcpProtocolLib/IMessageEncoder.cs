﻿namespace TcpProtocolLib
{
	public interface IMessageEncoder
	{
		int LengthPrefixSizeInBytes { get; }

		byte[] CreatePacket(string message);

		string GetString(byte[] buffer, int count);

		//string ZeroLengthMessage { get; }
	}
}
